//  Copyright 2011 WidgetAvenue - Librelio. All rights reserved.


@interface WAFileManagerCell : UITableViewCell {
}


@end
