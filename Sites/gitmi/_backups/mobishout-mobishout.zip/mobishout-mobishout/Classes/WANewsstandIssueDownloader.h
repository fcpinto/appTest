//
//  WANewsstandIssueDownloader.h
//  Librelio
//
//  Copyright (c) 2011 WidgetAvenue - Librelio. All rights reserved.
//

#import "WADocumentDownloader.h"
#import <NewsstandKit/NewsstandKit.h>


@interface WANewsstandIssueDownloader : WADocumentDownloader <NSURLConnectionDownloadDelegate>

@end
