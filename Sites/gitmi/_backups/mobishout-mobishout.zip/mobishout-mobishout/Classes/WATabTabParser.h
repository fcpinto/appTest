//  Copyright 2011 WidgetAvenue - Librelio. All rights reserved.
//

@interface WATabTabParser : NSObject {

}

- (void) loadTabFile;


@end
