/**
 * Created by zul on 11/03/14.
 */
Ext.define('MobiShout_Admin.view.Notification', {

    extend: 'Ext.form.Panel',
    xtype: 'notification',

    config: {
        items: [
            {
                xtype: 'fieldset',
                title: 'Notification',
                items: [
                    {
                        xtype: 'textfield',
                        label: 'Title',
                        maxLength:66,
                        name: 'title'
                    },
                    {
                        xtype: 'textfield',
                        label: 'Message',
                        maxLength:66,
                        name: 'message'
                    }
                ]
            },
            {
                xtype:'button',
                text:'send',
                action:'sendNotification',
                margin:10
            }
        ]
    }
});