Ext.define('MobiShout_Admin.view.Ad', {
    extend: 'Ext.form.Panel',
    requires: [
        'Ext.field.File',
        'Ext.field.Hidden',
        'Ext.field.Number'
    ],
    xtype: 'ad',

    config: {
        multipartDetection:true,
        items: [
            {
                xtype: 'fieldset',
                title: 'Ad',
                items: [
                    {
                        xtype: 'numberfield',
                        label: 'Delay',
                        name: 'delay',
                        value: '3000'
                    },
                    {
                        xtype: 'textfield',
                        label: 'Link',
                        name: 'link',
                        placeHolder:'http://...'
                    },
                    {
                        xtype: 'textfield',
                        label: 'Description',
                        name: 'description'
                    },
                    {
                        xtype: 'datepickerfield',
                        label: 'Start',
                        name: 'date_start',
                        value: new Date(),
                        picker:{
                            yearFrom:new Date().getFullYear(),
                            yearTo:new Date().getFullYear()+2
                        },
                        dateFormat:'Y-m-d'
                    },
                    {
                        xtype: 'datepickerfield',
                        label: 'End',
                        name: 'date_end',
                        value: new Date(),
                        picker:{
                            yearFrom:new Date().getFullYear(),
                            yearTo:new Date().getFullYear()+2
                        },
                        dateFormat:'Y-m-d'
                    },
                    {
                        xtype: 'filefield',
                        cls: 'file-sender',
                        label: "640x960<br><br>Click in dashed area or just drop an image.",
                        labelWrap:true,
                        name: 'file1',
                        //multiple:true,
                        accept: 'image/png',
                        action: 'uploadImage',
                        limits:{
                            width:640,
                            height:960
                        }
                    },
                    {
                        xtype: 'filefield',
                        cls: 'file-sender',
                        label: "640x1136<br><br>Click in dashed area or just drop an image.",
                        labelWrap:true,
                        name: 'file2',
                        //multiple:true,
                        accept: 'image/png',
                        action: 'uploadImage',
                        limits:{
                            width:640,
                            height:1136
                        }
                    },
                    {
                        xtype: 'filefield',
                        cls: 'file-sender',
                        label: "1536x2048<br><br>Click in dashed area or just drop an image.",
                        labelWrap:true,
                        name: 'file3',
                        //multiple:true,
                        accept: 'image/png',
                        action: 'uploadImage',
                        limits:{
                            width:1536,
                            height:2048
                        }
                    },
                    {
                        xtype: 'filefield',
                        cls: 'file-sender',
                        label: "2048x1536<br><br>Click in dashed area or just drop an image.",
                        labelWrap:true,
                        name: 'file4',
                        //multiple:true,
                        accept: 'image/png',
                        action: 'uploadImage',
                        limits:{
                            width:2048,
                            height:1536
                        }
                    }
                ]
            },
            {
                xtype: 'button',
                text: 'save',
                action: 'saveAd',
                margin: 10
            }
        ]
    }
});