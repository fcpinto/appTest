Ext.define('MobiShout_Admin.view.AppHolder', {

    extend: 'Ext.Container',
    xtype: 'appHolder',

    config: {
        showAnimation: {
            firstTime: true,
            type: 'fadeIn',
            duration: 250
        },

        layout: 'hbox',

        items: [
            {
            //MENU
                xtype: 'menu'
            },
            {
                xtype: 'viewCards',
                style: 'float: left',
                flex: 1
            }
        ]
    }
});
