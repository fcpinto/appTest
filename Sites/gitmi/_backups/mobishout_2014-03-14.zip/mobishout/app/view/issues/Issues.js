Ext.define('MobiShout_Admin.view.issues.Issues', {

    extend: 'Ext.Panel',
    xtype: 'issues',

    config: {

        layout: 'fit',
        items: [
            {
                xtype: 'toolbar',
                docked: 'top',
                items: [
                    {
                        xtype: 'spacer'
                    },
                    {
                        xtype: 'button',
                        text: '',
                        style: 'border: 0px; background-color: rgba(17, 89, 140, 0);',
                        cls: 'toolbarBtn',
                        iconCls: 'ss-plus',
                        action: 'newIssue',
                        align: 'right'
                    },
                    {
                        xtype: 'button',
                        text: '',
                        cls: 'toolbarBtn',
                        style: 'border: 0px; background-color: rgba(17, 89, 140, 0);',
                        iconCls: 'ss-refresh',
                        action: 'refreshApp',
                        align: 'right',
                        handler: function () {
                            Ext.getStore('IssuesStore').load();
                        } // handler
                    }
                ]
            },
            {
                xtype: 'dataview',
                loadingText: null,
                cls: 'dataview',
                scrollToTopOnRefresh: false,
                scrollable: true,
                inline: true,
                itemTpl: Ext.create('Ext.XTemplate',
                    '</br><div style="font-size: 80%; text-align: center;">{title}</br>',
                    '<div style="font-size: 75%; text-align: center;">{subtitle}</br>',
                    '{[this.setActive(values.active, values.thumbnail)]}',
                    //'<div id="issues" class = "issueFolders" style="background-image: url({thumbnail})"></div>',
                    '<div style="margin-bottom: 10px"></div>',
                    {
                        setActive: function (value, thumbnail) {
                            if (value == '1') {
                                var html = '<div id="issues" class = "issueFolders" style="background-image: url(' + thumbnail + ')"><div class= "activeState">ON</div></div>'
                            }
                            if (value == '0') {
                                var html = '<div id="issues" class = "issueDeactive" style="background-image: url(' + thumbnail + ')"><div class= "deactiveState">OFF</div></div>'
                            }
                            return html;
                        }
                    }
                ),
                store: 'IssuesStore'
            }
        ]
    }
});
