Ext.define('MobiShout_Admin.view.Menu', {

    extend: 'Ext.dataview.List',
    xtype: 'menu',

    config: {
        title: 'Menu',
        itemId: 'menuList',
        hidden: false,
        store: 'MenuStore',
        itemTpl: '<span style = "font-family: SSStandard; margin-left: 7px; margin-right: 17px;">{icon}</span><span style="font-size: 85%;">{title}</span>',
        allowDeselect: false,
        fieldCls: 'something',
     //   scrollable: false,
        minWidth: 47,
        width: 200,
        listeners: {
            initialize: function () {
                this.select(0)
            }
        },
        items: [
            {
                xtype: 'container',
                layout: 'hbox',
                docked: 'top',
                items: {
                    xtype: 'button',
                    text: 'hello'
                }
            }
        ],
        items: [
            {
                xtype: 'container',
                layout: 'vbox',
                docked: 'top',
                items: [
                    {
                        items: [
                            {
                                layout: 'hbox',
                                docked: 'top',
                                items: [
                                    {
                                        xtype: 'spacer'
                                    },
                                    {
                                        xtype: 'button',
                                        iconCls: 'ss-back',
                                        itemId: 'hideMenuBtn',
                                        cls: 'hideMenuBtn',
                                        style: 'border: 0px; background-color: #0099FF; font-size: 65%; ' +
                                            'float: right; width: 30px;  height: 30px; padding-top: 7px; ' +
                                            'border-bottom-left-radius: 0.8em;border-top-left-radius: 0.8em;' +
                                            'margin-top: 9px; margin-bottom: 7px; position: fixed; bottom: 20px; margin-left: -30px',
                                        iconAlign: 'right',
                                        action: 'hideMenu'
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        xtype: 'img',
                        src: 'http://www.mobinteg.com/img/logo.png',
                        cls: 'avatar',
                        itemId: 'profileImg'
                    },
                    {
                        html: ['mobishout'],
                        itemId: 'userLabel',
                        cls: 'userLabel'
                    },
                    {
                        xtype: 'button',
                        itemId: 'logout',
                        text: 'logout',
                        action: 'logout',
                        cls: 'logoutBtn'
                    }
                ]}
        ]
    }
});