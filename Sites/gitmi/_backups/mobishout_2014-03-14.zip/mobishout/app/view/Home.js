Ext.define('MobiShout_Admin.view.Home', {

    extend: 'Ext.NavigationView',
    xtype: 'home',


    config: {
//        //  tabBarPosition: 'bottom',
//        listeners:{
//            initialize: function(){
//
//                MobiShout_Admin.app.getController('MenuController').getMenuList().select(0)
//            }
//
//        },
        navigationBar: {
            hidden: true
        },
        items: [
            {
                layout: {type: 'vbox', pack: 'center', align: 'center'},
                cls: 'home',
                //style:'background-repeat: no-repeat;background-size: auto 100%;background-position: center;',
                items: {
                    style: 'text-align: center;',
                    html: [
                        //'<div style="margin: 2em;"></div>',
                        '<img width="100%" src="resources/images/mobishout.png" />',
                        '<div style="margin: 5em;"></div>'
                     //   '<img width="80%" src="resources/images/vozLogo.png" />'

                    ].join("")
                }

            }
        ]
    }
});

