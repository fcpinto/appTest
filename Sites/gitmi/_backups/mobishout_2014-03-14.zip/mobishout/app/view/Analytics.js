Ext.define('MobiShout_Admin.view.Analytics', {

    extend: 'Ext.Panel',
    xtype: 'analytics',

    config: {
        style: 'background-color: #000',
        scrollable: true,
        layout: {type: 'vbox', align: 'center', style: "margin: 5%;"},
        style: "margin-top: 20px; margin-bottom: 20px;",
        items: [
            {
                //FIRST LINE
                layout: {type: 'hbox', style: "margin: 5%;"},
                items: [
                    {
                        xtype: 'container',
                        html: [
                            '<div class="chartsTitle">VIEWS PER DAY</div>' +
                                '<div id="chart" class="chartsDiv"></div>'
                        ].join(""),

                        listeners: {
                            initialize: function () {
                                oo.setAPIKey("41d50f56ef5941de1de502ac04012037edf9284d");
                                oo.load(function () {

                                    //TIME LINE
                                    var timeline = new oo.Timeline("82908055", "7d");

                                    timeline.addMetric("ga:visits", "Visits");

                                //    timeline.addMetric("ga:newVisits", "New Visits");

                                    timeline.setOptions({colors: ['#27A9E3', '#FF6666', '#1ABC9C'],
                                        chartArea: {left: 40, top: 30, width: "100%", height: "75%"},
                                        fontSize: '11',
                                        pointSize: 4,
                                        curveType: 'function',
                                        legend: {position: 'none'},
                                        tooltip: {textStyle: {color: "#666"}},
                                        vAxis: {baselineColor: '#ccc', viewWindowMode: "explicit", viewWindow: { min: 0 }},
                                        hAxis: {fontSize: '6', baselineColor: '#FFFFFF', gridlines: {count: 2, color: "#FFF"}}
                                    });

                                    timeline.draw('chart');
                                });
                            }
                        },
                        flex: 1
                    },
                    {
                        xtype: 'container',
                        html: [
                            '<div class="chartsTitle">NEW VIEWS</div>' +
                                '<div id="bar" class="chartsDiv"></div>'
                        ].join(""),

                        listeners: {
                            initialize: function () {
                                oo.setAPIKey("41d50f56ef5941de1de502ac04012037edf9284d");
                                oo.load(function () {

                                    //BAR
                                    var bar = new oo.Bar("82908055", "7d");
                                    bar.addMetric("ga:visits", "Visits");
                                    bar.addMetric("ga:newVisits", "New Visits");
                                    bar.setDimension("ga:continent");
                                    bar.draw('bar');
                                });
                            }
                        },
                        flex: 1
                    },
                    {
                        xtype: 'container',
                        html: [
                            '<div class="chartsTitle">VIEWS PER CITY</div>' +
                                '<div id="pie" class="chartsDiv"></div>'
                        ].join(""),

                        listeners: {
                            initialize: function () {
                                oo.setAPIKey("41d50f56ef5941de1de502ac04012037edf9284d");
                                oo.load(function () {

                                    //PIE
                                    var pie = new oo.Pie("82908055", "7d");
                                    pie.setMetric("ga:visits", "Visits");
                                    pie.setDimension("ga:city");
                                    pie.draw('pie');

                                });
                            }
                        },
                        flex: 1
                    }
                ],
                flex: 1
            },
            //SECOND LINE
            {
                layout: {type: 'hbox', style: "margin: 5%;"},
                items: [
                    {
                        xtype: 'container',
                        html: [
                            '<div class="chartsTitle">MOBILE BRANDING</div>' +
                                '<div id="pie2" class="chartsDiv"></div>'
                        ].join(""),

                        listeners: {
                            initialize: function () {
                                oo.setAPIKey("41d50f56ef5941de1de502ac04012037edf9284d");
                                oo.load(function () {

                                    //PIE
                                    var pie = new oo.Pie("82908055", "7d");
                                    pie.setMetric("ga:visits", "Visits");
                                    pie.setDimension("ga:mobileDeviceBranding");
                                    pie.draw('pie2');

                                });
                            }
                        },
                        flex: 1

                    },
                    {
                        xtype: 'container',
                        html: [
                            '<div class="chartsTitle">VIEWS PER DEVICE</div>' +
                                '<div id="bar2" class="chartsDiv"></div>'
                        ].join(""),

                        listeners: {
                            initialize: function () {
                                oo.setAPIKey("41d50f56ef5941de1de502ac04012037edf9284d");
                                oo.load(function () {

                                    //BAR
                                    var bar = new oo.Bar("82908055", "7d");
                                    bar.addMetric("ga:visits", "Visits");
                                    bar.setDimension("ga:mobileDeviceModel");
                                    bar.setOptions({colors: ['#27A9E3', '#FF6666', '#1ABC9C']});
                                    bar.draw('bar2');
                                });
                            }
                        },
                        flex: 1

                    },
                    {
                        xtype: 'container',
                        html: [
                            '<div class="chartsTitle">VIEWS PER SCREEN</div>' +
                                '<div id="chart2" class="chartsDiv"></div>'
                        ].join(""),

                        listeners: {
                            initialize: function () {
                                oo.setAPIKey("41d50f56ef5941de1de502ac04012037edf9284d");
                                oo.load(function () {

                                    var table = new oo.Table("82908055", "30d");
                                    table.addMetric("ga:visits", "Screen Views");
                                    table.addDimension("ga:screenResolution", "Resolution");
                                    table.draw('chart2');
                                });
                            }
                        },
                        flex: 1
                    }
                ],
                flex: 1
            }

        ]



    }
});