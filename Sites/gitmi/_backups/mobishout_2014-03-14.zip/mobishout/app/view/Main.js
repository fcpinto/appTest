Ext.define('MobiShout_Admin.view.Main', {
    extend: 'Ext.form.Panel',
    xtype: 'main',

    requires: [
        'Ext.TitleBar',
        'Ext.Button',
        'Ext.ux.Fileup',
        'Ext.field.Toggle',
        'Ext.field.DatePicker'
    ],

    config: {

        navigationBar: {
            hidden: true
        },

        //  tabBarPosition: 'bottom',

        items: [
            {
                xtype: 'toolbar',
                docked: 'top',
                items: [
                    {
                        xtype: 'button',
                        cls: 'toolbarBtn',
                        iconCls: 'ss-back',
                        style: 'border: 0px; background-color: rgba(17, 89, 140, 0);',
                        action: 'backToIssues',
                        align: 'left'
                    },
                    {
                        xtype: 'spacer'
                    }
//                    {
//                        xtype: 'button',
//                        text: 'Submit Issue',
//                        iconCls: 'action',
//                        action: 'submitIssue',
//                        align: 'right'
//                    }
                ]
            },
            {
                id: 'welcome',
                title: 'Welcome',
                iconCls: 'home',
                scrollable: null,
                styleHtmlContent: true,

                layout: 'hbox',

                items: [
                    {
                        layout: {
                            type: 'vbox'
                        },
                        defaults: {
                            style: 'margin: 12px;'
                        },
                        items: [
                            {
                                xtype: 'fieldset',
                                name: 'issue_id',
                                id: 'issue_id',

                                items: [
                                    {
                                        xtype: 'textfield',
                                        label: 'Issue: ',
                                        itemId: 'issue_id',
                                        name: 'issue_id',
                                        readOnly: true,
                                        hidden: true
                                    },
                                    {
                                        xtype: 'textfield',
                                        label: 'Keywords: ',
                                        name: 'keywords'
                                    },
                                    {
                                        xtype: 'textfield',
                                        label: 'Title: ',
                                        name: 'title'
                                    },
                                    {
                                        xtype: 'textfield',
                                        label: 'Subtitle: ',
                                        name: 'subtitle'
                                    },
                                    {
                                        xtype: 'textfield',
                                        label: 'Description: ',
                                        name: 'description'
                                    },
                                    {
                                        xtype: 'textfield',
                                        label: 'Filename: ',
                                        name: 'filename'
                                    },
                                    {
                                        xtype: 'datepickerfield',
                                        dateFormat: 'Y-m-d',
                                        name: 'date_start',
                                        value: new Date(),
                                        label: 'Date Start:',
                                        picker: {
                                            yearFrom: new Date().getFullYear(),
                                            yearTo: 2020,
                                            slotOrder: ['year', 'month', 'day']
                                        }
                                    },
                                    {
                                        xtype: 'datepickerfield',
                                        dateFormat: 'Y-m-d',
                                        name: 'date_end',
                                        value: new Date(),
                                        label: 'Date End:',
                                        picker: {
                                            yearFrom: new Date().getFullYear(),
                                            yearTo: 2020,
                                            slotOrder: ['year', 'month', 'day']
                                        }
                                    }
                                ]
                            },
                            {
                                layout: 'hbox',
                                defaults:{
                                    cls:'mainBtn',
                                    style: 'height: 100px'
                                },

                                items: [
                                    {
                                        itemId: 'fileBtn',
                                        xtype: 'fileupload',
                                        autoUpload: true,
                                        url: servicesMSMS + '/getfile.php?',
                                        style: 'margin: 5px; height: 100px;',
                                        iconCls: 'action',
                                        flex: 1,
                                        handler: function () {
                                           this.setUrl(servicesMSMS + '/getfile.php?i=' + Ext.getCmp('issue_id').getTitle());

                                            var valueID = Ext.getCmp('issue_id').getTitle().replace("shout","");

                                            this.setUrl(servicesMSMS + '/getfile.php?i=' + 'shout' + valueID);

                                        } // handler
                                    },
                                    {
                                        itemId: 'fileLoadBtn',
                                        xtype: 'fileupload',
                                        style: 'margin: 5px',
                                        autoUpload: true,
                                        loadAsDataUrl: true,
                                        states: {
                                            browse: {
                                                text: 'Select Thumbnail'
                                            },
                                            ready: {
                                                text: 'Load'
                                            },
                                            uploading: {
                                                text: 'Loading',
                                                loading: true
                                            }
                                        },
                                        flex: 1
                                        // For success and failure callbacks setup look into controller
                                    },
                                    {
                                        xtype: 'button',
                                        text: '',
                                        iconCls: 'ss-picture',
                                        iconAlign:'center',
                                        style: 'margin: 5px',
                                        action: 'uploadAssets',
                                        flex: 1
                                    },
                                    {
                                        layout: 'vbox',

                                        items: [
                                            {
                                                xtype: 'button',
                                                text: 'Create Shout',
                                                action: 'saveIssue',
                                                ui: 'confirm',
                                                align: 'right',
                                                style: 'margin: 5px',
                                                flex: 1
                                            },
                                            {
                                                xtype: 'button',
                                                text: 'Delete',
                                                action: 'deleteFolder',
                                                style: 'margin: 5px',
                                                ui: 'decline',
                                                flex: 1
                                            }
                                        ],
                                            flex: 2
                                    }
                                ]
                            }

                        ],
                        flex: 1
                    },
                    {
                        itemId: 'loadedImage',
                        xtype: 'img',
                        name: 'thumbnail',
                        style: 'margin-top: 20px;',
                        cls: 'thumbnailImage',
                        // width: '80%',
                        style: 'margin-top:11px; margin-left:30px; margin-right:30px;'
                    }
                ]
            }
        ]
    }
});
