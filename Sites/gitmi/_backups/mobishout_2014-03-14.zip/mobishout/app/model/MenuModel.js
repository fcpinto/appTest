Ext.define('MobiShout_Admin.model.MenuModel', {

    extend: 'Ext.data.Model',

    config: {
        fields: ['icon','title']
    }

});