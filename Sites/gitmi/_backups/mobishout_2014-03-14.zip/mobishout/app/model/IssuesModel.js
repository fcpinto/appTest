Ext.define('MobiShout_Admin.model.IssuesModel', {

    extend: 'Ext.data.Model',


    config: {
        fields: ["issue_id",
            "keywords",
            "filename",
            "thumbnail",
            "document_type_id",
            "active",
            "date_start",
            "date_end",
            "title",
            "subtitle",
            "description"
        ]
    }
});
