Ext.define('MobiShout_Admin.controller.AdController', {
    extend: 'Ext.app.Controller',

    config: {

        refs: {
            form: 'ad'
        },

        control: {
            'ad button[action = saveAd]': {
                tap: 'saveAd'
            },
            'ad field[name = photo]': {
                change: 'imageChange'
            },
            'field[action = uploadImage]': {
                initialize: 'upImageInit',
                change: 'imageChange'
            },
            'ad datepickerfield[name = date_start]': {
                change: 'dateStartChange'
            }
        }
    },

    saveAd: function () {
        console.log(this.getForm().getValues());

        var fields = this.getForm().query('field'),
            len = fields.length,
            allow = true,
            me = this;

        for(var i=0;i<len;i++){
            if(fields[i].getName() != 'link' && fields[i].getValue() == ""){
                fields[i].addCls('filerequired');
                allow = false;
            }
        }

        if(allow){
            this.uploadFiles();
        }
        else{
            Ext.Msg.alert('Missing', 'all fields are required except link', function(btn){

            });
        }
    },

    upImageInit: function (field) {
        field.input = field.element.down('.x-input-file', true);
        field.reader = new FileReader();
        field.reader.onerror = this.readerError;
        field.reader.onload = Ext.bind(this.readerLoad, this, [field], true);//Ext.pass(this.readerLoad,[field]);
        field.holder = field.element.down('.x-component-outer', true);

        //this.addDragDropEvent(field.input, 'drop', Ext.bind(this.onDrop, this, [field], true));
        this.addDragDropEvent(field.input, 'dragenter', Ext.bind(this.dragenter, this, [field], true));
        this.addDragDropEvent(field.input, 'dragleave', Ext.bind(this.dragleave, this, [field], true));
    },
    dragenter: function (e, field) {
        e = e || window.event;
        e.stopPropagation();
        e.preventDefault();
        field.addCls('fileover');
    },
    dragleave: function (e, field) {
        e = e || window.event;
        e.stopPropagation();
        e.preventDefault();
        field.removeCls('fileover');
    },

    onDrop: function (e, field) {

        field.removeCls('fileover');

        /*var file = e.dataTransfer.files[0];
        var imgType = file.type;

        field.removeCls('fileover');

        /*if (imgType == "image/png") {
            return false;
        }*/
        /*e = e || window.event; // get window.event if e argument missing (in IE)
        if (e.preventDefault) {
            e.preventDefault();
        }*/
    },

    addDragDropEvent: function addEventHandler(obj, evt, handler) {
        if (obj.addEventListener) {
            // W3C method
            obj.addEventListener(evt, handler, false);
        } else if (obj.attachEvent) {
            // IE method.
            obj.attachEvent('on' + evt, handler);
        } else {
            // Old school method.
            obj['on' + evt] = handler;
        }

    },

    imageChange: function (field) {
        var file = field.input.files[0];

        field.removeCls('fileover');
        field.removeCls('filerequired');

        if(file.type == "image/png"){
            try {
                field.reader.readAsDataURL(file);
            }
            catch (error) {
                console.log('wrong file!!');
            }
        }
        else{
            console.log('wrong file!!');
        }
    },

    uploadFiles: function() {

        Ext.Viewport.setMasked(
            {
                xtype: 'loadmask'
            }
        );

        var form = this.getForm(),
            values = form.getValues();

        values.date_start = Ext.Date.format(values.date_start, 'Y-m-d');
        values.date_end = Ext.Date.format(values.date_end, 'Y-m-d');

        Ext.Ajax.request({
            url: servicesMSMS,
            isUpload: true,
            params:{
                q:Ext.encode({
                    UploadImg_newAd:[values]
                })
            },
            callback:function(){
                console.log(arguments);
                Ext.Viewport.setMasked(false);
            },
            method: 'POST',
            data: new FormData(form.element.dom),
            disableCaching:false,
            success: function(response, options) {
                console.log(Ext.decode(response.responseText));
            },
            failure: function(response, options) {
                console.log('fail');
            }
        });

    },

    readerLoad: function (e, field) {
        var img = new Image(),
            limits = field.config.limits;

        img.src = e.target.result;

        if(img.width == limits.width & img.height == limits.height){

            field.addCls('withfile');
            field.holder.style.backgroundImage = 'url("' + img.src + '")';
        }
        else{
            Ext.Msg.alert('Wrong size', (img.width +'x'+ img.height) + '<br>Right size: ' + limits.width +'x'+ limits.height);
        }

    },

    readerError: function (e) {
        var message;
        switch (e.target.error.code) {
            case e.target.error.NOT_FOUND_ERR:
                message = 'File Not Found';
                break;

            case e.target.error.NOT_READABLE_ERR:
                message = 'File is not readable';
                break;

            case e.target.error.ABORT_ERR:
                break;

            default:
                message = 'Can not read file';
        }
        console.log(message);
    },

    dateStartChange:function(field){
        var form = this.getForm(),
            values = form.getValues(),
            ds = values.date_start.getTime(),
            de = values.date_end.getTime();

        if(ds > de){
            form.setValues({
                date_end:values.date_start
            });
        }
    }

});
