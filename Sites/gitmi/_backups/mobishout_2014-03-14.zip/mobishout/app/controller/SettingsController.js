Ext.define('MobiShout_Admin.controller.SettingsController', {
    extend: 'Ext.app.Controller',

    config: {

        refs: {
            settings:'settings'
        },

        control: {

        }
    }

});
