//
//  SocialMessage.m
//  Copyright (c) 2013 Lee Crossley - http://ilee.co.uk
//

#import "Cordova/CDV.h"
#import "SocialMessage.h"
#import <Twitter/Twitter.h>
#import <MessageUI/MessageUI.h>
//#import <Twitter/TWTweetComposeViewController.h>

@implementation SocialMessage

- (void) send:(CDVInvokedUrlCommand*)command;
{
    NSMutableDictionary *args = [command.arguments objectAtIndex:0];
    NSString *text = [args objectForKey:@"text"];
    NSString *url = [args objectForKey:@"url"];
    NSString *image = [args objectForKey:@"image"];
    NSString *subject = [args objectForKey:@"subject"];
    NSString *activityType = [args objectForKey:@"activityType"];
    NSArray *activityTypes = [[args objectForKey:@"activityTypes"] componentsSeparatedByString:@","];

    NSMutableArray *items = [NSMutableArray new];
    if (text)
    {
        [items addObject:text];
    }
    if (url)
    {
        NSURL *formattedUrl = [NSURL URLWithString:[NSString stringWithFormat:@"%@", url]];
        [items addObject:formattedUrl];
    }
    if (image)
    {
        UIImage *imageFromUrl = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@", image]]]];
        [items addObject:imageFromUrl];
    }

    UIActivityViewController *activity = [[UIActivityViewController alloc] initWithActivityItems:items applicationActivities:Nil];
    [activity setValue:subject forKey:@"subject"];

    NSMutableArray *exclusions = [[NSMutableArray alloc] init];

    if (![activityTypes containsObject:@"PostToFacebook"])
    {
        [exclusions addObject: UIActivityTypePostToFacebook];
    }
    if (![activityTypes containsObject:@"PostToTwitter"])
    {
        [exclusions addObject: UIActivityTypePostToTwitter];
    }
    if (![activityTypes containsObject:@"PostToWeibo"])
    {
        [exclusions addObject: UIActivityTypePostToWeibo];
    }
    if (![activityTypes containsObject:@"Message"])
    {
        [exclusions addObject: UIActivityTypeMessage];
    }
    if (![activityTypes containsObject:@"Mail"])
    {
        [exclusions addObject: UIActivityTypeMail];
    }
    if (![activityTypes containsObject:@"Print"])
    {
        [exclusions addObject: UIActivityTypePrint];
    }
    if (![activityTypes containsObject:@"CopyToPasteboard"])
    {
        [exclusions addObject: UIActivityTypeCopyToPasteboard];
    }
    if (![activityTypes containsObject:@"AssignToContact"])
    {
        [exclusions addObject: UIActivityTypeAssignToContact];
    }
    if (![activityTypes containsObject:@"SaveToCameraRoll"])
    {
        [exclusions addObject: UIActivityTypeSaveToCameraRoll];
    }

    activity.excludedActivityTypes = exclusions;
    

    //mi::DG - alteração feita para enviar twitter (tirar //)
    //[self.viewController presentViewController:activity animated:YES completion:Nil];
    
    if([activityType isEqualToString:@"Mail"]){
        
        /*MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
        
        // his class should be the delegate of the mc
        mc.mailComposeDelegate = self;
        
        // set a mail subject ... but you do not need to do this :)
        [mc setSubject:@"This is an optional mail subject!"];
        
        // set some basic plain text as the message body ... but you do not need to do this :)
        [mc setMessageBody:@"This is an optional message body plain text!" isHTML:NO];
        
        // set some recipients ... but you do not need to do this :)
        [mc setToRecipients:[NSArray arrayWithObjects:@"first.address@test.com", @"second.address@test.com", nil]];
        
        // displaying our modal view controller on the screen with standard transition
        [self.viewController presentModalViewController:mc animated:YES];
        
        // be a good memory manager and release mc, as you are responsible for it because your alloc/init
        //[mc release];*/
        
        
        if([MFMailComposeViewController canSendMail]){
            NSLog(@"canSendMail!!!");
            MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
            picker.mailComposeDelegate = self;
            
            if (subject)
            {
                [picker setSubject:subject];
            }
            
            // Attach an image to the email
            //NSString *path = [[NSBundle mainBundle] pathForResource:@"rainy" ofType:@"png"];
            //NSData *myData = [NSData dataWithContentsOfFile:path];
            //[picker addAttachmentData:myData mimeType:@"image/png" fileName:@"rainy"];
            
            // Fill out the email body text
            NSString *emailBody = [NSString stringWithFormat:@"%@<br><br>%@", text, url];
            [picker setMessageBody:emailBody isHTML:YES];
            
            [self.viewController presentModalViewController:picker animated:YES];
            //[picker release];
        }
        else{
            // Show Alert View When The Application Cannot Send Mail
            NSString *message = @"The application cannot send a mail at the moment. This is because it cannot reach Mail client or you don't have a mail account associated with this device.";
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops" message:message delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
            [alertView show];
        }
        
    }
    else{
        NSString *chosenService;
        if ([activityType isEqualToString:@"PostToTwitter"]){
            chosenService = SLServiceTypeTwitter;
        }
        else if ([activityType isEqualToString:@"PostToFacebook"]){
            chosenService = SLServiceTypeFacebook;
        }
        
        if([SLComposeViewController isAvailableForServiceType:chosenService]){
            SLComposeViewController *mySLComposer = [SLComposeViewController composeViewControllerForServiceType:chosenService];
            
            if (text)
            {
                [mySLComposer setInitialText:text];
            }
            if (image)
            {
                UIImage *imageFromUrl = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@", image]]]];
                [mySLComposer addImage:imageFromUrl];
            }
            if (url)
            {
                NSURL *formattedUrl = [NSURL URLWithString:[NSString stringWithFormat:@"%@", url]];
                [mySLComposer addURL:formattedUrl];
            }
            
            [mySLComposer setCompletionHandler:^(SLComposeViewControllerResult result) {
                [self.viewController dismissModalViewControllerAnimated:YES];
                switch (result) {
                    case SLComposeViewControllerResultCancelled:
                    NSLog(@"Post Canceled");
                    break;
                    case SLComposeViewControllerResultDone:
                    NSLog(@"Post Sucessful");
                    break;
                    
                    default:
                    break;
                }
            }];
            
            [self.viewController presentViewController:mySLComposer animated:YES completion:nil];
        }
        else {
            // Show Alert View When The Application Cannot Send Tweets
            NSString *message = @"The application cannot send a tweet at the moment. This is because it cannot reach Twitter or you don't have a Twitter account associated with this device.";
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops" message:message delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
            [alertView show];
        }
    }
    
    
    
    //mi::DG - alteração feita para enviar twitter
    /*if ([TWTweetComposeViewController canSendTweet]) {
        // Initialize Tweet Compose View Controller
        TWTweetComposeViewController *vc = [[TWTweetComposeViewController alloc] init];
        // Settin The Initial Text
        if (text)
        {
            [vc setInitialText:text];
        }
        //[vc setInitialText:@"This tweet was sent using the new Twitter framework available in iOS 5."];
        // Adding an Image
        if (image)
        {
            UIImage *imageFromUrl = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@", image]]]];
            [vc addImage:imageFromUrl];
        }
        //UIImage *image = [UIImage imageNamed:@"https://fbcdn-photos-f-a.akamaihd.net/hphotos-ak-ash3/851555_475232129262933_807163637_n.png"];
        //[vc addImage:image];
        // Adding a URL
        if (url)
        {
            NSURL *formattedUrl = [NSURL URLWithString:[NSString stringWithFormat:@"%@", url]];
            [vc addURL:formattedUrl];
        }
        //NSURL *url = [NSURL URLWithString:@"http://www.mynetpress.com"];
        //[vc addURL:url];
        // Setting a Completing Handler
        [vc setCompletionHandler:^(TWTweetComposeViewControllerResult result) {
            [self.viewController dismissModalViewControllerAnimated:YES];
        }];
        // Display Tweet Compose View Controller Modally
        [self.viewController presentViewController:vc animated:YES completion:nil];
    } else {
        // Show Alert View When The Application Cannot Send Tweets
        NSString *message = @"The application cannot send a tweet at the moment. This is because it cannot reach Twitter or you don't have a Twitter account associated with this device.";
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oops" message:message delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
        [alertView show];
    }*/
}
    - (void)mailComposeController:(MFMailComposeViewController*)mailController didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error {
        [self.viewController dismissModalViewControllerAnimated:YES];
        
        
    }
    

@end