/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.NewsFilters', {
    extend: 'Ext.form.Panel',
    xtype: 'newsFilters',

    config: {
        itemId:'newsFilters',
        styleHtmlContent: true,
        style: 'background:#ffffff;',
        items: [
            {
                xtype:'filterSet'
            },
            {
                xtype: 'sliderfield',
                itemId:'days',
                label: 'Dias: 7',
                value: 7,
                minValue: 1,
                maxValue: 30,
                name:'days',
                listeners: {
                    change: function (cmp, sl, thumb, newValue, oldValue) {
                        cmp.setLabel('Dias: ' + newValue);
                    }
                }
            },
            {
                xtype: 'button',
                itemId: 'filterBtn',
                text: 'Filtrar',
                ui: 'action',
                margin: 5,
                padding: 10,
                docked: 'bottom',
                action: 'filtrar'
            }
        ]

    }
});
