/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 17/09/13
 * Time: 00:52
 */
Ext.define('Manchete.model.MenuClipping', {
    extend: 'Ext.data.Model',

    config: {
        fields:[
            'id',
            'clipping',
            'activo',
            'referencia3',
            'tipo',
            {
                name:'priority',
                mapping:'tipo',
                convert:function(vl){
                    if(vl == 'Imprensa Escrita'){
                        return 1;
                    }
                    else if(vl == 'Online'){
                        return 2;
                    }
                    else if(vl == 'Audiovisuais'){
                        return 3;
                    }
                    return 4;
                }
            },
            {
                name:'filters',
                mapping:'referencia3',
                convert:function(vl){
                    return btoa(JSON.stringify([
                        {
                            property: 'tipo',
                            value: vl
                        },
                        {
                            property: 'data?>=',
                            value: 'date("now", "-6 days")'
                        }
                    ]));
                }
            },
            {
                name:'sorters',
                convert:function(vl){
                    return btoa(JSON.stringify([
                        {
                            property:'data',
                            direction:'DESC'
                        }
                    ]));
                }
            }
        ]
    }
});


