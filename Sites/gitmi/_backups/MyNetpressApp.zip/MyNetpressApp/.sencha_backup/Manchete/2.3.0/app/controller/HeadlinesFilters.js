/**
 * Created by zul on 08/10/13.
 */
Ext.define('Manchete.controller.HeadlinesFilters', {
    extend: 'Ext.app.Controller',

    config: {
        refs: {
            headlinesFilters:'headlinesFilters',
            pubSelector:'headlinesFilters #manchetesPub',
            daysSlider:'headlinesFilters #days',
            filterPublicacao:'filterManchetesPub'
        },
        control: {
            headlinesFilters:{
                initialize:'oninitialize'
            },
            'button[action=filtrarManchetes]':{
                tap:'filtrar'
            },
            'textfield[itemId=manchetesPub]':{
                initialize:'giveTap'
            },
            'button[action=fmSelectAll]':{
                tap:'fSelectAll'
            },
            'button[action=fmClose]':{
                tap:'fClose'
            }
        }
    },
    init: function () {
        this.control({
            filterPublicacao: {
                itemtap: Ext.Function.createBuffered(this.onitemtap, 100, this)
            }
        });
    },
    oninitialize:function(form){

    },
    giveTap:function(tf){
        tf.element.on('tap',Ext.bind(this.onFieldTap, this, [tf], false))
    },
    onFieldTap:function(tf){
        if(!tf.getDisabled()){
            var store = tf.config.st,
                list = store.charAt(0).toLowerCase()+store.slice(1);

            //console.log(list)

            if (!this[list]) {
                this[list] = Ext.Viewport.add({
                    xtype: list,
                    tf:null
                });
                Ext.getStore(store).load();
            }
            else{
                this.updateFields(this[list], tf);
            }
            this[list].config.tf = tf;
            this[list].show();
        }
    },
    onitemtap:function(list, index, target, record){
        if(!list.isSelected(record)){
            list.down('#fSelectAll').setIconCls('ss-notall');
        }

        this.updateFields(list, list.config.tf);
    },
    updateFields:function(list, tf){
        var name = 'publicacao',
            selection = list.getSelection(),
            len = list.getSelectionCount(),
            refs = [],
            value = {},
            firstItem;

        if(len > 1){
            tf.setValue('vários');
        }
        else if(len == 1){
            firstItem = list.getSelection()[0]
            tf.setValue(firstItem.data.text);
        }
        else{
            tf.setValue('');
        }

        for(var i=0;i<len;i++){
            refs.push(selection[i].data.value);
        }
        value[name] = len==0?'':'"'+refs.join('","')+'"';

        this.getHeadlinesFilters().setValues(value);
    },
    filtrar:function(btn){
        var form = this.getHeadlinesFilters(),
            publicacao = form.getValues().publicacao,
            days = -form.getValues().days[0]+1,
            array = [],
            store = Ext.getStore('HeadlinesTable');

        if (publicacao != '') {
            array.push('publicacao IN (' + publicacao + ')');
        }
        array.push('data >= date("now","' + days + ' days")');

        //console.log('SELECT * FROM HEADLINES WHERE ' + array.join(' AND '));// + ' ORDER BY data DESC LIMIT 0, 25');

        store.setFilters([
            {
                property: 'ownQuery',
                value: 'SELECT * FROM HEADLINES WHERE ' + array.join(' AND ')// + ' ORDER BY data DESC LIMIT 0, 25'
            }
        ]);
        store.removeAll();
        store.currentPage = 1;
        store.load();

        //form.up('navigationview').reset();
        Manchete.app.getController('Main').showViews('manchetes');
    },
    fSelectAll:function(btn){
        var list = btn.up('list');
        if(!btn.allItems){
            btn.setIconCls('ss-all');
            list.selectAll();
        }
        else{
            btn.setIconCls('ss-notall');
            list.deselectAll();
        }
        btn.allItems = !btn.allItems;
        this.updateFields(list, list.config.tf);
    },
    fClose:function(btn){
        btn.up('list').hide();

    }
});