/**
 * Created by zul on 04/11/13.
 */
Ext.define('Manchete.view.LoginForm', {
    extend:'Ext.Container',

    requires:[
        'Ext.field.Email',
        'Ext.field.Password'
    ],

    xtype:'loginForm',

    config:{

        modal: true,
        centered:true,
        hideOnMaskTap: true,
        hidden: true,
        styleHtmlContent: true,
        contentEl: 'content',
        width: !Ext.os.is.Phone? 400 : 260,
        height: !Ext.os.is.Phone? 400 : 280,
        layout:'fit',
        style:'background-color:#ffffff;',

        showAnimation:{
            type:'slide',
            direction:'up'
        },
        hideAnimation:{
            type:'slide',
            direction:'up',
            out:true
        },
        cls:'login-view',

        items:[
            {
                xtype:'formpanel',
                layout:'vbox',
                scrollable:null,
                padding:10,
                items:[
                    {
                        xtype: 'img',
                        src: 'resources/images/manchete_logo.png',
                        style: 'background-size:contain;',
                        flex:1,
                        margin:!Ext.os.is.Phone? 40 : 10
                    },
                    {
                        xtype: 'emailfield',
                        itemId: 'user',
                        label: '<span style="font-family: SSStandard; font-size: 150%">👤</span>',
                        labelWidth: 44,
                        placeHolder:'e-mail',
                        name: 'user',
                        value:'teste@manchete.pt',
                        margin:'0 0 10 0'
                    },
                    {
                        xtype: 'passwordfield',
                        itemId: 'pass',
                        label: '<span style="font-family: SSStandard; font-size: 150%">🔒</span>',
                        labelWidth: 44,
                        placeHolder:'password',
                        name: 'password',
                        value:'b9Wk9Yeq',
                        margin:'0 0 10 0'
                    },
                    {
                        xtype: 'button',
                        itemId: 'loginBtn',
                        //text: 'LOGIN',
                        ui: 'action',
                        action: 'login',
                        iconCls:'ss-select',
                        iconAlign:'center',
                        padding:10
                    }
                ]
            }
        ]
    }
});