/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.FilterManchetesPub', {
    extend: 'Ext.dataview.List',
    xtype: 'filterManchetesPub',

    config: {
        modal: true,
        centered:true,
        hideOnMaskTap: true,
        hidden: true,
        width: !Ext.os.is.Phone? 400 : 260,
        height: !Ext.os.is.Phone? 400 : '70%',
        contentEl: 'content',
        styleHtmlContent: true,
        scrollable: true,
        store: 'FilterManchetesPub',
        mode:'MULTI',
        callback:'',
        itemTpl:Ext.create('Ext.XTemplate',
            '<span class="title">{text}</span>'
        ),
        items:[
            {
                xtype:'titlebar',
                docked:'top',
                title: 'Filtros',
                ui:'light',
                items: [
                    {
                        iconCls: 'ss-notall',
                        align: 'left',
                        ui:'plain',
                        action:'fmSelectAll',
                        itemId:'fmSelectAll'
                    },
                    {
                        iconCls: 'ss-select',
                        align: 'right',
                        ui:'plain',
                        action:'fmClose'
                    }
                ]
            }
        ]
    }
});