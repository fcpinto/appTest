/**
 * Created by zul on 08/10/13.
 */
Ext.define('Manchete.controller.NewsFilters', {
    extend: 'Ext.app.Controller',

    config: {
        refs: {
            newsFilters:'newsFilters',
            newsSearch:'newsSearch',
            meioSelector:'newsFilters #meio',
            pubSelector:'newsFilters #publicacao',
            temaSelector:'newsFilters #tema',
            daysSlider:'newsFilters #days',
            datainicio:'textfield[itemId=datainicio]',
            datafim:'textfield[itemId=datafim]',
            filterMeio:'filterMeio',
            filterPublicacao:'filterPublicacao',
            filterTema:'filterTema'
        },
        control: {
            newsFilters:{
                initialize:'oninitialize'
            },
            newsSearch:{
                initialize:'onSearchinitialize'
            },
            'button[action=filtrar]':{
                tap:'filtrar'
            },
            'textfield[itemId=meio]':{
                initialize:'giveTap',
                change:'onMeioChange'
            },
            'textfield[itemId=publicacao]':{
                initialize:'giveTap'
            },
            'textfield[itemId=tema]':{
                initialize:'giveTap'
            },
            'textfield[itemId=datainicio]':{
                onchange:'dateChange'
            },
            'textfield[itemId=datafim]':{
                onchange:'dateChange'
            },
            'button[action=fSelectAll]':{
                tap:'fSelectAll'
            },
            'button[action=fClose]':{
                tap:'fClose'
            },
            'button[action=procurar]':{
                tap:'procurar'
            }
        }
    },
    init: function () {
        this.control({
            filterMeio: {
                itemtap: Ext.Function.createBuffered(this.onitemtap, 100, this)
            },
            filterPublicacao: {
                itemtap: Ext.Function.createBuffered(this.onitemtap, 100, this)
            },
            filterTema: {
                itemtap: Ext.Function.createBuffered(this.onitemtap, 100, this)
            }
        });
        this.listMode = null;
        this.formType = null;
    },
    onSearchinitialize:function(form){
        this.listMode = 'SINGLE';
        this.formType = form;
        this.cleaner();
        Ext.getCmp('m-menu').deselectAll();
        //console.log(form.getItemId());
    },
    oninitialize:function(form){

        //isFavorites
        //var data = form.getData();
        var data = Ext.getCmp('m-menu').getSelection()[0].data,
            maxdays = parseInt(!localStorage.manchetemaxhistory?30:localStorage.manchetemaxhistory);

        //this.cleaner();
        this.listMode = 'MULTI';
        this.formType = form;

        if (data.activo == 1) {
            var tf = this.getMeioSelector(),
                store = tf.config.st,
                list = store.charAt(0).toLowerCase()+store.slice(1);

            tf.setDisabled(true);
            if (!this[list]) {
                this[list] = Ext.Viewport.add({
                    xtype: list,
                    tf:null
                });
                Ext.getStore(store).load();
            }
            this[list].config.tf = tf;

            form.setValues({
                meio: data.referencia3,
                meioString: data.clipping
            })
        }

        this.getDaysSlider().setMaxValue(maxdays);
        if(data.id == 2005 || data.id == 2006){
            this.getDaysSlider().setValue('1');
            this.getDaysSlider().setLabel('Dias: 1');
            this.getDaysSlider().setDisabled(true);
        }
        else{
            console.log(this.getDaysSlider().getValue(), maxdays);
            if(this.getDaysSlider().getValue()>=maxdays){
                this.getDaysSlider().setValue(maxdays);
                this.getDaysSlider().setLabel('Dias: '+maxdays);
            }
        }

        form.config.isFavorites = (data.referencia3 == 'favorito');
    },
    giveTap:function(tf){
        Ext.Function.defer(this.onFieldTap, 100, this, [tf,true]);
        tf.element.on('tap',Ext.bind(this.onFieldTap, this, [tf], false))
    },

    onMeioChange:function(tf){
        var selected = Ext.getCmp('m-menu').getSelection()[0],
            activo = !selected?0:selected.data.activo,
            store = tf.config.st,
            list = store.charAt(0).toLowerCase()+store.slice(1),
            selection = this[list].getSelection(),
            len = selection.length,
            refs = [];

        if(activo == 1){
            refs.push(selected.data.referencia3);
        }
        else{
            for(var i=0;i<len;i++){
                refs.push(selection[i].data.value);
            }
        }
        //console.log(refs.join('","'));
        Ext.getStore('FilterPublicacao').removeAll();
        Ext.getStore('FilterPublicacao').setFilters([
            {
                property: 'ownQuery',
                value: 'SELECT DISTINCT publicacao FROM NEWS WHERE tipo in ("' + refs.join('","') + '")'
            }
        ]);
        Ext.getStore('FilterPublicacao').load();
    },
    onFieldTap:function(tf,notShow){
        if(!notShow){
            notShow = false;
        }
        if(!tf.getDisabled()){
            var store = tf.config.st,
                list = store.charAt(0).toLowerCase()+store.slice(1);

            if (!this[list]) {
                this[list] = Ext.Viewport.add({
                    xtype: list,
                    tf:null
                });
                Ext.getStore(store).load();
            }
            else{
                this.updateFields(this[list], tf);
            }

            this[list].setMode(this.listMode);
            this[list].config.tf = tf;
            if(!notShow){
                this[list].show();
            }
        }

    },
    createList:function(store){
        var list = store.charAt(0).toLowerCase()+store.slice(1);
        if (!this[list]) {
            this[list] = Ext.Viewport.add({
                xtype: list,
                tf:null
            });
            Ext.getStore(store).load();
        }
        //this[list].deselectAll();
        this[list].config.tf = null;
        this[list].show();
        this.cleaner();
    },
    onitemtap:function(list, index, target, record){
        if(!list.isSelected(record)){
            list.down('#fSelectAll').setIconCls('ss-notall');
        }

        if(list.config.tf){
            this.updateFields(list, list.config.tf);
        }
    },
    updateFields:function(list, tf){
        var name = tf.getItemId(),
            selection = list.getSelection(),
            len = list.getSelectionCount(),
            refs = [],
            value = {},
            firstItem;

        if(len > 1){
            tf.setValue('vários');
        }
        else if(len == 1){
            firstItem = list.getSelection()[0]
            tf.setValue(firstItem.data.text);
        }
        else{
            tf.setValue('');
        }
        for(var i=0;i<len;i++){
            refs.push(selection[i].data.value);
        }
        value[name] = len==0?'':refs.join(',');

        this.formType.setValues(value);
    },
    filtrar:function(btn){
        var form = this.getNewsFilters(),
            isFavorites = form.config.isFavorites,
            meio = form.getValues().meio,
            publicacao = form.getValues().publicacao,
            tema =  form.getValues().tema,
            days = form.getValues().days[0]-1,
            store = Ext.getStore('News'),
            filters = [];

        if (isFavorites) {
            filters.push({
                property:'favotito',
                value:1
            })
        }
        if (meio != '') {
            filters.push({
                property:'tipo',
                values:meio.split(',')
            })
        }
        if (publicacao != '') {
            filters.push({
                property:'publicacao',
                values:publicacao.split(',')
            })
        }
        if (tema != ''){
            filters.push({
                property:'tema',
                anyMatch:true,
                values:tema.split(',')
            })
        }
        //if (days > 0) {
            filters.push({
                property: 'data?>=',
                value: 'date("now", "-' + days + ' days")'
            });
        //}
        store.setFilters(filters);
        store.removeAll();
        store.currentPage = 1;
        store.load();

        form.up('navigationview').reset();


    },
    procurar:function(btn){
        var form = this.getNewsSearch(),
            values = form.getValues(),
            meio = values.meio,
            publicacao = values.publicacao,
            tema =  values.tema,
            datainicio = values.datainicio.replace('T',' '),
            datafim = values.datafim.replace('T',' '),
            //days = values.days[0]-1,
            palavra1 = values.palavra1,
            palavra2 = values.palavra2,
            store = Ext.getStore('SearchNews');

        if(meio.length + publicacao.length + tema.length == 0){
            Ext.Msg.alert('Pesquisa', 'Tem de preencher pelo menos um dos campos...', Ext.emptyFn);
        }
        else if(palavra1 == ''){
            Ext.Msg.alert('Pesquisa', 'Tem de preencher pelo menos a Palavra 1', Ext.emptyFn);
        }
        else{

            if(Ext.Viewport.getMasked().isHidden()){
                Ext.Viewport.getMasked().setHidden(false);
            }

            store.load({
                params:{
                    user: localStorage.mancheteuser,
                    password: localStorage.manchetepass,
                    datainicio:datainicio,
                    datafim:datafim,
                    tema:tema,
                    tipo:meio,
                    publicacao:publicacao,
                    palavra1:palavra1,
                    palavra2:palavra2,
                    operador:""
                }
            });
        }
    },
    fSelectAll:function(btn){
        var list = btn.up('list');
        if(!btn.allItems){
            btn.setIconCls('ss-all');
            list.selectAll();
        }
        else{
            btn.setIconCls('ss-notall');
            list.deselectAll();
        }
        btn.allItems = !btn.allItems;
        if(list.config.tf){
            this.updateFields(list, list.config.tf);
        }


    },
    fClose:function(btn){
        var list = btn.up('list')
        list.hide();
        if(!list.config.tf){
            var data = Ext.getCmp('m-menu').getSelection()[0].data,
                store = Ext.getStore('News'),
                selection = list.getSelection(),
                len = list.getSelectionCount(),
                filters = [].concat(data.filters),
                values = [];

            if(len > 0){
                for(var i=0;i<len;i++){
                    values.push(selection[i].data.value);
                }
                filters.push({
                    property: 'tema',
                    anyMatch:true,
                    values: values
                });
            }
            store.setFilters(filters);
            store.setSorters(data.sorters);

            store.removeAll();
            store.currentPage = 1;
            store.title = data.clipping;
            store.load();

            Manchete.app.getController('Main').showViews('mediaType');
        }
    },
    cleaner:function(){
        var selectors = ['filterMeio','filterPublicacao','filterTema'],
            len = selectors.length,
            list;
        for(var i=0;i<len;i++){
            list = this[selectors[i]];
            if(list){
                list.deselectAll();
            }
        }
    },
    dateChange:function(tf){
        var datainicio = this.getDatainicio(),
            datafim = this.getDatafim(),
            di = datainicio.getValue(),
            df = datafim.getValue(),
            diff = Ext.Date.diff(new Date(di), new Date(df), Ext.Date.DAY),
            diffDays = 24 * 60 * 60 * 1000 * 7,
            newDate;



        if (diff < 0 || diff > 7) {
            if(datainicio == tf){
                newDate = Ext.Date.format(new Date(new Date(di).getTime()+diffDays), "Y-m-d H:i");
                datafim.setValue(newDate.replace(' ','T'));
            }
            else{
                newDate = Ext.Date.format(new Date(new Date(df).getTime()-diffDays), "Y-m-d H:i");
                datainicio.setValue(newDate.replace(' ','T'));
            }
        }

    }
});