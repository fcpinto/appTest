/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 19/09/13
 * Time: 15:30
 */
//Ext.data.proxy.Sql.prototype.config.tableExists = true;
Ext.LoadMask.prototype.config.message = '';

Ext.define('Manchete.controller.MancheteDB', {
    extend: 'Ext.app.Controller',

    requires:[
        'Manchete.util.MancheteSql'
    ],

    config: {
        refs: {

        },
        control: {

        }
    },
    init: function () {
        this.dbName = "MancheteDB";
        //this.db = openDatabase(this.dbName, "1.0", "Manchete Demo", 200000);
        this.db = window.rootdb;
        this.db.transaction(Ext.bind(this.populateDB, this), this.errorDB, this.successDB);
        Manchete.app.on('insertRecords', Ext.bind(this.insertRecords, this));
        Manchete.app.on('countTotalItems', Ext.bind(this.countTotalItems, this));
        Manchete.app.on('getTodayCovers', Ext.bind(this.getTodayCovers, this));
    },

    populateDB: function (tx) {

        // TO REMOVE - JUST FOR TEST!!!!
        /*if(document.location.search == '?drop=true'){
            tx.executeSql('DROP TABLE HEADLINES');
            tx.executeSql('DROP TABLE CLIPPING');
            tx.executeSql('DROP TABLE NEWS');
            localStorage.clear();
        }*/

        var stores = Manchete.app.getStores(),
            len = stores.length;
        for(var i=0; i<len; i++){
            if(stores[i].config.startTable == true){
                this.drawTable(tx, stores[i]);
            }
        }

    },

    /*
     success & error
     */
    errorDB: function () {
        //console.log('error DB');
        //console.log(arguments);
    },
    successDB: function () {
        //console.log('success DB');
    },

    /*
     INSERT OR IGNORE INTO TABLES
     */
    insertRecords: function (records, stName) {
        var me = this,
            st = Ext.getStore(stName),
            tb = st.getProxy().getTable(),
            placeholders = [],
            columns = [],
            rec = {};

        me.db.transaction(function (tx) {

            if(tb == 'CLIPPING' || tb == 'THEMES'){
                tx.executeSql('DELETE FROM ' + tb);
            }

            Ext.each(records, function (record) {
                rec = record.getData();
                placeholders = [];
                columns = [];
                for (var i in rec) {
                    columns.push(i);
                    placeholders.push(Ext.htmlEncode(rec[i]));
                }
                //console.log('INSERT OR IGNORE INTO '+tb+' (' + columns.join(',') + ') VALUES("' + placeholders.join('","') + '")');
                tx.executeSql('INSERT OR IGNORE INTO '+tb+' (' + columns.join(',') + ') VALUES("' + placeholders.join('","') + '")');
            });
            me.deleteRows(tx, tb, st);
            me.getAllProviders(tx, tb);
            st.load();
        }, me.errorDB, me.successDB);

        //this.dropTable('HEADLINES');
    },
    getAllProviders:function(tx, tb){
        if(tb == 'NEWS'){
            Manchete.app.allProviders = [];
            tx.executeSql('SELECT DISTINCT publicacao FROM NEWS', [], function(t, results){
                var len = results.rows.length;
                for (var i=0; i<len; i++){
                    Manchete.app.allProviders.push(results.rows.item(i).publicacao);
                }
            });
        }
    },
    deleteRows:function(tx, tb, st){
        if(tb == 'HEADLINES'){
            tx.executeSql('DELETE FROM HEADLINES WHERE data <= date("now", "-7 days")');
        }
        this.countTotalItems(st);
    },

    countTotalItems:function(store){
        //console.log('???????????????????????????????????');
        var table = store.getProxy().getTable();
        this.db.transaction(function (tx) {
            tx.executeSql('SELECT COUNT(*) FROM '+ table, [],

                function (tx, results) {
                    //console.log(results.rows.item(0)['COUNT(*)']);
                    store.countTotalItems = results.rows.item(0)['COUNT(*)'];
                })
        }, this.errorDB, this.successDB);
    },


    /*
     CREATE TABLES
     */
    createTable:function(store){
        var me = this;
        this.db.transaction(function(tx){
            me.drawTable(tx, store);
        }, this.errorDB, this.successDB);
    },
    drawTable: function (tx, store) {
        var table = store.getProxy().getTable();
        var model = store.getModel();
        //console.log('CREATE TABLE IF NOT EXISTS '+table+' (' + this.getSchemaString(model) + ')');
        //tx.executeSql('DROP TABLE '+table);
        tx.executeSql('CREATE TABLE IF NOT EXISTS '+table+' (' + this.getSchemaString(model) + ')');
        this.getAllProviders(tx, table);
    },
    getSchemaString: function (model) {
        var schema = [],
            fields = model.getFields().items,
            ln = fields.length,
            i, field, type, name;

        for (i = 0; i < ln; i++) {
            field = fields[i];
            name = field.getName();
            if(name === 'id'){
                type = 'unique';
                type = this.convertToSqlType(type);
                schema.unshift(name + ' ' + type);
            }
            else{
                type = field.getType().type;
                type = this.convertToSqlType(type);
                schema.push(name + ' ' + type);
            }

        }
        return schema.join(', ');
    },
    convertToSqlType: function (type) {
        switch (type.toLowerCase()) {
            case 'date':
            case 'string':
            case 'auto':
                return 'TEXT';
            case 'int':
                return 'INTEGER';
            case 'float':
                return 'REAL';
            case 'bool':
                return 'NUMERIC';
            case 'unique':
                return 'UNIQUE';
            default:
                return 'TEXT'
        }
    },


    dropTable:function(table){
        this.db.transaction(function(tx){
            tx.executeSql('DROP TABLE '+table);
        }, this.errorDB, this.successDB);
    },
    debuggingDB:function(query){
        this.db.transaction(function (tx) {
            tx.executeSql(query, [],

                function (tx, results) {
                    var len = results.rows.length;
                    for (var i = 0; i < len; i++) {
                        //console.log(results.rows.item(i));
                    }
                }

            );
        });
    },
    getFieldById:function(id, fields, callback, table){
        var tb = !table?'news':table;
        var query = 'select '+ fields +' from '+tb+' where id = "'+ id +'"';
        this.db.transaction(function (tx) {
            tx.executeSql(query, [],

                function (tx, results) {
                    callback(results.rows.item(0));
                }

            );
        });
    },
    updateRowById:function(result, callback, table){//UPDATE NEWS SET texto='abc' WHERE id='87844fe1-c5d0-4539-8099-87f4d9d8db93';

        /*
         update news set texto="Magistrados e inspetores..." where id = "04cfea78-d2a5-4d2c-b7f0-08bae890b880"
         update news set texto="abc",bold="false" where id = "72770076-93b7-4c9a-a28c-f18290ff772c"
         */

        var tb = !table?'news':table,
            id = result.id,
            query = '',
            fieldsAndValues = [];

        for(var i in result){
            fieldsAndValues.push(i + '="' + Ext.htmlEncode(result[i]) + '"');
        }
        query = 'update '+tb+' set '+ fieldsAndValues.join(',') +' where id = "'+ id +'"';
        console.log(query);
        this.db.transaction(function (tx) {
            tx.executeSql(query, [],

                function (tx, results) {
                    if(callback){
                        callback(results.rowsAffected);
                    }
                }

            );
        });
    },
    updateFieldById:function(id, field, value, callback, table){//UPDATE NEWS SET texto='abc' WHERE id='87844fe1-c5d0-4539-8099-87f4d9d8db93';
        var tb = !table?'news':table;
        var query = 'update '+tb+' set '+field+'="'+value+'" where id = "'+ id +'"';
        console.log(query)
        this.db.transaction(function (tx) {
            tx.executeSql(query, [],

                function (tx, results) {
                    if(callback){
                        callback(results.rowsAffected);
                    }
                }

            );
        });
    },
    updateFieldByIdFromData:function(data, field, value, callback, table){//UPDATE NEWS SET texto='abc' WHERE id='87844fe1-c5d0-4539-8099-87f4d9d8db93';
        var tb = !table?'news':table;
        var query = 'update '+tb+' set '+field+'="'+value+'" where id = "'+ data.id +'"';
        this.db.transaction(function (tx) {
            tx.executeSql(query, [],
                function (tx, results) {
                    data[field] = value;
                    callback(data);
                }

            );
        });
    },

    getTodayCovers:function(callback){
        this.db.transaction(function (tx) {
            tx.executeSql('select data,linkBig from headlines where data=(SELECT MAX(data) from headlines) and link != "" group by publicacao', [],
                function (tx, results) {
                    var len = results.rows.length,
                        data = [];
                    for(var i=0;i<len;i++){
                        data.push(results.rows.item(i));
                    }
                    callback(data);
                })
        }, this.errorDB, this.successDB);
    },
    deleteRowAndFile:function(record){

    }
});




/*
rootdb.transaction(function (tx) {
    var placeholders,columns;
    Ext.each(testeDeCarga, function (rec) {
        placeholders = [];
        columns = [];
        for (var i in rec) {
            columns.push(i);
            placeholders.push(Ext.htmlEncode(rec[i]));
        }
        //console.log('INSERT OR IGNORE INTO NEWS (' + columns.join(',') + ') VALUES("' + placeholders.join('","') + '")');
        tx.executeSql('INSERT OR IGNORE INTO NEWS (' + columns.join(',') + ') VALUES("' + placeholders.join('","') + '")');
    });
    Ext.getStore('News').load();
}, function(error){console.log(error)}, function(){console.log('success')});


Ext.data.JsonP.request({
    url: 'something.json',
    success: function(result, request) {
        console.log(result)
    }
});
*/