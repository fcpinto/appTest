/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 09/09/13
 * Time: 13:32
 */
Ext.define('Manchete.store.TextById', {
    extend: 'Ext.data.Store',

    requires: [
        'Ext.data.proxy.JsonP'
    ],

    config:{
        model:'Manchete.model.MediaType',

        proxy:{
            type:"jsonp",
            url: 'https://services.manchete.pt:8002/Clientes.asmx/getTextbyId',

            pageParam:false,
            limitParam:false,
            startParam:false
        }
    }
});
