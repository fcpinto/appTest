/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.FilterList', {
    extend: 'Ext.dataview.List',
    xtype: 'filterList',

    config: {
        modal: true,
        centered:true,
        hideOnMaskTap: true,
        hidden: true,
        width: !Ext.os.is.Phone? 400 : 260,
        height: !Ext.os.is.Phone? 400 : '70%',
        contentEl: 'content',
        styleHtmlContent: true,
        scrollable: true,
        store: '',
        mode:'MULTI',
        callback:'',
        itemTpl:Ext.create('Ext.XTemplate',
            '<span class="title">{text}</span><br>'
        )
    }
});