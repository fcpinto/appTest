Ext.define('Manchete.view.Main', {
    extend: 'Ext.Container',
    xtype: 'main',
    requires: [
        'Ext.navigation.View',
        'Ext.tab.Panel',
        'Ext.dataview.DataView',
        'Ext.dataview.List'
    ],
    config: {
        fullscreen:true,
        layout:!Ext.os.is.Phone?'hbox':'fit',/** testing here **/

        items:[
            {
                xtype:'titlebar',
                itemId:'mainToolbar',
                title:!Ext.os.is.Phone?'<img width="120px" height="24px" style="-webkit-transform: translateY(5px);" src="resources/images/logo4.png">':'',
                //cls:'main-toolbar',
                docked:'top',
                ui:'light',
                items:[
                    /*{
                        xtype:'button',
                        align:'left',
                        iconCls:'ss-list',
                        hidden:!Ext.os.is.Phone?true:false,
                        ui:'plain',
                        handler:function(){

                            if(!Ext.getCmp('m-menu').isHidden()){
                                Ext.getCmp('m-menu').hide();
                            }
                            else{
                                setTimeout(function(){Ext.getCmp('m-menu').show();},100);
                            }
                        }
                    },*/
                    /*{
                        xtype:'component',
                        padding:!Ext.os.is.Phone?'4 10 0 10':'4 10 0 0',
                        html:(!Ext.os.is.Phone?'':'<span style="font-family: iOSss; color: #ffffff;">M</span>')+'<img width="24px" height="24px" src="resources/images/lg.png">',//'<img width="120px" height="24px" src="resources/images/logo4.png">',
                        hidden:true,
                        listeners:{
                            tap:function(){
                                if(Ext.os.is.Phone){
                                    if(!Ext.getCmp('m-menu').isHidden()){
                                        Ext.getCmp('m-menu').hide();
                                    }
                                    else{
                                        setTimeout(function(){Ext.getCmp('m-menu').show();},100);
                                    }
                                }
                            },
                            element:'element'
                        }
                    },*/
                    {
                        xtype:'button',
                        iconCls:'ss-list',
                        align:'left',
                        ui:'plain',
                        hidden:!Ext.os.is.Phone?true:false,
                        whenHide:[!Ext.os.is.Phone?'always':'never'],
                        handler:function(){
                            if(Ext.os.is.Phone){
                                if(!Ext.getCmp('m-menu').isHidden()){
                                    Ext.getCmp('m-menu').hide();
                                }
                                else{
                                    setTimeout(function(){Ext.getCmp('m-menu').show();},100);
                                }
                            }
                        }
                    },
                    {
                        xtype:'button',
                        iconCls:'ss-grid',
                        align:'right',
                        ui:'plain',
                        action:'mancheteNews',
                        hidden:false,
                        whenHide:['mediaType','newsGrid','newsSearch','settingsView','userView','settingsView','infoView']
                    },
                    /*{
                        xtype:'button',
                        iconCls:'ss-rows',
                        align:'right',
                        ui:'plain',
                        action:'coverNews',
                        hidden:true,
                        whenHide:['manchetes','mediaType','newsGrid', 'headlinesFilters','newsSearch','settingsView','userView','settingsView','infoView']
                    },*/

                    /***********/
                    {
                        xtype:'button',
                        iconCls:!localStorage.manchetenewsview?'ss-rows':(localStorage.manchetenewsview=='mediaType'?'ss-grid':'ss-rows'),
                        align:'right',
                        ui:'plain',
                        action:'newsLayout',
                        hidden:true,
                        whenHide:['manchetes','manchetesCarousel','manchetesGrid','headlinesFilters','newsSearch','settingsView','userView','settingsView','infoView']
                    },
                    /***********/

                    {
                        xtype:'button',
                        iconCls:'ss-search',
                        align:'right',
                        ui:'plain',
                        action:'searchNews',
                        hidden:true,
                        whenHide:['manchetesCarousel','manchetes','manchetesGrid', 'headlinesFilters']
                    },
                    {
                        xtype:'button',
                        iconCls:'ss-filter',
                        align:'right',
                        ui:'plain',
                        action:'filterNews',
                        hidden:true,
                        whenHide:['manchetesCarousel','manchetesGrid','newsSearch','settingsView','userView','settingsView','infoView']
                    },
                    {
                        xtype:'button',
                        iconCls:'ss-refresh',
                        align:'right',
                        ui:'plain',
                        action:'refreshNews',
                        hidden:false,
                        whenHide:['never']
                    }
                ]
            },
            {
                xtype:'container',
                layout:'card',
                id:'contentView',
                style:!Ext.os.is.Phone?'box-shadow: -2px 0px 10px #333333;':'',
                flex:1,

                items:[
                    {
                        xtype:'manchetesGrid',
                        /*showAnimation: 'slide',
                        hideAnimation: {type: 'slide', out: true},
                        items:[
                            /*{
                                xtype:'titlebar',
                                title:'manchete <span style="font-family: iOSss; opacity: 0.8;">m</span>',
                                docked:'top',
                                ui:'light',
                                items:[
                                    {
                                        xtype:'button',
                                        align:'left',
                                        iconCls:'ss-list',
                                        hidden:!Ext.os.is.Phone?true:false,
                                        ui:'plain',
                                        handler:function(){

                                            if(!Ext.getCmp('m-menu').isHidden()){
                                                Ext.getCmp('m-menu').hide();
                                            }
                                            else{
                                                setTimeout(function(){Ext.getCmp('m-menu').show();},100);
                                            }
                                        }
                                    }
                                ]
                            },*/
                            /*{
                                xtype:'image',
                                centered:true,
                                width:174,
                                height:53,
                                src:'resources/images/manchete_logo.png'
                            }
                        ],*/
                        listeners:{
                            hide:function(view){
                                view.destroy();
                            }
                        }
                    }
                ]
            }
        ],
        listeners:{
            initialize: function (cmp) {
                if (!Ext.os.is.Phone) {
                    cmp.insert(0, {xtype: 'menuClipping'});
                }
                else {
                    cmp.add({xtype: 'menuClipping', hidden:true, style:'z-index:1; box-shadow: 2px 0px 10px #333333;'});
                }
            }
        }

    }
});

//
//Ext.Viewport.setMasked({xtype:'container',centered:true,modal:true,html:'<div class="rotationObj">X</div>'});
//
