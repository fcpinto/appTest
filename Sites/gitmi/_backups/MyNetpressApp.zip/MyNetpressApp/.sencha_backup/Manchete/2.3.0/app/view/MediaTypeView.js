/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 18/09/13
 * Time: 11:21
 */
Ext.define('Manchete.view.MediaTypeView', {
    extend: 'Ext.navigation.View',
    xtype: 'mediaType',

    config: {
        defaultBackButtonText:'',
        useTitleForBackButtonText: false,
        navigationBar:{
            cls:'mediaTypeNav',
            backButton:{
                iconCls:'ss-directleft',
                ui: 'plain'
            }
        },

        items:[
            {
                xtype:'list',
                cls: 'manchetes-list',

                selectedCls: '',
                padding: 0,
                margin: 0,
                styleHtmlContent: true,
                store: 'News',
                masked:{
                    xtype: 'loadmask'
                    //hidden:false
                },
                loadingText:' ',
                scrollable:{
                    direction:'vertical',
                    directionLock:true
                },
                scrollToTopOnRefresh:false,
                striped: true,
                //emptyText:'Não existem novas notícias...',
                itemTpl: Ext.os.is.Phone?Ext.create('Ext.XTemplate',
                    '<div class="boxPhone{[this.inHistory(values.link)]}">',
                    '   <div class="title bold{bold}">{titulo}</div>',
                    '   <div class="others">',
                    '       <div class="provider">{publicacao}</div>',
                    '       <div class="date">{data}</div>',
                    '       <div class="favorite{favorito} iconios"></div>',
                    '       <div class="share iconios"></div>',
                    '       <div class="{linkType}{downloaded} iconios files"></div>',
                    '   </div>',
                    '</div>',
                    '<div class="deleteBtn"></div>',
                    {
                        inHistory:function(vl){
                            return vl==''?' notInHistory':''
                        }
                    }
                ):Ext.create('Ext.XTemplate',
                    '<div class="box{[this.inHistory(values.link)]}">',
                    '   <div class="title bold{bold}">{titulo}</div>',
                    '       <div class="provider">{publicacao}</div>',
                    '       <div class="date">{data}</div>',
                    '       <div class="favorite{favorito} iconios"></div>',
                    '       <div class="share iconios"></div>',
                    '       <div class="{linkType}{downloaded} iconios files"></div>',
                    '</div>',
                    '<div class="deleteBtn"></div>',
                    {
                        inHistory:function(vl){
                            return vl==''?' notInHistory':''
                        }
                    }
                ),
                items:[
                    /*{
                        xtype:'component',
                        docked:'top',
                        itemId:'titleBar',
                        cls:'tabbar-list',
                        //style:'font-size: 0.7em;',
                        html:'&nbsp;'
                    },*/
                    {
                        xtype:'container',
                        style:'text-align:center; padding:10px 0 10px 0; background-color:#ffffff; color:#0775c1; font-family: iOSss;',
                        html:'6',
                        itemId:'toNext',
                        scrollDock:'bottom',
                        hidden:true,
                        listeners: {
                            tap: {
                                fn: function(){
                                    var list = this.up('list'),
                                        store = list.getStore(),
                                        totalItems = store.getProxy().totalItems,
                                        totalPages = Math.ceil(totalItems/store.getPageSize());

                                    list.setLoadingText(' ');

                                    if(store.currentPage < totalPages){
                                        list.setScrollToTopOnRefresh(true);
                                        //list.getScrollable().getScroller().scrollTo(0, 0);
                                        store.nextPage();
                                    }
                                },
                                element: 'element'
                            }
                        }
                    },
                    {
                        xtype:'container',
                        style:'text-align:center; padding:10px 0 10px 0; background-color:#ffffff; color:#0775c1; font-family: iOSss;',
                        html:'9',
                        itemId:'toPrev',
                        scrollDock:'top',
                        hidden:true,
                        listeners: {
                            tap: {
                                fn: function(){
                                    var list = this.up('list'),
                                        store = list.getStore(),
                                        currentPage = store.currentPage;

                                    list.setLoadingText(' ');

                                    if(currentPage > 1){
                                        store.previousPage();
                                    }
                                },
                                element: 'element'
                            }
                        }
                    }
                ],
                listeners:{
                    initialize:function(list){
                        list.config.title = list.getStore().title;
                        if(!list.getStore().isLoading()){
                            list.setMasked(false);
                        }
                    },
                    painted:{
                        buffer:500,
                        fn:function(el){
                            this.refresh();
                        }
                    },
                    refresh: function (list) {
                        var store = list.getStore(),
                            totalItems = store.getProxy().totalItems,
                            totalPages = Math.ceil(totalItems / store.getPageSize()),
                            currentPage = store.currentPage,
                            toPrev = list.down('#toPrev'),
                            toNext = list.down('#toNext');

                        toPrev.setHidden(currentPage <= 1);
                        toNext.setHidden(store.currentPage >= totalPages);
                        list.setScrollToTopOnRefresh(false);
                    }
                }
            }
        ],
        listeners:{
            initialize:function(nav){
                /*setTimeout(function(){
                    var titleBar = nav.down('#titleBar');
                    if(titleBar){
                        titleBar.setHtml(Ext.getCmp('m-menu').getSelection()[0].data.clipping)
                    }
                },100);*/
            },
            destroy:function(nav){
                //console.log(nav.config.cleanSearch);
                if(nav.config.cleanSearch){
                    Ext.getStore('SearchRemover').load();
                }
            }
        }

    }
});