/**
 * Created by zul on 16/10/13.
 */
Ext.define('Manchete.store.SearchRemover', {
    extend: 'Ext.data.Store',

    config: {
        model: 'Manchete.model.News',

        filters: [
            {
                property: 'link',
                value   : ''
            }
        ],
        pageSize:false,
        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'NEWS',
            enablePagingParams:false
        },
        listeners: {
            load: function (st, records, successful, operation) {
                //console.log('SearchRemover: ' + successful);
                //console.log(records);

                var len = records.length;
                for(var i = 0; i < len; i++){
                    st.remove(records[i])
                }
                st.sync();
            }
        }
    }
});