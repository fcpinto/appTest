/**
 * Created by zul on 06/11/13.
 */
Ext.define('Manchete.view.ShareNews', {
    extend: 'Ext.Panel',//'Ext.ActionSheets'
    xtype: 'shareNews',

    config: {
        //width:100,
        modal: true,
        centered:true,
        //right:0,
        hideOnMaskTap: true,
        hidden: true,
        style:'background-color:#ffffff;',
        layout:'hbox',
        showAnimation:'fade',
        items:[
            {
                xtype:'button',
                iconCls:'ss-facebook',
                ui:'plain',
                actions:'toFacebbok'
            },
            {
                xtype:'button',
                iconCls:'ss-twitter',
                ui:'plain',
                actions:'toTwitter'
            },
            {
                xtype:'button',
                iconCls:'ss-linkedin',
                ui:'plain',
                actions:'toLinkedin',
                hidden:true
            },
            {
                xtype:'button',
                iconCls:'ss-mail',
                ui:'plain',
                actions:'toMail'
            }
        ]
    }
});