/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.store.FilterPublicacao', {
    extend: 'Ext.data.Store',

    config: {
        fields:['publicacao', 'tipo',
            {
                name:'text',
                convert:function(vl,rec){
                    return rec.raw.publicacao;
                }
            },
            {
                name:'value',
                convert:function(vl,rec){
                    return rec.raw.publicacao;
                }
            }
        ],
        filters:[
            {
                property: 'ownQuery',
                value: 'SELECT DISTINCT publicacao FROM NEWS'
            }
        ],
        pageSize:false,
        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'NEWS',
            tableExists:true
        },
        listeners: {
            load: function (st, records, successful, operation) {

                /*if(records.length > 0){
                    st.insert(0, [
                        {
                            publicacao:'Todos',
                            tipo:'todos'
                        }
                    ])
                }*/
            }
        }

    }
});