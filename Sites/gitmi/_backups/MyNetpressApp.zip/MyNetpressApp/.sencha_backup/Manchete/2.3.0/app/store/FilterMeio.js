/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.store.FilterMeio', {
    extend: 'Ext.data.Store',

    config: {
        fields:[
            'id','tipo',
            {
                name:'text',
                convert:function(vl,rec){
                    return rec.raw.clipping;
                }
            },
            {
                name:'value',
                convert:function(vl,rec){
                    return rec.raw.referencia3;
                }
            }
        ],
        sorters:['priority', 'id'],
        filters:[
            {
                property:'activo',
                value:1
            }
        ],
        pageSize:false,
        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'CLIPPING',
            tableExists:true
        },
        listeners: {
            load: function (st, records, successful, operation) {
                /*if(records.length > 0){
                    st.insert(0, [
                        {
                            clipping:'Todos',
                            referencia3:'todos'
                        }
                    ])
                }*/
            }
        }

    }
});