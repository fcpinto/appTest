/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 09/09/13
 * Time: 13:32
 */
Ext.define('Manchete.store.UserThemes', {
    extend: 'Ext.data.Store',

    requires: [
        'Ext.data.proxy.JsonP'
    ],

    config:{
        model:'Manchete.model.UserThemes',

        //autoLoad:true,

        proxy:{
            type:"jsonp",
            url:'https://services.manchete.pt:8002/Clientes.asmx/getTemasbyUser',

            extraParams: {
                user: localStorage.mancheteuser,
                password: localStorage.manchetepass
            },
            pageParam:false,
            limitParam:false,
            startParam:false

        },

        listeners:{
            load:function (st, records, successful, operation) {
                //console.log('UserThemes: '+successful);
                if(successful){
                    //console.log(records);
                    Manchete.app.fireEvent('insertRecords', records, 'UserThemesTable');

                }
                else{
                    Ext.getStore('MenuClippingTable').load();
                    //console.log('error');
                }
            }
        }
    }
});
