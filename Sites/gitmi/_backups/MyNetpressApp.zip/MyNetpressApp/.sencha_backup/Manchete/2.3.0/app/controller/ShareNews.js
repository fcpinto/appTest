/**
 * Created by zul on 07/11/13.
 */
Ext.define('Manchete.controller.ShareNews',{
    extend:'Ext.app.Controller',

    config:{
        refs:{
            shareNews:'shareNews',
            facebook:'button[actions=toFacebbok]',
            twitter:'button[actions=toTwitter]',
            linkedin:'button[actions=toLinkedin]',
            mail:'button[actions=toMail]'
        },
        control:{
            'button[actions=toFacebbok]':{
                tap:'toFacebbok'
            },
            'button[actions=toTwitter]':{
                tap:'toTwitter'
            },
            'button[actions=toLinkedin]':{
                tap:'toLinkedin'
            },
            'button[actions=toMail]':{
                tap:'toMail'
            }
        }
    },
    init:function(){

    },
    toFacebbok:function(){
         //console.log('toFacebbok');
        var fbConnect = Manchete.app.getController('Facebook');
        fbConnect.getLoginFbStatus(Ext.bind(this.fbIsLogin,this),Ext.bind(this.fbIsLogout,this));
        this.hideSharePop();
    },
    fbIsLogin:function(fbConnect){
        //console.log('fbIsLogin');
        var me = this,
            data = me.getShareNews().getData();
        //console.log(Ext.htmlDecode(data.texto));
        fbConnect.publishToFB(data,function(){
            me.getShareNews().hide();
        });
    },
    fbIsLogout:function(fbConnect){
        fbConnect.startLogin();
    },
    toTwitter:function(btn){
        //console.log('toTwitter');

        if(Ext.browser.is.WebView){
            var shareNews = btn.up('shareNews'),
                data = shareNews.getData(),
                url = Ext.htmlDecode(data.link),
                text = Ext.htmlDecode(data.titulo) + '\n\nin ' + Ext.htmlEncode(data.publicacao) + ', ' + data.data,
                message = {
                    text: text,
                    url: url,
                    activityType: "PostToTwitter"//PostToTwitter,PostToFacebook,Mail
                };
            window.socialmessage.send(message);
        }
        this.hideSharePop();
    },
    toLinkedin:function(btn){
        //console.log('toLinkedin');
        this.hideSharePop();
    },
    toMail:function(btn){
        //console.log('toMail');
        if(Ext.os.is.iOS  && Ext.browser.is.WebView){
            var shareNews = btn.up('shareNews'),
                data = shareNews.getData(),
                title = 'Manchete: ' + Ext.htmlDecode(data.titulo),
                url = Ext.htmlDecode(data.link),
                text = ''+ Ext.htmlDecode(data.titulo) + '<br><br>' + Ext.htmlDecode(data.link) + '<br><br>in ' + Ext.htmlEncode(data.publicacao) + ', ' + data.data + '',
                message = {
                    text: text,
                    //url: url,
                    activityType: "Mail",//PostToTwitter,PostToFacebook,Mail
                    subject: title
                };
            window.socialmessage.send(message);
        }
        else{
            var shareNews = btn.up('shareNews'),
                data = shareNews.getData(),
                title = 'Manchete: ' + Ext.htmlDecode(data.titulo),
                body = Ext.htmlDecode(data.titulo)+'%0D%0A%0D%0A'+Ext.htmlDecode(data.link)+'%0D%0A%0D%0Ain '+ Ext.htmlEncode(data.publicacao) +', '+ data.data;

            window.location.href = "mailto:?subject="+title+"&body="+body;
        }
        this.hideSharePop();
    },
    hideSharePop:function(){
        if(Manchete.app.shareFromList){
            Manchete.app.shareFromList.hide();
        }
        if(Manchete.app.shareFromItem){
            Manchete.app.shareFromItem.hide();
        }
    }
})