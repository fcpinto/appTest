/**
 * Created by zul on 08/10/13.
 */
Ext.define('Manchete.controller.Login', {
    extend: 'Ext.app.Controller',

    config: {
        refs: {
            loginForm: 'loginForm formpanel',
            loginRemove: 'loginRemove formpanel'
        },
        control: {
            'button[action=login]': {
                tap: 'logintap'
            },
            'button[action=removerconta]': {
                tap: 'removerconta'
            },
            'button[action=confirmToRemove]': {
                tap: 'confirmToRemove'
            }
        }
    },
    init: function () {

    },
    logintap: function (btn) {
        var form = this.getLoginForm(),
            values = form.getValues(),
            store;

        if (values.user != '' && values.password != '') {

            if (this.isMail(values.user)) {
                store = Ext.getStore('Login');
                store.load({
                    params: values,
                    callback: Ext.bind(this.loginCallback, this)
                })
            }
            else {
                Ext.Msg.alert('Login', 'O seu e-mail não é válido.', Ext.emptyFn);
            }
        }
        else {
            Ext.Msg.alert('Login', 'Os dois campos são obrigatórios', Ext.emptyFn);
        }
    },
    loginCallback: function (records, operation, success) {
        //console.log('Login');
        //console.log(records);
        if (success) {
            if (records.length > 0) {
                var login = records[0].data.login;

                if (login == '2') {
                    var form = this.getLoginForm(),
                        values = form.getValues();
                    localStorage.mancheteuser = values.user;
                    localStorage.manchetepass = values.password;
                    localStorage.manchetemaxhistory = 30;

                    //Manchete.app.getController('Main').fromLogin = true;
                    Ext.getStore('MenuClipping').load({
                        params: {
                            user: localStorage.mancheteuser,
                            password: localStorage.manchetepass
                        }
                    });

                    Ext.getStore('UserThemes').load({
                        params: {
                            user: localStorage.mancheteuser,
                            password: localStorage.manchetepass
                        }
                    });
                    form.up('container').hide();

                    localStorage.mancheteuserdetails = JSON.stringify(records[0].raw);
                    Manchete.app.fireEvent('insertRecords', records, 'UserDetails');

                }
                else if (login == '1') {
                    Ext.Msg.alert('Login', 'O seu utilizador não dispõe de acesso ao "MyNetpress Pocket". Por favor contacte o seu gestor de contrato.', Ext.emptyFn);
                }
                else {
                    Ext.Msg.alert("Login", "Nome de utilizador ou palavra passe errados.", Ext.emptyFn);
                }
            }
        }
        else {
            Ext.Msg.alert("Internet", "Não tem ligação à internet!", Ext.emptyFn);
        }
        /*if(operation.error != 'error'){
         if(operation.getResponse() == 'true'){
         var form = this.getLoginForm(),
         values = form.getValues();

         localStorage.mancheteuser = values.user;
         localStorage.manchetepass = values.password;
         Ext.getStore('MenuClipping').load({
         params:{
         user: localStorage.mancheteuser,
         password: localStorage.manchetepass
         }
         });

         Ext.getStore('UserThemes').load({
         params:{
         user: localStorage.mancheteuser,
         password: localStorage.manchetepass
         }
         });
         form.up('container').hide();
         }
         else{
         Ext.Msg.alert("Login","Nome de utilizador ou palavra passe errados.", Ext.emptyFn);
         }
         }
         else{
         Ext.Msg.alert("Internet", "Não tem ligação à internet!", Ext.emptyFn);
         }*/

    },
    isMail: function (mail) {
        var emailRegEx = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;

        return mail.search(emailRegEx) != -1 ? true : false;
    },
    removerconta:function(btn){
        if(!this.loginForm){
            this.loginForm = Ext.Viewport.add({xtype:'loginRemove'});
        }
        this.loginForm.show();
    },
    confirmToRemove:function(){

        var form = this.getLoginRemove(),
            values = form.getValues(),
            store;

        if (values.user != '' && values.password != '') {

            if (this.isMail(values.user)) {
                if (values.user == localStorage.mancheteuser && values.password == localStorage.manchetepass) {
                    this.lastConfirmation();
                }
                else {
                    Ext.Msg.alert("Login", "Nome de utilizador ou palavra passe errados.", Ext.emptyFn);
                }
            }
            else {
                Ext.Msg.alert('Login', 'O seu e-mail não é válido.', Ext.emptyFn);
            }
        }
        else {
            Ext.Msg.alert('Login', 'Os dois campos são obrigatórios', Ext.emptyFn);
        }
    },
    lastConfirmation:function(){
        Ext.Msg.confirm("Confirmação", "Tem a certeza que pretende remover todos os seus dados e reiniciar a aplicação?", function (btn) {
            if (btn == 'yes') {

                rootdb.transaction(function (tx) {
                    tx.executeSql('DROP TABLE IF EXISTS HEADLINES');
                    tx.executeSql('DROP TABLE IF EXISTS CLIPPING');
                    tx.executeSql('DROP TABLE IF EXISTS NEWS');
                    tx.executeSql('DROP TABLE IF EXISTS THEMES');
                    tx.executeSql('DROP TABLE IF EXISTS NEWSSEARCH');
                    tx.executeSql('DROP TABLE IF EXISTS USERDETAILS');
                    localStorage.clear();
                    document.location.reload(true);
                }, function (error) {
                });
            }
        });
    },
    teste: function () {
        console.log('ashakhdahdkshdkahsdkjahsdkhaskjahsdjkhsadkj');
            //var menu = Ext.getCmp('m-menu');
            //Manchete.app.getController('Main').onMenuItemtap(menu,null,null,menu.getSelection()[0]);
    }
});