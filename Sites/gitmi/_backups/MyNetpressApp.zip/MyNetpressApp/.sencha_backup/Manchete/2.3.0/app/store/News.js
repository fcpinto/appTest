/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 09/09/13
 * Time: 13:32
 */
Ext.define('Manchete.store.News', {
    extend: 'Ext.data.Store',

    config: {
        model: 'Manchete.model.News',
        sorters:[{property:'data',direction:'DESC'}],

        pageSize: 25,
        startTable:true,
        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'NEWS'
            //,pageParam:false
        },
        listeners: {
            beforeload: function (store, operation) {
                //console.log(store.getData().items);
            },
            load: function (st, records, successful, operation) {
                //console.log('NEWS: ' + successful);
                //console.log(records);
            }
        }
    }
});
