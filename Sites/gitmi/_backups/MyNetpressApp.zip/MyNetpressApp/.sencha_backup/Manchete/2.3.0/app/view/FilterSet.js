/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.FilterSet', {
    extend: 'Ext.Container',
    xtype: 'filterSet',

    config: {
        defaults:{
            margin:'0 0 10 0'
        },
        items:[
            {
                xtype: 'textfield',
                itemId: 'meio',
                label: 'Meio',
                name: 'meioString',
                st:'FilterMeio',
                readOnly: true
            },
            {
                xtype: 'hiddenfield',
                name: 'meio'
            },
            {
                xtype: 'textfield',
                itemId: 'publicacao',
                label: 'Publicação',
                name: 'pubString',
                st:'FilterPublicacao',
                readOnly: true
            },
            {
                xtype: 'hiddenfield',
                name: 'publicacao'
            },
            {
                xtype: 'textfield',
                itemId: 'tema',
                label: 'Temas',
                name: 'temaString',
                st:'FilterTema',
                readOnly: true
            },
            {
                xtype: 'hiddenfield',
                name: 'tema'
            }
        ]
    }
});