/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.FilterPublicacao', {
    extend: 'Manchete.view.FilterMeio',
    xtype: 'filterPublicacao',

    config: {
        store: 'FilterPublicacao',
        listeners:{
            initialize:function(){

            },
            itemtap:{
                fn: function (list, index, target, record, e) {

                    /*var refs = [],
                        selection,
                        len;

                    if(record.data.text == 'Todos'){
                        if(list.isSelected(record)){
                            list.selectAll();
                        }
                        else{
                            list.deselectAll();
                        }
                    }
                    else{
                        list.deselect(0);
                    }

                    selection = list.getSelection();
                    len = selection.length;

                    for (var i = 0; i < len; i++) {
                        if(selection[i].data.value != 'Todos'){
                            refs.push(selection[i].data.value);
                        }
                    }
                    list.form.setValues({
                        pubString:len==1?selection[0].data.text:len==0?'':'vários',
                        publicacao:len==0?'':'"'+refs.join('","')+'"'
                    });*/

                },
                buffer:100
            }
        }
    }
});