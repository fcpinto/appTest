/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.FilterTema', {
    extend: 'Manchete.view.FilterMeio',
    xtype: 'filterTema',

    config: {
        store: 'FilterTema',
        listeners:{
            initialize:function(){

            },
            itemtap:{
                fn: function (list, index, target, record, e) {

                    /*var refs = [],
                        selection,
                        len;

                    if(record.data.text == 'Todos'){
                        if(list.isSelected(record)){
                            list.selectAll();
                        }
                        else{
                            list.deselectAll();
                        }
                    }
                    else{
                        list.deselect(0);
                    }

                    selection = list.getSelection();
                    len = selection.length;

                    for (var i = 0; i < len; i++) {
                        if(selection[i].data.value != 'todos'){
                            refs.push(selection[i].data.value);
                        }
                    }
                    list.form.setValues({
                        temaString:len==1?selection[0].data.text:len==0?'':'vários',
                        tema:len==0?'':'tema LIKE "%'+refs.join('%" OR tema LIKE "%')+'%"'
                    });*/

                },
                buffer:100
            }
        }
    }
});