/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.store.FilterMeio', {
    extend: 'Ext.data.Store',

    config: {
        fields:[
            'id','marcador',
            {
                name:'text',
                convert:function(vl,rec){
                    return rec.raw.clipping;
                }
            },
            {
                name:'value',
                convert:function(vl,rec){
                    return rec.raw.referencia3;
                }
            }
        ],
        sorters:['marcador', 'id'],
        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'CLIPPING',
            tableExists:true
        },
        listeners: {
            load: function (st, records, successful, operation) {
                if(records.length > 0){
                    st.insert(0, [
                        {
                            clipping:'Todos',
                            referencia3:'todos'
                        }
                    ])
                }
            }
        }

    }
});