/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.CarouselTest', {
    extend: 'Ext.Carousel',
    xtype: 'carouselTest',

    config: {
        defaults: {
            styleHtmlContent: true
        },
        activeItem:1,

        items: [
            {
                html : 'Item 1',
                style: 'background-color: #5E99CC'
            },
            {
                html : 'Item 2',
                style: 'background-color: #759E60'
            },
            {
                html : 'Item 3'
            }
        ],
        listeners:{
            activeitemchange:function(cmp){
                console.log(cmp.innerItems);
                //alert(cmp.animationDirection==1?'left':'right');
                if(cmp.animationDirection==-1){
                    cmp.add({
                        html : 'Item 2',
                        style: 'background-color: '+'#'+(0x1000000+(Math.random())*0xffffff).toString(16).substr(1,6)
                    })
                    cmp.innerItems[0].destroy()
                }
                else{
                    cmp.insert(0, {
                        html : 'Item 2',
                        style: 'background-color: '+'#'+(0x1000000+(Math.random())*0xffffff).toString(16).substr(1,6)
                    })
                    cmp.innerItems[cmp.innerItems.length-1].destroy()
                }
            }
        }
    }
});