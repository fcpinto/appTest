/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.NewsFilters', {
    extend: 'Ext.form.Panel',
    xtype: 'newsFilters',

    config: {
        styleHtmlContent: true,
        style: 'background:#ffffff;',
        defaults:{
            margin:'0 0 10 0'
        },
        items: [
            {
                xtype: 'textfield',
                itemId: 'meioSelector',
                label: 'Meio',
                name: 'refString',
                readOnly: true,
                listeners: {
                    element: 'element',
                    tap: function () {
                        if(!Manchete.app.filterMeio){
                            Manchete.app.filterMeio = Ext.Viewport.add({
                                xtype:'filterMeio'
                            })

                        }
                        Manchete.app.filterMeio.form = this.up('formpanel');
                        Manchete.app.filterMeio.show();
                    }
                }

            },
            {
                xtype: 'hiddenfield',
                name: 'referencia3'
            },
            {
                xtype: 'textfield',
                itemId: 'pubSelector',
                label: 'Publicação',
                name: 'pubString',
                readOnly: true,
                listeners: {
                    element: 'element',
                    tap: function () {
                        if(!Manchete.app.filterPublicacao){
                            Manchete.app.filterPublicacao = Ext.Viewport.add({
                                xtype:'filterPublicacao'
                            })
                        }
                        Manchete.app.filterPublicacao.form = this.up('formpanel');
                        Manchete.app.filterPublicacao.show();
                    }
                }

            },
            {
                xtype: 'hiddenfield',
                name: 'publicacao'
            },
            {
                xtype: 'textfield',
                itemId: 'temaSelector',
                label: 'Temas',
                name: 'temaString',
                readOnly: true,
                listeners: {
                    element: 'element',
                    tap: function () {
                        if(!Manchete.app.filterTema){
                            Manchete.app.filterTema = Ext.Viewport.add({
                                xtype:'filterTema'
                            })
                        }
                        Manchete.app.filterTema.form = this.up('formpanel');
                        Manchete.app.filterTema.show();
                    }
                }
            },
            {
                xtype: 'hiddenfield',
                name: 'tema'
            },
            {
                xtype: 'sliderfield',
                label: 'Dias: 7',
                value: 7,
                minValue: 1,
                maxValue: 30,
                name:'days',
                listeners: {
                    change: function (cmp, sl, thumb, newValue, oldValue) {
                        /*cmp.up('newsFilters').setValues({
                         dias:newValue
                         });*/
                        cmp.setLabel('Dias: ' + newValue);
                    }
                }
            },
            {
                xtype: 'button',
                text: 'Filtrar',
                ui: 'action',
                margin: 5,
                padding: 10,
                docked: 'bottom',
                handler: function (btn) {
                    var form = btn.up('formpanel'),
                        isFavorites = form.config.isFavorites,
                        tipo = form.getValues().referencia3,
                        publicacao = form.getValues().publicacao,
                        tema =  form.getValues().tema,
                        days = form.getValues().days[0],
                        array = [],
                        store = Ext.getStore('News'),
                        nav = btn.up('navigationview');

                    if (isFavorites) {
                        array.push('favorito = 1');
                    }
                    if (tipo != '') {
                        array.push('tipo IN (' + tipo + ')');
                    }
                    if (publicacao != '') {
                        array.push('publicacao IN (' + publicacao + ')');
                    }
                    if (tema != ''){
                        array.push(tema)
                    }
                    array.push('data >= date("now","-' + days + ' days")');

                    //console.log('SELECT * FROM NEWS WHERE ' + array.join(' AND ') + ' ORDER BY data DESC LIMIT 0, 25');

                    store.setFilters([
                        {
                            property: 'ownQuery',
                            value: 'SELECT * FROM NEWS WHERE ' + array.join(' AND ') + ' ORDER BY data DESC LIMIT 0, 25'
                        }
                    ]);
                    store.load();
                    nav.reset();
                }
            }
        ]

    }
});
