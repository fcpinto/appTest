/**
 * Created by zul on 08/10/13.
 */
Ext.define('Manchete.controller.NewsFilters', {
    extend: 'Ext.app.Controller',

    config: {
        refs: {

        },
        control: {

        }
    },
    init: function () {

    }
});