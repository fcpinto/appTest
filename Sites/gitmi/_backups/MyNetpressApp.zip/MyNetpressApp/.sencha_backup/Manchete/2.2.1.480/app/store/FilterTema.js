/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.store.FilterTema', {
    extend: 'Ext.data.Store',

    config: {
        autoLoad:true,
        fields:['tema', 'referencia4',
            {
                name:'text',
                convert:function(vl,rec){
                    return rec.raw.tema;
                }
            },
            {
                name:'value',
                convert:function(vl,rec){
                    return rec.raw.referencia4;
                }
            }
        ],
        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'THEMES',
            tableExists:true
        },
        listeners: {
            load: function (st, records, successful, operation) {
                 console.log(records)
                if(records.length > 0){
                    st.insert(0, [
                        {
                            tema:'Todos',
                            referencia4:'todos'
                        }
                    ])
                }
            }
        }

    }
});