/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 17/09/13
 * Time: 00:52
 */
Ext.define('Manchete.model.MenuClipping', {
    extend: 'Ext.data.Model',

    config: {
        fields:[
            'id',
            {
                name: 'clipping',
                convert: function (vl) {
                    if (vl.lastIndexOf('Imprensa Nacional - Jornais') > -1) {
                        vl = 'Nacional - Jornais';
                    }
                    if (vl.lastIndexOf('Imprensa Nacional - Revistas') > -1) {
                        vl = 'Nacional - Revistas';
                    }
                    if (vl.lastIndexOf('Imprensa Regional') > -1) {
                        vl = 'Regional';
                    }
                    if (vl.lastIndexOf('Imprensa Internacional') > -1) {
                        vl = 'Internacional';
                    }

                    return vl;
                }
            },
            'activo',
            'referencia3',
            {
                name:'marcador',
                mapping:'clipping',
                convert:function(vl){

                    var marcador = 'Mais';
                    if (vl == "Imprensa Nacional - Jornais") {
                        marcador = ' Imprensa Escrita';
                    }
                    else if (vl == "Imprensa Nacional - Revistas") {
                        marcador = ' Imprensa Escrita';
                    }
                    else if (vl == "Imprensa Regional") {
                        marcador = ' Imprensa Escrita';
                    }
                    else if (vl == "Imprensa Internacional") {
                        marcador = ' Imprensa Escrita';
                    }
                    else if (vl == "Internet") {
                        marcador = 'Online';
                    }
                    else if (vl == "Televisão") {
                        marcador = 'Audiovisuais';
                    }
                    else if (vl == "Rádio") {
                        marcador = 'Audiovisuais';
                    }
                    else if (vl == "Alinhamentos") {
                        marcador = 'Audiovisuais';
                    }
                    else if (vl == "Blogs") {
                        marcador = 'Online';
                    }
                    else if (vl == "Redes Sociais") {
                        marcador = 'Online';
                    }

                    return marcador;
                }
            }
        ]
    }
});