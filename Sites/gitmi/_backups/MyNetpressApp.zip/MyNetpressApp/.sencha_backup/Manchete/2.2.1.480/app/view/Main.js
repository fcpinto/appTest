Ext.define('Manchete.view.Main', {
    extend: 'Ext.Container',
    xtype: 'main',
    requires: [
        'Ext.navigation.View',
        'Ext.tab.Panel',
        'Ext.dataview.DataView',
        'Ext.dataview.List'
    ],
    config: {
        fullscreen:true,
        layout:!Ext.os.is.Phone?'hbox':'fit',/** testing here **/

        items:[
            {
                xtype:'container',
                layout:'card',
                id:'contentView',
                style:!Ext.os.is.Phone?'box-shadow: -2px 0px 10px #333333;':'',
                flex:1,

                items:[
                    {
                        xtype:'container',
                        showAnimation: 'slide',
                        hideAnimation: {type: 'slide', out: true},
                        items:[
                            {
                                xtype:'titlebar',
                                title:'Manchete',
                                docked:'top',
                                ui:'light',
                                items:[
                                    {
                                        xtype:'button',
                                        align:'left',
                                        iconCls:'list',
                                        hidden:!Ext.os.is.Phone?true:false,
                                        ui:'plain',
                                        handler:function(){

                                            if(!Ext.getCmp('m-menu').isHidden()){
                                                Ext.getCmp('m-menu').hide();
                                            }
                                            else{
                                                setTimeout(function(){Ext.getCmp('m-menu').show();},100);
                                            }
                                        }
                                    }
                                ]
                            },
                            {
                                xtype:'image',
                                centered:true,
                                width:174,
                                height:53,
                                src:'http://www.mynetpress.com/site/images/logo.png'
                            }
                        ],
                        listeners:{
                            hide:function(view){
                                view.destroy();
                            }
                        }
                    }
                ]
            }
        ],
        listeners:{
            initialize: function (cmp) {
                if (!Ext.os.is.Phone) {
                    cmp.insert(0, {xtype: 'menuClipping'});
                }
                else {
                    cmp.add({xtype: 'menuClipping', hidden:true, style:'box-shadow: 2px 0px 10px #333333;'});
                }
            }
        }

    }
});