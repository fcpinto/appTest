/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 26/08/13
 * Time: 20:20
 */
Ext.define('Manchete.controller.Main', {
    extend: 'Ext.app.Controller',

    requires: [
        'Ext.Img',
        'Ext.field.Slider',
        'Ext.form.Panel',
        'Ext.field.Select',
        'Ext.field.Hidden',
        'Ext.Anim'
    ],

    config: {
        refs: {
            menu: 'menuClipping',
            contentView: '#contentView',
            mediaType:'mediaType',
            ordinaryNav:'ordinaryNav',
            mancheteList:'manchetes',
            filterField:'newsFilters'
        },
        control: {
            menu: {
                initialize: 'onInitialize',
                itemtap: 'onMenuItemtap'
            },
            mediaType: {
                itemtap: 'onMediaItemtap',
                itemswipe:'onMediaItemswipe'
            },
            contentView: {
                add: 'onAdd'
            },
            'button[action=openFilters]': {
                tap: 'openFilters'
            },
            'button[action=changeManchetesView]': {
                tap: 'changeManchetesView'
            },
            mancheteList:{
                itemtap:'onMancheteItemtap'
            }
        }
    },
    init: function () {
        this.navigationButtons = {
            historico:{
                iconCls:'ss-filter',
                xtype:'newsFilters',
                title:'Filtros',
                action:'openFilters',
                isFavorites:false
            },
            favorito:{
                iconCls:'ss-filter',
                xtype:'newsFilters',
                title:'Filtros',
                action:'openFilters',
                isFavorites:true
            },
            manchetes:{
                iconCls:'ss-target',
                xtype:'manchetes',
                title:'Manchetes',
                action:'changeManchetesView'
            },
            manchetesCarousel:{
                iconCls:'ss-rows',
                xtype:'manchetesCarousel',
                title:'Manchetes',
                action:'changeManchetesView'
            }
        }
    },
    onInitialize: function (menu) {

        if (!Ext.os.is.Phone === false) {
            this.getContentView().element.on('tap', function (view) {
                if (!Ext.getCmp('m-menu').isHidden()) {
                    Ext.getCmp('m-menu').hide();
                }
            });
            this.getContentView().element.on('swipe', function (evt, node) {
                if (evt.direction === 'right' && evt.startX < 50) {
                    Ext.getCmp('m-menu').show();
                }
                if (evt.direction === 'left') {
                    Ext.getCmp('m-menu').hide();
                }
            });
        }

        //this.getContentView().setActiveItem({xtype:'carouselTest'})
    },
    onMenuItemtap: function (list, index, target, record) {
        var me = this;

        if (record.data.activo != '2') {
            var lastTime = localStorage['mancheteLastTime' + record.data.referencia3],
                sevenDays = 24 * 60 * 60 * 1000 * 7,
                datafim = new Date(),
                datainicio = new Date(!lastTime ? datafim.getTime() - sevenDays : lastTime),
                store = Ext.getStore('MediaType'),
                localstore = Ext.getStore('News');

            if ((datafim.getTime() - datainicio.getTime()) >= sevenDays) {
                datainicio.setTime(datafim.getTime() - sevenDays);
            }
            console.log(Ext.Date.format(datainicio, 'Y-m-d H:i'));
            console.log(Ext.Date.format(datafim, 'Y-m-d H:i'));

            localstore.removeAll();
            if (record.data.activo == '1') {
                localstore.setFilters([
                    {
                        property: 'tipo',
                        value: record.data.referencia3
                    }
                ]);
                store.load({
                    params: {
                        user: 'pgeraldes@mobinteg.com',
                        password: 'Pass123',
                        datainicio: Ext.Date.format(datainicio, 'Y-m-d H:i'),//Ext.Date.format(dt, 'm-d-Y'),
                        datafim: Ext.Date.format(datafim, 'Y-m-d H:i'),//Ext.Date.format(new Date(), 'm-d-Y'),
                        referencia3: record.data.referencia3
                    }
                });
            }
            else if (record.data.activo == '0') {
                localstore.setFilters(record.data.referencia3 == 'favorito' ? [
                    {
                        property: 'favorito',
                        value: 1
                    }
                ] : []);
                localstore.load();
            }
        }

        Ext.getCmp('contentView').setActiveItem({
            xtype: 'ordinaryNav',
            items: [
                {
                    xtype: record.data.activo == '2' ? record.data.referencia3 : 'mediaType',
                    title: record.data.clipping
                }
            ],
            listeners: {
                initialize: function (nav) {
                    var details = me.navigationButtons[record.data.referencia3];
                    if (!details == false) {
                        nav.getNavigationBar().add({
                            xtype: 'button',
                            align: 'right',
                            iconCls: details.iconCls,
                            text: ' ',
                            ui: 'plain',
                            myNav: nav,
                            details: details,
                            action: details.action
                        });
                    }

                }
            }
        });

        if (!Ext.os.is.Phone === false) {
            Ext.getCmp('m-menu').hide();
        }

    },
    changeManchetesView: function (btn) {
        var me = this,
            details = me.navigationButtons[btn.config.details.xtype == 'manchetes'?'manchetesCarousel':'manchetes'];
        Ext.getCmp('contentView').setActiveItem({
            xtype: 'ordinaryNav',
            items: [
                {
                    xtype: details.xtype,
                    title: 'Manchetes'
                }
            ],
            listeners: {
                initialize: function (nav) {
                    //var details = me.navigationButtons[record.data.referencia3];
                    if(!details == false){
                        nav.getNavigationBar().add({
                            xtype: 'button',
                            align: 'right',
                            iconCls: details.iconCls,
                            text: ' ',
                            ui: 'plain',
                            myNav:nav,
                            details:details,
                            action:details.action
                        });
                    }

                }
            }
        });
    },
    openFilters: function (btn) {
        var details = btn.config.details;
        btn.up('navigationview').push({
            xtype:details.xtype,
            title:details.title,
            isFavorites:details.isFavorites
        });
    },
    onAdd: function (cmp, newView) {
        window.newView = newView
        if (!Ext.os.is.android) {
            newView.setShowAnimation('slide');
            newView.setHideAnimation({type: 'slide', out: true});
        }

        newView.on('hide', function (view) {
            view.destroy();
        });
    },
    onMancheteItemtap:function(dv, index, target, record, e) {
        //console.log(record)
        /*var ref = window.open('photoHolder.html?'+record.data.linkBig, '_blank', 'location=no,toolbar=no,transitionstyle=fliphorizontal');
         ref.addEventListener('loadstart', function(event) {
         if(event.url.split('?')[1] == 'done'){
         ref.close();
         }
         });*/
        window.open(record.data.linkBig, '_blank', 'location=no,toolbar=yes,transitionstyle=fliphorizontal,EnableViewPortScale=yes');

    },
    onMediaItemtap: function (list, idx, el, record, e) {
        var node = e.target;
        //console.log(node.className)
        if (node.className.indexOf('file') > -1) {
            //console.log(Ext.htmlDecode(record.data.link));
            //window.open(Ext.htmlDecode(record.data.link), '_blank', 'location=yes');
            //window.open(Ext.htmlDecode(record.data.link), '_blank', 'location=no,toolbar=yes,transitionstyle=fliphorizontal');
            var ref = window.open(Ext.htmlDecode(record.data.link), '_blank', 'location=yes,EnableViewPortScale=yes');
            ref.addEventListener('exit', function(event) {
                Manchete.app.getController('MancheteDB').db = rootdb;
            });
        }
        else if (node.className.indexOf('favoriteYes') > -1) {
            //node.className = "favoriteNo";
            record.set('favorito', 0);
            record.setDirty();
            list.getStore().sync();
        }
        else if (node.className.indexOf('favoriteNo') > -1) {
            //node.className = "favoriteYes";
            record.set('favorito', 1);
            record.setDirty();
            list.getStore().sync();
        }
        else{
            var data = record.data;
            data.idx = idx;
            data.store = list.getStore();
            /*list.up('navigationview').push({
                xtype:'newsItem',
                title:data.publicacao,
                data:data
            });*/

            /*console.log(idx)
            var allData = list.getStore().getData().items,
                len = allData.length,
                idx = idx- 1,
                newItems = [],
                dt;

            for(var i=0;i<3;i++){

                if(!allData[idx+i] == false){
                    dt = allData[idx+i].data;
                    dt.idx = idx+i;
                    newItems.push({
                        xtype:'newsItemCarousel',
                        data:dt
                    })
                }
            }

            list.up('navigationview').push({
                xtype:'container',
                layout:'card',
                items:[
                    {
                        xtype:'newsCarousel',
                        //title:data.publicacao,
                        st:list.getStore(),
                        activeItem: 1,
                        items:newItems
                    }
                ]

            });*/
            /***** WORKING WELL ******/
            list.up('navigationview').push({
                xtype:'container',
                layout:'card',
                items:[
                    {
                        xtype:'newsItem',
                        title:data.publicacao,
                        data:data
                    }
                ]

            });
        }
    },
    onMediaItemswipe:function(list, index, target, record, e){
        if (e.direction == "left") {



            var del = Ext.create("Ext.Button", {
                ui: "decline",
                text: "Remover",
                height: 40,
                cls:'deleteItem',
                style: 'position:absolute; top:50%; right:0; margin:-20px 5px; border:none;',
                showAnimation:{
                    duration: 300,
                    easing: 'ease-out',
                    type: 'slide'
                },
                hidden:true,
                handler: function() {
                    var store = record.stores[0];
                    store.remove(record);
                    store.sync();
                }
            });
            var removeDeleteButton = function() {
                console.log('removeDeleteButton')
                del.destroy();
            };

            del.renderTo(target.element);
            del.show();
            list.on({
                single: true,
                buffer: 250,
                itemtouchstart: removeDeleteButton
            });
            list.element.on({
                single: true,
                buffer: 250,
                touchstart: removeDeleteButton
            });

        }
        /*********** TESTE ************/
        /*else{
            var iDiv = document.createElement('div');
            iDiv.className = 'remover';
            iDiv.style.height = '40px';
            iDiv.style.backgroundColor = '#ff0000';
            iDiv.style.position = 'absolute';
            iDiv.style.top = '50%';
            iDiv.style.left = '5px';
            iDiv.style.margin = '-20px 5px';
            iDiv.innerHTML = 'Remover';
            target.element.dom.appendChild(iDiv);

            var removeDeleteButton2 = function() {
                if(iDiv.parentNode != null){
                    iDiv.parentNode.removeChild(iDiv);
                }
            };

            list.on({
                single: true,
                buffer: 250,
                itemtouchstart: removeDeleteButton2
            });
            list.element.on({
                single: true,
                buffer: 250,
                touchstart: removeDeleteButton2
            });
        }*/

    }
});


