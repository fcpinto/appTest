/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 17/09/13
 * Time: 00:52
 */
Ext.define('Manchete.model.HeadlinesTable', {
    extend: 'Ext.data.Model',

    config: {
        fields: [
            {
                name:'id',
                type:'int'
            },
            {
                name: 'guid',
                type: 'int'
            },
            'titulo',
            'publicacao',
            {
                name:'data',
                convert:function(vl){
                    var dt = new Date(vl);
                    return Ext.Date.format(dt, 'd-m-Y');
                }
            },
            'link',
            'linkBig',
            'photo'
        ],
        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'HEADLINES'
        }
    }
});