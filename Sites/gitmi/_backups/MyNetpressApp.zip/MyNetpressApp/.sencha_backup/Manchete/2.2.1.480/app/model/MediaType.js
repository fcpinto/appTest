/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 17/09/13
 * Time: 00:52
 */
Ext.define('Manchete.model.MediaType', {
    extend: 'Ext.data.Model',

    config: {
        fields: [
            'id',
            'titulo',
            'publicacao',
            'suplemento',
            'tipo',
            'tema',
            'link',
            {
                name:'linkType',
                mapping:'tipo',
                convert:function(vl, rec){
                    if(rec.raw.link != ''){
                        if(vl[0] == 'j'){
                            return 'pdf'
                        }
                        else if(vl[0] == 'r'){
                            return 'audio'
                        }
                        else if(vl[0] == 't'){
                            return 'video'
                        }
                    }
                    return 'site';
                }
            },
            {
                name:'data',
                convert:function(vl){
                    var str = vl.split(' ')[0];
                    return str;
                }
            },
            {
                name:'data_insercao',
                convert:function(vl){
                    var str = vl.split(' ')[0];
                    return str;
                }
            },
            'hora_insercao',
            'jornalista',
            'paginas',
            'duracoes',
            'texto',
            {
                name:'favorito',
                type:'int',
                allowNull:false
            }
        ]
    }
});