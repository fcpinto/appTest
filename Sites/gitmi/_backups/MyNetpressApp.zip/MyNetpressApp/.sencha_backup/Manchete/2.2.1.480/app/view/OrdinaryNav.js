/**
 * Created by zul on 08/10/13.
 */
Ext.define('Manchete.view.OrdinaryNav', {
    extend: 'Ext.navigation.View',
    xtype: 'ordinaryNav',

    config: {
        defaultBackButtonText:'',
        navigationBar:{
            ui: 'light',
            padding: 0,
            backButton: {
                ui: 'plain',
                //style: 'min-width:50px; position: relative; bottom: 0; top: 0; border: none;',
                iconCls: 'ss-directleft',
                iconAlign: 'left'
            },
            items: [
                {
                    xtype: 'button',
                    align: 'left',
                    iconCls: 'ss-list',
                    hidden: !Ext.os.is.Phone ? true : false,
                    text: ' ',
                    ui: 'plain',
                    handler: function () {
                        if (!Ext.getCmp('m-menu').isHidden()) {
                            Ext.getCmp('m-menu').hide();
                        }
                        else {
                            setTimeout(function () {
                                Ext.getCmp('m-menu').show();
                            }, 100);
                        }
                    }
                }

            ]
        }
    }
});