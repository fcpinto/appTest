/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.FilterList', {
    extend: 'Ext.dataview.List',
    xtype: 'filterList',

    config: {
        modal: true,
        centered:true,
        hideOnMaskTap: true,
        hidden: true,
        width: !Ext.os.is.Phone? 400 : 260,
        height: !Ext.os.is.Phone? 400 : '70%',
        contentEl: 'content',
        styleHtmlContent: true,
        scrollable: true,
        store: 'FilterMeio',
        mode:'MULTI',
        callback:'',
        itemTpl:Ext.create('Ext.XTemplate',
            '<span class="title">{text}</span><br>'
        ),
        listeners:{
            initialize:function(list){
                list.getStore().load();
            },
            itemtap:{
                fn: function (list, index, target, record, e) {
                    if(record.data.text == 'Todos'){
                        if(list.isSelected(record)){
                            list.selectAll();
                        }
                        else{
                            list.deselectAll();
                        }
                    }
                    else{
                        list.deselect(0);
                    }
                    if (list.getStore().getStoreId() == 'FilterMeio') {
                        var store = Ext.getStore('FilterPublicacao'),
                            selection = list.getSelection(),
                            refs = [],
                            len;
                        len = selection.length;

                        for (var i = 0; i < len; i++) {
                            refs.push(selection[i].data.value);
                        }
                        console.log('SELECT DISTINCT publicacao FROM NEWS WHERE tipo in ("' + refs.join('","') + '")')
                        /*store.setFilters([
                            {
                                property: 'ownQuery',
                                value: 'SELECT DISTINCT publicacao FROM NEWS WHERE tipo in ("' + refs.join('","') + '")'
                            }
                        ]);
                        store.load();*/
                    }
                    /*var store = list.up('newsFilters').down('#pubSelector').getStore(),
                     selection = list.getSelection(),
                     refs = [],
                     len;
                     len = selection.length;

                     for (var i = 0; i < len; i++) {
                     refs.push(selection[i].data.referencia3);
                     }
                     store.setFilters([
                     {
                     property: 'ownQuery',
                     value: 'SELECT DISTINCT publicacao FROM NEWS WHERE tipo in ("' + refs.join('","') + '")'
                     }
                     ]);
                     store.load();*/

                },
                buffer:100
            }
        }
    }
});