/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 17/09/13
 * Time: 00:52
 */
Ext.define('Manchete.model.Headlines', {
    extend: 'Ext.data.Model',

    config: {
        fields: [
            {
                name: 'id',
                type: 'int'
            },
            {
                name: 'guid',
                type: 'int'
            },
            'titulo',
            'publicacao',
            {
                name: 'data',
                convert: function (vl) {
                    var str = vl.split(' ')[0];
                    return str;
                }
            },
            'link',
            {
                name: 'linkBig',
                mapping: 'link',
                convert: function (vl, rec) {
                    var link;
                    if (!vl == false) {
                        var lio = vl.lastIndexOf('.');
                        var ext = vl.slice(lio);
                        link = vl.replace(ext, ('big' + ext));
                    }
                    return link;
                }
            },
            {
                name: 'photo',
                mapping: 'link',
                convert: function (vl, rec) {
                    return !vl ? 'none' : 'block';
                }
            }
        ]
    }
});