/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 27/08/13
 * Time: 12:13
 */
Ext.define('Manchete.view.daily.DailyNav',{
    extend:'Ext.navigation.View',
    xtype:'dailyNav',

    config:{
        items:[
            {
                xtype:'dataview',
                title:'Daily',
                cls:'daily-list',
                padding:0,
                margin:0,
                styleHtmlContent:true,
                store: 'HeadlinesTable',
                /*plugins: [
                    {
                        xclass: 'Ext.plugin.PullRefresh',
                        pullRefreshText: 'Manchete',
                        overpullSnapBackDuration:0,
                        snappingAnimationDuration:0
                    }
                ],*/
                itemTpl: [
                    '<div class="box">',
                    '   <div class="image" style="background-image:url({linkBig}); display: {photo}; ">',
                    '       <div class="image-bar">',

                    '           <span class="provider">{publicacao}</span>',
                    '           <span class="favorite">⋆</span>',
                    '       </div>',
                    '   </div>',
                    '   <div class="title">{titulo}</div>',
                    '   <div class="date">{data}</div>',
                    '</div>'
                ].join(''),
                listeners:{
                    itemtap:function(dv, index, target, record, e){
                        //console.log(record)
                        var node = e.target;
                        if(node.className === 'image'){
                            Ext.Viewport.overlay.element.dom.style.backgroundImage = 'url('+record.data.linkBig+')';
                            Ext.Viewport.overlay.show();
                        }
                        else{
                            this.up('navigationview').push({xtype:'container', title:record.data.publicacao});
                        }
                        /*if(node.className === 'image'){
                            console.log(record.data.linkBig);
                            if (!Ext.Viewport.overlay) {
                                Ext.Viewport.overlay = Ext.Viewport.add({
                                    itemId:'anOverlay',
                                    xtype:'container',
                                    cls:'overlayPhoto',
                                    centered:true,
                                    modal:true,
                                    hideOnMaskTap:true,
                                    showAnimation:{
                                        type:'popIn',
                                        duration:250,
                                        easing:'ease-out'
                                    },
                                    hideAnimation:{
                                        type:'popOut',
                                        duration:250,
                                        easing:'ease-out'
                                    },
                                    html:'<img class="photo" src="'+record.data.linkBig+'" style="width:100%; height:auto">',
                                    zIndex:1000,
                                    listeners:{
                                        initialize:function (img) {
                                            img.element.on('tap', function(){
                                                Ext.Viewport.overlay.hide();
                                            });
                                        },
                                        hide:function(img){
                                            Ext.Viewport.overlay.setHtml('');
                                        }
                                    }
                                });
                            }
                            else{
                                Ext.Viewport.overlay.setHtml('<img class="photo" src="'+record.data.linkBig+'" width="100%"/>')
                            }
                            Ext.Viewport.overlay.show();
                        }
                        else{
                            Ext.ComponentQuery.query('dailyNav')[0].push({xtype:'container', title:record.data.publicacao});
                        }*/

                    }
                }
            }
        ]
    }
});
