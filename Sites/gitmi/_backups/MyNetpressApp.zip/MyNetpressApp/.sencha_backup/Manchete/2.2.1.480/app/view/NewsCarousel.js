/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.NewsCarousel', {
    extend: 'Ext.Carousel',
    xtype: 'newsCarousel',

    config: {
        defaults: {
            styleHtmlContent: true
        },

        listeners:{
            activeitemchange:function(cmp){
                console.log(cmp.getActiveItem().getData().idx);
                //alert(cmp.animationDirection==1?'left':'right');
                if(cmp.animationDirection==-1){
                    var idx = cmp.getActiveItem().getData().idx+1;
                    console.log(cmp.config.st.getData().items[idx])
                    var dt = cmp.config.st.getData().items[idx].data;

                    dt.idx = idx;
                    cmp.add({
                        xtype:'newsItemCarousel',
                        data:dt
                        //html : 'Item 1',
                        //style: 'background-color: '+'#'+(0x1000000+(Math.random())*0xffffff).toString(16).substr(1,6)
                    })
                    cmp.innerItems[0].destroy()
                }
                else{
                    cmp.insert(0, {
                        html : 'Item 2',
                        style: 'background-color: '+'#'+(0x1000000+(Math.random())*0xffffff).toString(16).substr(1,6)
                    })
                    cmp.innerItems[cmp.innerItems.length-1].destroy()
                }
            }
        }
    }
});