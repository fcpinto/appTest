/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.HeadlinesFilters', {
    extend: 'Ext.form.Panel',
    xtype: 'headlinesFilters',

    config: {
        styleHtmlContent: true,
        style: 'background:#ffffff;',
        defaults:{
            margin:'0 0 10 0'
        },
        items: [
            {
                xtype:'titlebar',
                docked:'top',
                cls:'mediaTypeNav',
                items:[
                    {
                        xtype:'button',
                        iconCls:'ss-directleft',
                        ui: 'plain',
                        align:'left',
                        action:'backToManchetes'
                    }
                ]
            },
            {
                xtype: 'textfield',
                itemId: 'manchetesPub',
                label: 'Publicação',
                name: 'pubString',
                st:'FilterManchetesPub',
                readOnly: true

            },
            {
                xtype: 'hiddenfield',
                name: 'publicacao'
            },
            {
                xtype: 'sliderfield',
                itemId:'days',
                label: 'Dias: 1',
                value: 1,
                minValue: 1,
                maxValue: 7,
                name:'days',
                listeners: {
                    change: function (cmp, sl, thumb, newValue, oldValue) {
                        cmp.setLabel('Dias: ' + newValue);
                    }
                }
            },
            {
                xtype: 'button',
                text: 'Filtrar',
                ui: 'action',
                margin: 5,
                padding: 10,
                docked: 'bottom',
                action: 'filtrarManchetes'
            }
        ]

    }
});
