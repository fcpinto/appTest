/**
 * Created by zul on 07/10/13.
 */
/*Ext.define('Manchete.view.InfoView', {
    extend: 'Ext.Container',
    xtype: 'infoView',

    config: {
        styleHtmlContent:true,
        cls:'settings-form',
        items:[
            {
                xtype:'component',
                styleHtmlContent:true,
                docked:'bottom',
                style:'text-align:center',
                html:'<span style="color:#999999;">MyNetpress App, 2013 © Todos os direitos reservados</span>'
            }
        ]
    }
});*/


Ext.define('Manchete.view.InfoView', {
    extend: 'Ext.Container',
    xtype: 'infoView',

    config: {
        styleHtmlContent:true,
        scrollable: 'vertical',
        cls: 'infoPage'
    },

    initialize: function() {

        Ext.Ajax.request({
            url: 'manchete_info.html',
            success: function(rs) {
                this.setHtml(rs.responseText);
            },
            scope: this
        });
    }
});