/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 18/09/13
 * Time: 11:21
 */
Ext.define('Manchete.view.NewsGridView', {
    extend: 'Ext.navigation.View',
    xtype: 'newsGrid',

    config: {
        defaultBackButtonText:'',
        useTitleForBackButtonText: false,
        navigationBar:{
            cls:'mediaTypeNav',
            backButton:{
                iconCls:'ss-directleft',
                ui: 'plain'
            }
        },
        items:[
            {
                xtype:'dataview',
                cls: 'newsGrid-list',
                navlist:'newsGrid',
                selectedCls: '',
                padding: 0,
                margin: 0,
                styleHtmlContent: true,
                store: 'News',
                masked:{
                    xtype: 'loadmask',
                    message:'Por favor aguarde'
                },
                loadingText:'Por favor aguarde',
                scrollable:{
                    direction:'vertical',
                    directionLock:true
                },
                scrollToTopOnRefresh:false,
                striped: true,
                itemCls:Ext.os.deviceType == 'Phone'?'news-phone':'news-notphone',
                //emptyText:'Não existem novas notícias...',
                emptyText:'Não existem notícias disponíveis, por favor faça refresh, ou tente mais tarde.',
                itemTpl: Ext.create('Ext.XTemplate',
                    '<div class="box{[this.inHistory(values.link)]} bold{bold} completed{completed}">',
                    '   <div class="topbar {[this.clippingColor(values.tipo)]}"><div class="provider">{publicacao}</div><div class="info">{data}{[this.pagHora(values.paginas)]}</div></div>',
                    '   <div class="title">{titulo}</div>',
                    '   <div class="text">{[Ext.String.ellipsis(Ext.htmlDecode(values.texto), 200, true)]}</div>',
                    '   <div class="bottomBar">',
                    '       <span class="favorite{favorito} iconios"></span>',
                    '       <span class="share iconios"></span>',
                    '       <span class="{linkType}{downloaded} iconios files"></span>',
                    '       <span class="trash"></span>',
                    '   </div>',
                    '</div>',
                    {
                        inHistory:function(vl){
                            return vl==''?' notInHistory':'';
                        },
                        clippingColor:function(vl){
                            //console.log('teste:' + (!Manchete.app.clippingColors[vl]?'':Manchete.app.clippingColors[vl]));
                            return !Manchete.app.clippingColors[vl]?'':Manchete.app.clippingColors[vl];
                        },
                        pagHora:function(vl){
                            var str = '';
                            if(vl!=''){
                                str += '<br>' + (vl.lastIndexOf(':')> -1 ? vl : 'pág. ' + vl);
                            }
                            return str;
                        }
                    }
                ),
                items:[
                    {
                        xtype:'container',
                        style:'text-align:center; padding:10px 0 10px 0; background-color:#ffffff; color:#0775c1; font-weight: bold;',
                        html:'︿',
                        itemId:'toPrev',
                        scrollDock:'top',
                        hidden:true,
                        listeners: {
                            tap: {
                                fn: function(){
                                    var list = this.up('dataview'),
                                        store = list.getStore(),
                                        currentPage = store.currentPage;

                                    list.setLoadingText('Por favor aguarde');

                                    if(currentPage > 1){
                                        store.previousPage();
                                    }
                                },
                                element: 'element'
                            }
                        }
                    }
                ],
                listeners:{
                    initialize:function(list){
                        this.add({
                            xtype:'container',
                            style:'text-align:center; padding:10px 0 10px 0; background-color:#ffffff; color:#0775c1; font-weight: bold;',
                            html:'﹀',
                            itemId:'toNext',
                            scrollDock:'bottom',
                            hidden:true,
                            listeners: {
                                tap: {
                                    fn: function(){
                                        var store = list.getStore(),
                                            totalItems = store.getProxy().totalItems,
                                            totalPages = Math.ceil(totalItems/store.getPageSize());

                                        list.setLoadingText('Por favor aguarde');

                                        if(store.currentPage < totalPages){
                                            list.setEmptyText('');
                                            store.removeAll();
                                            list.setScrollToTopOnRefresh(true);
                                            //list.getScrollable().getScroller().scrollTo(0, 0);
                                            store.nextPage();
                                        }
                                    },
                                    element: 'element'
                                }
                            }
                        });

                        var store = this.getStore();
                        this.config.title = store.title;
                        if(!store.isLoading()){
                            this.setMasked(false);
                        }

                        if(!this.msnry){
                            var container = Ext.DomQuery.selectNode(".x-dataview-container", this.element.dom);
                            this.msnry = new Masonry( container, {
                                transitionDuration:0,
                                itemSelector: '.x-dataview-item'
                            });
                        }
                        if(list.config.title == "Favoritos"){
                            list.setEmptyText('Não existem notícias marcadas como favoritas');
                        }
                        else if(list.config.title == "Histórico"){
                            list.setEmptyText('Não existem notícias guardadas no histórico');
                        }
                    },
                    painted:function(el){
                        //console.log('painted');
                        //this.refresh();
                        this.msnry.reloadItems();
                        this.msnry.layout();

                    },
                    /*painted: {
                        fn: function (el) {
                            this.msnry.reloadItems();
                            this.msnry.layout();
                        },
                        buffer:100
                    },*/
                    refresh:function(list){
                        //console.log('refresh');
                        var store = list.getStore(),
                            totalItems = store.getProxy().totalItems,
                            totalPages = Math.ceil(totalItems/store.getPageSize()),
                            currentPage = store.currentPage,
                            toPrev = list.down('#toPrev'),
                            toNext = list.down('#toNext');

                        toPrev.setHidden(currentPage<=1);
                        toNext.setHidden(store.currentPage >= totalPages);
                        list.setScrollToTopOnRefresh(false);

                        this.msnry.reloadItems();
                        this.msnry.layout();
                    },
                    activate:function(list){
                        var store = list.getStore();
                        if(store.isFiltered){
                            list.setEmptyText('Não existem notícias que obedeçam aos critérios de filtragem');
                        }
                    }
                }
            }
        ],
        listeners:{
            destroy:function(nav){
                if(nav.config.cleanSearch){
                    Ext.getStore('SearchRemover').load();
                }
            }
        }
    }
});