/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 26/08/13
 * Time: 20:23
 */
Ext.define('Manchete.view.MenuClipping', {
    extend: 'Ext.dataview.List',
    xtype: 'menuClipping',

    config: {
        id: 'm-menu',
        width: 240,
        layout: 'fit',
        showAnimation: {type: 'slide', direction: 'right'},
        hideAnimation: {type: 'slide', direction: 'left', out: true},
        scrollable: {
            direction: 'vertical',
            indicators: false
        },
        masked:{
            xtype: 'loadmask',
            hidden:false
        },
        cls:'menu-list',
        styleHtmlContent:true,
        store:'MenuClippingTable',
        grouped: true,
        itemTpl: Ext.create('Ext.XTemplate',
            '<span style="font-family: SSStandard; color: #747679;">{[this.setIcon(values.id)]}</span>',
            '<span class="title">&nbsp;&nbsp;{clipping}</span>',
            {
                setIcon:function(id){
                    if(id == 2004 || id == 2005 || id == 2006){
                        return '📅';
                    }
                    else if(id == 2007){
                        return '⋆';
                    }
                    else if(id == 2008){
                        return '⏲';
                    }
                    else if(id == 2010){
                        return '🔎';
                    }
                }
            }
        ),
        items: [
            {
                docked: 'bottom',
                xtype: 'toolbar',
                padding: 0,
                layout: 'hbox',
                ui: 'about-settings',
                items:[
                    {
                        xtype: 'button',
                        ui:'plain',
                        iconCls: 'ss-user',
                        flex:1,
                        action:'user'
                    },
                    {
                        xtype: 'button',
                        ui:'plain',
                        iconCls: 'ss-settings',
                        flex:1,
                        action:'settings'
                    },
                    {
                        xtype: 'button',
                        ui:'plain',
                        iconCls: 'ss-info',
                        flex:1,
                        action:'info',
                        handler:function(){

                            //TEMPORÁRIO (para testes)++++++++++++++++++
                            /*Ext.Msg.confirm("Confirmação", "Tem a certeza que pretende remover todos os seus dados e reiniciar a aplicação?<br>- isto é para testes...", function (btn) {
                                if (btn == 'yes') {

                                    rootdb.transaction(function (tx) {
                                        tx.executeSql('DROP TABLE IF EXISTS HEADLINES');
                                        tx.executeSql('DROP TABLE IF EXISTS CLIPPING');
                                        tx.executeSql('DROP TABLE IF EXISTS NEWS');
                                        tx.executeSql('DROP TABLE IF EXISTS THEMES');
                                        tx.executeSql('DROP TABLE IF EXISTS NEWSSEARCH');
                                        localStorage.clear();
                                        document.location.reload(true);
                                    }, function (error) {
                                    });
                                }
                            });*/

                            /*Ext.Msg.confirm("Confirmação", "Tem a certeza que pretende fazer download de notícias, sem textos, até 4 meses atrás?<br>- isto é para testes... é melhor usar wireless", function(btn){
                                if(btn == 'yes'){
                                    var records = Ext.getStore('MenuClipping').getData().items,
                                        realRecords = [];
                                    for (var i in records) {
                                        if (records[i].data.activo == 1) {
                                            realRecords.push(records[i]);
                                        }
                                    }
                                    if (realRecords.length > 0) {
                                        //console.log(realRecords);
                                        Manchete.app.getController('Main').fullStores(realRecords);
                                    }
                                }
                            });*/

                        }
                    }
                ]
            }

        ]
    }
})