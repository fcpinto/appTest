/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.FilterPublicacao', {
    extend: 'Manchete.view.FilterMeio',
    xtype: 'filterPublicacao',

    config: {
        title:'Publicações',
        store: 'FilterPublicacao'
    }
});