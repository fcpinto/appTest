/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.NewsSearch', {
    extend: 'Ext.form.Panel',
    xtype: 'newsSearch',

    config: {
        itemId: 'newsSearch',
        styleHtmlContent: true,
        style: 'background:#ffffff;',
        items: [
            {
                xtype: 'filterSet'
            },
            {
                xtype: 'textfield',
                action:'moveViewport',
                itemId: 'palavra1',
                label: 'Palavra 1',
                name: 'palavra1',
                listeners: {
                    keyup: function (tf, e) {
                        var form = tf.up('formpanel');
                        if (tf.getValue() == '') {
                            form.down('#palavra2').setDisabled(true);
                            form.down('#palavra2').setValue('');
                            form.down('togglefield[name=operador]').setDisabled(true);
                            form.down('togglefield[name=operador]').setValue(0);
                        }
                        else {
                            form.down('#palavra2').setDisabled(false);
                            form.down('togglefield[name=operador]').setDisabled(false);
                        }
                    },
                    clearicontap: function (tf, e) {
                        var form = tf.up('formpanel');
                        form.down('#palavra2').setDisabled(true);
                        form.down('#palavra2').setValue('');
                        form.down('togglefield[name=operador]').setDisabled(true);
                        form.down('togglefield[name=operador]').setValue(0);
                    }
                },
                margin: '0 0 10 0'
            },
            {
                xtype: 'container',
                layout:'hbox',
                cls:'toggle-two-labels',
                defaults:{
                    flex: '1'
                },
                margin: '0 0 10 0',
                items:[
                    {
                        xtype: 'component',
                        html: 'E'
                    },
                    {
                        xtype: 'togglefield',
                        name: 'operador',
                        disabled:true
                    },
                    {
                        xtype: 'component',
                        html: 'OU'
                    }
                ]
            },
            {
                xtype: 'textfield',
                action:'moveViewport',
                itemId: 'palavra2',
                label: 'Palavra 2',
                name: 'palavra2',
                disabled: true,
                margin: '0 0 10 0'/*,
                listeners:{
                    focus: function(comp, e, eopts) {
                        var ost = comp.element.dom.offsetTop;
                        this.getParent().getScrollable().getScroller().scrollTo(0, ost);
                    }
                }*/
            },
            {
                xtype: 'textfield',
                itemId: 'datainicio',
                name: 'datainicio',
                label: 'Data início',
                clearIcon:false,
                listeners: {
                    initialize:function(tf){
                        /*var datefield = tf.element.dom.getElementsByTagName('input')[0],
                            oneDay = 24 * 60 * 60 * 1000 * 1,
                            datafim = new Date(),
                            datainicio = Ext.Date.format(new Date(datafim.getTime()-oneDay), "Y-m-d H:i");

                        datefield.type = 'datetime-local';
                        datefield.value = datainicio.replace(' ','T');

                        datefield.onchange = function(){
                            tf.fireEvent('onchange', tf);
                        }*/
                        var datefield = tf.element.dom.getElementsByTagName('input')[0],
                            oneDay = 24 * 60 * 60 * 1000 * 1,
                            datafim = new Date(),
                            datainicio = Ext.Date.format(new Date(datafim.getTime()-oneDay), "Y-m-d");

                        datefield.type = 'date';
                        datefield.value = datainicio;

                        datefield.onchange = function(){
                            tf.fireEvent('onchange', tf);
                        }
                    }
                },
                margin: '0 0 10 0'
            },
            {
                xtype: 'textfield',
                itemId: 'datafim',
                name: 'datafim',
                label: 'Data fim',
                clearIcon:false,
                listeners: {
                    initialize:function(tf){
                        /*var datefield = tf.element.dom.getElementsByTagName('input')[0];
                        var date = Ext.Date.format(new Date(), "Y-m-d H:i");
                        datefield.type = 'datetime-local';
                        datefield.value = date.replace(' ','T');

                        datefield.onchange = function(){
                            tf.fireEvent('onchange', tf);
                        }*/
                        var datefield = tf.element.dom.getElementsByTagName('input')[0];
                        var date = Ext.Date.format(new Date(), "Y-m-d");
                        datefield.type = 'date';
                        datefield.value = date

                        datefield.onchange = function(){
                            tf.fireEvent('onchange', tf);
                        }
                    }
                }
            },
            {
                xtype: 'container',
                layout:'hbox',
                docked: 'bottom',
                //action: 'filtrar',
                style:'background:#EEEEEE;',
                padding:5,
                items:[
                    /*{
                        xtype: 'button',
                        //itemId: 'filterBtn',
                        text: 'Cancelar',
                        ui: 'decline',
                        margin: '0 3 0 0',
                        padding: 10,
                        flex:1,
                        action: 'procurarCancel'
                    },*/
                    {
                        xtype: 'button',
                        itemId: 'searchBtn',
                        text: 'Procurar',
                        ui: 'confirm',
                        margin: '0 0 0 3',
                        padding: 10,
                        flex:1,
                        action: 'procurar'
                    }
                ]
            }
        ]

    }
});
