/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.FilterMeio', {
    extend: 'Ext.dataview.List',
    xtype: 'filterMeio',

    config: {
        title:'Meios',
        modal: true,
        centered:true,
        hideOnMaskTap: false,
        hidden: true,
        width: !Ext.os.is.Phone? 400 : 260,
        height: !Ext.os.is.Phone? 400 : '70%',
        contentEl: 'content',
        styleHtmlContent: true,
        scrollable: true,
        store: 'FilterMeio',
        mode:'MULTI',
        callback:'',
        itemTpl:Ext.create('Ext.XTemplate',
            '<span class="title">{text}</span>'
        ),
        items:[
            {
                xtype:'titlebar',
                docked:'top',
                ui:'light',
                items: [
                    {
                        iconCls: 'ss-notall',
                        align: 'left',
                        ui:'plain',
                        action:'fSelectAll',
                        itemId:'fSelectAll'
                    },
                    {
                        iconCls: 'ss-select',
                        align: 'right',
                        ui:'plain',
                        action:'fClose'
                    }
                ]
            }
        ],
        listeners:{
            initialize:function(list){
                list.down('titlebar').setTitle(list.config.title);
            },
            itemtap:{
                fn: function (list, index, target, record, e) {

                },
                buffer:100
            }
        }
    }
});