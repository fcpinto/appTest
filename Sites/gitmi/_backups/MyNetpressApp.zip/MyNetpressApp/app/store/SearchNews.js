/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 09/09/13
 * Time: 13:32
 */
Ext.define('Manchete.store.SearchNews', {
    extend: 'Ext.data.Store',

    requires: [
        'Ext.data.proxy.JsonP'
    ],

    config:{
        model:'Manchete.model.MediaType',
        //fields:['id','tipo','data'],
        //autoLoad:true,

        proxy:{
            timeout:'60000',
            type:"jsonp",
            url:'https://services.manchete.pt:8002/Clientes.asmx/getSearch',

            extraParams: {
                user: '',
                password: '',
                datainicio: "",
                datafim: "",
                tema: "",
                tipo:"",
                publicacao:"",
                palavra1:"",
                palavra2:"",
                operador:""
            },
            pageParam:false,
            limitParam:false,
            startParam:false

        },
        pageSize:100,

        listeners:{
            load:function (st, records, successful, operation) {
                console.log('SearchNews: ',records);
                if(successful){
                    var len = records.length,
                        store = Ext.getStore('News'),
                        listIds = [];

                    if(len==0){
                        //Ext.Msg.alert('Notícias', 'Não existem notícias disponíveis para os critérios de pesquisa!', Ext.emptyFn);
                        Ext.device.Notification.show({
                            title: 'Notícias',
                            message: 'Não existem notícias disponíveis para os critérios de pesquisa!',
                            buttons: Ext.MessageBox.OK
                        });
                    }
                    else if(records[0].raw.warning){
                        //Ext.Msg.alert('Notícias', 'A sua pesquisa retornou demasiados resultados. Por favor reveja os critérios de pesquisa!', Ext.emptyFn);
                        Ext.device.Notification.show({
                            title: 'Notícias',
                            message: 'A sua pesquisa retornou demasiados resultados. Por favor reveja os critérios de pesquisa!',
                            buttons: Ext.MessageBox.OK
                        });
                    }
                    else{
                        for(var i=0;i<len;i++){
                            listIds.push(records[i].data.id);
                            records[i].data.completed = -1;
                        }

                        store.setFilters([
                            {
                                property:'id',
                                values:listIds
                            }
                        ]);

                        Manchete.app.fireEvent('insertRecords', records, 'News');
                        Manchete.app.getController('Main').showViews('mediaType', true);

                    }



                    /*var len = records.length,
                        store = Ext.getStore('SearchResult'),
                        listIds = [];
                    if(len>0){

                        for(var i=0;i<len;i++){
                            listIds.push(records[i].data);
                        }
                        store.load({
                            params:{
                                user: 'teste@manchete.pt',
                                password: 'b9Wk9Yeq',
                                listIds:JSON.stringify(listIds)
                            }
                        });
                    }
                    else{
                        Ext.Msg.alert('Notícias', 'Não existem notícias disponíveis para os critérios de pesquisa.', Ext.emptyFn);
                        Ext.Viewport.getMasked().setHidden(true);
                    }*/

                    //Manchete.app.fireEvent('insertRecords', records, 'HeadlinesTable');
                }
                else{
                    Ext.Msg.alert('Internet', 'Erro de ligação à Internet.', Ext.emptyFn);
                }
                Ext.Viewport.getMasked().setHidden(true);
            }
        }
    }
});