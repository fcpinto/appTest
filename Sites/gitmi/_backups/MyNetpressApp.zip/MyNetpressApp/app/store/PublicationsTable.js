/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 16/09/13
 * Time: 15:29
 */
Ext.define('Manchete.store.PublicationsTable', {
    extend: 'Ext.data.Store',

    config: {
        model: 'Manchete.model.Publications',

        sorters: ['tipo','fonte'],
        startTable: true,

        pageSize:false,

        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'PUBLICATIONS',
            enablePagingParams: false
        },
        listeners: {
            load: function (st, records, successful, operation) {
                //console.log('PublicationsTable: ' + successful);

                if(successful){
                    var len = records.length;

                    for(var i=0;i<len;i++){
                        //console.log(records[i].data.tipo +': '+records[i].data.fonte);
                    }
                }

            }
        }
    }
});