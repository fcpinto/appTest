/**
 * Created by zul on 08/10/13.
 */
Ext.define('Manchete.controller.Login', {
    extend: 'Ext.app.Controller',

    config: {
        refs: {
            loginForm: 'loginForm formpanel',
            loginRemove: 'loginRemove formpanel'
        },
        control: {
            'button[action=login]': {
                tap: 'logintap'
            },
            'button[action=logout]': {
                tap: 'logouttap'
            },
            'button[action=removerconta]': {
                tap: 'removerconta'
            },
            'button[action=confirmToRemove]': {
                tap: 'confirmToRemove'
            }
        }
    },
    init: function () {

    },
    logintap: function (btn) {
        var form = this.getLoginForm(),
            values = form.getValues(),
            store;

        if (values.user != '' && values.password != '') {

            if (this.isMail(values.user)) {
                var noAccount = !localStorage.mancheteuserdetails?true:false,
                    userdetails;

                if(typeof(window.deviceToken) != "undefined"){
                    values.deviceType = device.platform;
                    values.deviceToken = window.deviceToken;
                }
                else{
                    values.deviceType = '';
                    values.deviceToken = '';
                }

                if(noAccount){
                    store = Ext.getStore('Login');
                    store.load({
                        params: values,
                        callback: Ext.bind(this.loginCallback, this)
                    });
                }
                else{
                    userdetails = JSON.parse(localStorage.mancheteuserdetails);
                    if(values.user == userdetails.mail){
                        store = Ext.getStore('Login');
                        store.load({
                            params: values,
                            callback: Ext.bind(this.loginCallback, this)
                        });
                    }
                    else{
                        Ext.device.Notification.show({
                            title: 'Login',
                            message: 'O user da conta ' + userdetails.mail + ' deverá remover a conta primeiro.',
                            buttons: Ext.MessageBox.OK,
                            callback: Ext.emptyFn
                        });
                    }
                }

            }
            else {
                Ext.device.Notification.show({
                    title: 'Login',
                    message: 'O seu e-mail não é válido.',
                    buttons: Ext.MessageBox.OK,
                    callback: Ext.emptyFn
                });
            }
        }
        else {
            Ext.device.Notification.show({
                title: 'Login',
                message: 'Os dois campos são obrigatórios.',
                buttons: Ext.MessageBox.OK,
                callback: Ext.emptyFn
            });
        }
    },
    loginCallback: function (records, operation, success) {
        //console.log('Login');
        //console.log(records);
        if (success) {
            if (records.length > 0) {
                var login = records[0].data.login;

                if (login == '2') {
                    var form = this.getLoginForm(),
                        values = form.getValues();
                    localStorage.mancheteuser = values.user;
                    localStorage.manchetepass = values.password;
                    localStorage.manchetemaxhistory = 30;

                    //Manchete.app.getController('Main').fromLogin = true;
                    Ext.getCmp('contentView').getActiveItem().hide();
                    Ext.getStore('MenuClipping').load({
                        params: {
                            user: localStorage.mancheteuser,
                            password: localStorage.manchetepass
                        }
                    });

                    Ext.getStore('UserThemes').load({
                        params: {
                            user: localStorage.mancheteuser,
                            password: localStorage.manchetepass
                        }
                    });
                    form.up('container').hide();

                    localStorage.mancheteuserdetails = JSON.stringify(records[0].raw);
                    Manchete.app.fireEvent('insertRecords', records, 'UserDetails');

                }
                else if (login == '1') {
                    Ext.device.Notification.show({
                        title: 'Login',
                        message: 'O seu utilizador não dispõe de acesso ao "MyNetpress App". Por favor contacte o seu gestor de contrato.',
                        buttons: Ext.MessageBox.OK,
                        callback: Ext.emptyFn
                    });
                }
                else {
                    Ext.device.Notification.show({
                        title: 'Login',
                        message: 'Nome de utilizador ou palavra passe errados.',
                        buttons: Ext.MessageBox.OK,
                        callback: Ext.emptyFn
                    });
                }
            }
        }
        else {
            Ext.device.Notification.show({
                title: 'Internet',
                message: 'Não tem ligação à internet!',
                buttons: Ext.MessageBox.OK,
                callback: Ext.emptyFn
            });
        }
        /*if(operation.error != 'error'){
         if(operation.getResponse() == 'true'){
         var form = this.getLoginForm(),
         values = form.getValues();

         localStorage.mancheteuser = values.user;
         localStorage.manchetepass = values.password;
         Ext.getStore('MenuClipping').load({
         params:{
         user: localStorage.mancheteuser,
         password: localStorage.manchetepass
         }
         });

         Ext.getStore('UserThemes').load({
         params:{
         user: localStorage.mancheteuser,
         password: localStorage.manchetepass
         }
         });
         form.up('container').hide();
         }
         else{
         Ext.Msg.alert("Login","Nome de utilizador ou palavra passe errados.", Ext.emptyFn);
         }
         }
         else{
         Ext.Msg.alert("Internet", "Não tem ligação à internet!", Ext.emptyFn);
         }*/

    },
    isMail: function (mail) {
        var emailRegEx = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;

        return mail.search(emailRegEx) != -1 ? true : false;
    },
    removerconta:function(btn){
        if(!this.loginForm){
            this.loginForm = Ext.Viewport.add({xtype:'loginRemove'});
        }
        this.loginForm.show();
    },
    confirmToRemove:function(){

        var form = this.getLoginRemove(),
            values = form.getValues(),
            store;

        if (values.user != '' && values.password != '') {

            if (this.isMail(values.user)) {
                if (values.user == localStorage.mancheteuser && values.password == localStorage.manchetepass) {
                    this.lastConfirmation();
                }
                else {
                    Ext.device.Notification.show({
                        title: 'Login',
                        message: 'Nome de utilizador ou palavra passe errados.',
                        buttons: Ext.MessageBox.OK,
                        callback: Ext.emptyFn
                    });
                }
            }
            else {
                Ext.device.Notification.show({
                    title: 'Login',
                    message: 'O seu e-mail não é válido.',
                    buttons: Ext.MessageBox.OK,
                    callback: Ext.emptyFn
                });
            }
        }
        else {
            Ext.device.Notification.show({
                title: 'Login',
                message: 'Os dois campos são obrigatórios.',
                buttons: Ext.MessageBox.OK,
                callback: Ext.emptyFn
            });
        }
    },
    lastConfirmation:function(){
        var me = this;
        Ext.device.Notification.show({
            title: 'Confirmação',
            message: 'Tem a certeza que pretende remover todos os seus dados e reiniciar a aplicação?',
            buttons: [{text: 'Não'}, {text: 'Sim', ui: 'action'}],
            callback: function (button) {
                if (button.toLowerCase() == "sim") {

                    if(typeof(window.deviceToken) != "undefined"){
                        Ext.data.JsonP.request({
                            url: 'https://services.manchete.pt:8002/Clientes.asmx/DeleteNotifications',
                            callbackKey: 'callback',
                            params: {
                                user:localStorage.mancheteuser,
                                password:localStorage.manchetepass,
                                deviceType:device.platform,
                                deviceToken:window.deviceToken
                            },
                            success: function (response) {
                                me.confirmationYes();
                            },
                            failure: function (error) {
                                me.confirmationYes();
                            }
                        });
                    }
                    else{
                        me.confirmationYes();
                    }
                }
            }
        });
    },
    confirmationYes:function(){
        stopPushNotification();
        rootdb.transaction(function (tx) {
            tx.executeSql('DROP TABLE IF EXISTS HEADLINES');
            tx.executeSql('DROP TABLE IF EXISTS CLIPPING');
            tx.executeSql('DROP TABLE IF EXISTS NEWS');
            tx.executeSql('DROP TABLE IF EXISTS THEMES');
            tx.executeSql('DROP TABLE IF EXISTS NEWSSEARCH');
            tx.executeSql('DROP TABLE IF EXISTS USERDETAILS');
            tx.executeSql('DROP TABLE IF EXISTS PUBLICATIONS');
            localStorage.clear();
            document.location.reload(true);
        }, function (error) {
        });
    },
    teste: function () {
        //var menu = Ext.getCmp('m-menu');
        //Manchete.app.getController('Main').onMenuItemtap(menu,null,null,menu.getSelection()[0]);
    },
    logouttap: function () {
        var userdetails = JSON.parse(localStorage.mancheteuserdetails);

        userdetails.login = -1;

        localStorage.removeItem('mancheteuser');
        localStorage.removeItem('manchetepass');
        localStorage.mancheteuserdetails = JSON.stringify(userdetails);
        document.location.reload(true);

    }
});