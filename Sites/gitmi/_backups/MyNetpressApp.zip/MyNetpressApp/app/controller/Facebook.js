/**
 * Created by zul on 06/11/13.
 */
Ext.define('Manchete.controller.Facebook', {
    extend: 'Ext.app.Controller',

    config: {
        refs: {

        },
        control: {

        },
        fbLogged:false
    },
    init: function () {
            if (Ext.browser.is.WebView){
                var script = document.createElement("script");
                script.type = "text/javascript";
                script.src = "facebook_js_sdk.js";
                script.onload = Ext.bind(this.fbOnWebView, this);
                document.body.appendChild(script);
            }
            else{
                window.fbAsyncInit = Ext.bind(this.fbOnDesktop, this);
                (function (d) {
                    var js, id = 'facebook-jssdk';
                    if (d.getElementById(id)) {
                        return;
                    }
                    js = d.createElement('script');
                    js.id = id;
                    js.async = true;
                    js.src = "//connect.facebook.net/en_US/all.js";
                    d.getElementsByTagName('head')[0].appendChild(js);
                }(document));
            }

    },
    fbOnWebView:function(){
        //console.log('fbOnWebView');
        //FB.Event.subscribe('auth.login', Ext.bind(this.onLogin, this));
        FB.Event.subscribe('auth.logout', Ext.bind(this.onLogout, this));
        FB.init({
            appId: Manchete.app.facebookAppId,
            nativeInterface: CDV.FB,
            //useCachedDialogs: false,
            status: true,
            cookie: true,
            xfbml: true,
            frictionlessRequests: true,
            useCachedDialogs: true,
            oauth: true
        });

        //this.getLoginFbStatus();
        this.getLoginStatus();
    },
    fbOnDesktop:function(){
        //console.log('fbOnDesktop');
        var controller = this;
        //FB.Event.subscribe('auth.login', Ext.bind(this.onLogin, this));
        FB.Event.subscribe('auth.logout', Ext.bind(this.onLogout, this));
        FB.init({
            appId: Manchete.app.facebookAppId,
            frictionlessRequests: true,
            status     : true,           // check login status
            cookie     : true,           // enable cookies to allow the server to access the session
            xfbml      : true,
            useCachedDialogs: true
        });
        //this.getLoginFbStatus();
        this.getLoginStatus();
    },
    getLoginFbStatus:function(connected,nonconnected){
        var controller = this;
        FB.getLoginStatus(function (resp) {

            if (resp.status == 'connected') {
                var accessToken = resp.authResponse.accessToken;
                //console.log('logged in');
                if(connected){
                    connected(controller);
                }
                FB.api('/me', function (response) {
                    /*console.log(response.id);
                    console.log(response.name);
                    console.log(response.gender);
                    console.log(response.email);
                    console.log(response.username);*/
                });
            }
            else {
                //console.log('not logged in');
                if(nonconnected){
                    nonconnected(controller);
                }
            }
        });
    },
    startLogin:function(){
        var controller = this;
        FB.login(function(response) {
            controller.onLogin(response);
        },{ scope: "email" });
    },
    onLogin: function(resp) {

        if (resp.status === 'connected') {
            var accessToken = resp.authResponse.accessToken;
            this.accessToken = accessToken;
            FB.api('/me', function (response) {
                //console.log(response.id);
                 //console.log(response.name);
                 //console.log(response.gender);
                 //console.log(response.email);
                 //console.log(response.username);
            });
        }
        else {
            console.log('not logged in');
        }
        //console.log('auth.login event');
    },
    onLogout: function(response) {
        //console.log(response);
        //console.log('auth.logout event');
    },
    publishToFB:function(data,onsuccess){

        var me = this;

        //console.log(Ext.htmlDecode(data.titulo));


        if (Ext.browser.is.WebView) {

            if (me.getFbLogged()) {
                FB.ui({
                        method: 'feed',
                        name: Ext.htmlDecode(data.titulo),
                        caption: 'www.mynetpress.com',
                        description: 'in ' + Ext.htmlEncode(data.publicacao) + ', ' + data.data,
                        link: Ext.htmlDecode(data.link),
                        picture: 'http://www.mynetpress.com/MynetpressApp/seta_manchete_BIG.png'
                    },
                    function (response) {
                        onsuccess(true);
                        /*if(response.post_id){
                         var postID = response.post_id.split('_');
                         console.log('https://www.facebook.com/' + postID[0] + '/posts/' + postID[1]);
                         }*/
                    });
            }
            else {
                me.doLogin(data, onsuccess);
            }
        }
        else {
            FB.api('/me/feed', 'post', {
                    privacy: {
                        'value': 'SELF'
                    },
                    //privacy:{
                    //    'value': 'CUSTOM',
                    //    'allow': '10150724533865328,10151414724869799,1269766299713,444183589031005'
                    //},
                    name: Ext.htmlDecode(data.titulo),
                    type: 'link',
                    link: Ext.htmlDecode(data.link),
                    description: 'in ' + Ext.htmlEncode(data.publicacao) + ', ' + data.data,
                    picture: 'http://www.mynetpress.com/MynetpressApp/seta_manchete_BIG.png'
                },
                function (response) {
                    if (!response) {
                        console.log('Error occured on publish to FB');
                        onsuccess(false);
                    }
                    else if (response.error) {
                        console.log(response.error);
                        if (response.error.code == 200) {
                            console.log('Permission error: Publish not allowed');
                            //me.startLogin();
                            me.askPublishPermission(data, onsuccess);
                        }
                        else if (response.error.code == 2500) {
                            console.log('Permission error: Login not allowed');
                            me.loginAndPermission(data, onsuccess);
                        }
                        else {
                            console.log('Error occured on publish to FB');
                            onsuccess(false);
                        }
                    }
                    else {
                        var postID = response.id.split('_');
                        console.log('https://www.facebook.com/' + postID[0] + '/posts/' + postID[1]);
                        onsuccess(true);
                    }

                }
            );
        }
    },
    loginAndPermission:function(data, onsuccess){
        var me = this;
        FB.login(function(response) {
            if (response.status === 'connected') {
                me.askPublishPermission(data, onsuccess);
            }
            else {
                console.log('not logged in');
                Ext.device.Notification.show({
                    title: 'Facebook',
                    message: 'Não foram dadas as permissões para publicar no Facebook',
                    buttons: Ext.MessageBox.OK
                });
            }
        },{ scope: "email" });
    },
    askPublishPermission:function(data, onsuccess){
        var me = this;
        FB.login(function(response){

            FB.api('/me/permissions', function (response) {
                var perms = response.data[0];
                if (perms.publish_stream) {
                    me.publishToFB(data, onsuccess);
                }
                else{
                    Ext.device.Notification.show({
                        title: 'Facebook',
                        message: 'Não foram dadas as permissões para publicar no Facebook',
                        buttons: Ext.MessageBox.OK
                    });
                }
            } );

        }, {scope: 'publish_stream'});
    },
    getLoginStatus:function(){
        var me = this;

        FB.getLoginStatus(function (response) {
            me.setFbLogged(response.status == 'connected');
        });
    },
    doLogin:function(data, onsuccess){
        var me = this,
            logged = false;

        FB.login(function(response) {

            logged = (response.status === 'connected');
            me.setFbLogged(logged);

            if (!logged) {
                console.log('not logged in');
                Ext.device.Notification.show({
                    title: 'Facebook',
                    message: 'Não foram dadas as permissões para publicar no Facebook',
                    buttons: Ext.MessageBox.OK
                });
            }
            else{
                me.publishToFB(data, onsuccess);
            }
        },{ scope: "email" });
    }

});