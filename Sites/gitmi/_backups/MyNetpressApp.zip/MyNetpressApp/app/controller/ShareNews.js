/**
 * Created by zul on 07/11/13.
 */
Ext.define('Manchete.controller.ShareNews',{
    extend:'Ext.app.Controller',

    config:{
        refs:{
            shareNews:'shareNews',
            facebook:'button[actions=toFacebbok]',
            twitter:'button[actions=toTwitter]',
            linkedin:'button[actions=toLinkedin]',
            mail:'button[actions=toMail]',
            mailSender:'mailsender'
        },
        control:{
            'button[actions=toFacebbok]':{
                tap:'toFacebbok'
            },
            'button[actions=toTwitter]':{
                tap:'toTwitter'
            },
            'button[actions=toLinkedin]':{
                tap:'toLinkedin'
            },
            'button[actions=toMail]':{
                tap:'toMail'
            },
            'button[action=sendMail]':{
                tap:'sendMail'
            }
        }
    },
    init:function(){

    },
    toFacebbok:function(){
         //console.log('toFacebbok');
        /*var fbConnect = Manchete.app.getController('Facebook');
        fbConnect.getLoginFbStatus(Ext.bind(this.fbIsLogin,this),Ext.bind(this.fbIsLogout,this));
        this.hideSharePop();*/

        var me = this,
            fbController = Manchete.app.getController('Facebook'),
            data = me.getShareNews().getData();

        if(data.linkType == 'video'){
            data.link = 'http://www.mynetpress.com/mailsystem/video_mp4.asp?id='+data.id;
        }
        else if(data.linkType == 'audio'){
            data.link = 'http://www.mynetpress.com/mailsystem/radio_mp3.asp?id='+data.id;
        }

        fbController.publishToFB(data,function(success){

            if(success){

            }
            else{
                Ext.device.Notification.show({
                    title: 'Partilha',
                    message: 'Não foi possível partilhar no facebook. Por favor tente mais tarde.',
                    buttons: Ext.MessageBox.OK,
                    callback: Ext.emptyFn
                });
            }
        });
        me.getShareNews().hide();

    },
    fbIsLogin:function(fbConnect){
        //console.log('fbIsLogin');
        var me = this,
            data = me.getShareNews().getData();
        //console.log(Ext.htmlDecode(data.texto));
        fbConnect.publishToFB(data,function(success){
            me.getShareNews().hide();
            if(success){

            }
            else{
                Ext.device.Notification.show({
                    title: 'Partilha',
                    message: 'Não foi possível partilhar no facebook. Por favor tente mais tarde.',
                    buttons: Ext.MessageBox.OK,
                    callback: Ext.emptyFn
                });
            }
        });
    },
    fbIsLogout:function(fbConnect){
        fbConnect.startLogin();
    },
    toTwitter:function(btn){
        //console.log('toTwitter');
        if(Ext.browser.is.WebView){
            var shareNews = btn.up('shareNews'),
                data = shareNews.getData(),
                text = Ext.htmlDecode(data.titulo) + '\n\nin ' + Ext.htmlEncode(data.publicacao) + ', ' + data.data,
                url = data.link,
                message = {};


            if(data.linkType == 'video'){
                url = 'http://www.mynetpress.com/mailsystem/video_mp4.asp?id='+data.id;
            }
            else if (data.linkType == 'audio') {
                url = 'http://www.mynetpress.com/mailsystem/radio_mp3.asp?id=' + data.id;
            }

            message = {
                text: text,
                url: Ext.htmlDecode(url),
                activityType: "PostToTwitter"//PostToTwitter,PostToFacebook,Mail
            };
            window.socialmessage.send(message);
        }
        this.hideSharePop();
    },
    toLinkedin:function(btn){
        //console.log('toLinkedin');
        this.hideSharePop();
    },
    toMail: function (btn) {
        console.log('toMail');

        var mailSender = this.getMailSender();
        var shareNews = btn.up('shareNews'),
            data = shareNews.getData(),
            manchete = (typeof(data.tipo) == 'undefined'),
            id = manchete?'mediaPressId':'newId',
            params = {
                //emailSender: localStorage.mancheteuser,
                user: manchete ? 'manchetemobile' : localStorage.mancheteuser,
                password: manchete ? 'mancheteqwerty' : localStorage.manchetepass
            },
            url = manchete ? 'https://services.manchete.pt:8001/Manchetes.asmx/sendHeadlinesPress' : 'https://services.manchete.pt:8002/Clientes.asmx/sendnewByEmail'; //

        params[id] = data.id;

        if(!manchete){
            params.tipo = data.tipo;
        }

        if(!mailSender){
            mailSender = Ext.Viewport.add({xtype:'mailSender'});
            mailSender.mailParams = params;
            mailSender.mailUrl = url;
        }
        mailSender.show();
        this.hideSharePop();
    },
    sendMail:function(btn){
        var mailSender = btn.up('mailSender'),
            values = btn.up('formpanel').getValues(),
            params = mailSender.mailParams,
            url = mailSender.mailUrl,
            newsType = (params.user == "manchetemobile")?'Manchete':'Notícia',
            newParams;

        if (this.isMail(values.emailDestination)) {

            Ext.Viewport.setMasked({xtype: 'loadmask'});

            newParams = Ext.Object.merge({}, values, params);
            //console.log(JSON.stringify(newParams));
            newParams.emailSender = !localStorage.mancheteuser?values.emailSender:localStorage.mancheteuser;

            Ext.data.JsonP.request({
                url: url,
                callbackKey: 'callback',
                params: newParams,
                success: function (response) {
                    console.log(response);
                    var done = (response.mail == "true");
                    if(done){
                        Ext.device.Notification.show({
                            title: 'Mail',
                            message: newsType+' partilhada com sucesso.',
                            buttons: Ext.MessageBox.OK,
                            callback: Ext.emptyFn
                        });
                        mailSender.hide();
                    }
                    else{
                        Ext.device.Notification.show({
                            title: 'Mail',
                            message: 'Falha na partilha da '+newsType+'. Por favor verifique os dados e tente novamente.',
                            buttons: Ext.MessageBox.OK,
                            callback: Ext.emptyFn
                        });
                    }
                    Ext.Viewport.setMasked(false);
                },
                failure: function (error) {
                    Ext.device.Notification.show({
                        title: 'Internet',
                        message: 'Sem ligação à internet.',
                        buttons: Ext.MessageBox.OK,
                        callback: Ext.emptyFn
                    });
                    Ext.Viewport.setMasked(false);
                }
            });
        }
        else {
            Ext.device.Notification.show({
                title: 'Mail',
                message: 'O e-mail não é válido.',
                buttons: Ext.MessageBox.OK,
                callback: Ext.emptyFn
            });
        }
    },
    hideSharePop:function(){
        if(Manchete.app.shareFromList){
            Manchete.app.shareFromList.hide();
        }
        if(Manchete.app.shareFromItem){
            Manchete.app.shareFromItem.hide();
        }
    },
    isMail: function (mail) {
        var emailRegEx = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;

        return mail.search(emailRegEx) != -1 ? true : false;
    }
})