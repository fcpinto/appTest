Ext.define('MobiShout_Admin.view.issues.SelectedIssue', {
    extend: 'Ext.form.Panel',
    xtype: 'selectedIssue',

    requires: [
        'Ext.TitleBar',
        'Ext.Button',
        'Ext.ux.Fileup'
    ],

    config: {
        navigationBar: {
            hidden: true
        },
        //   tabBarPosition: 'bottom',
        items: [
            {
                xtype: 'toolbar',
                docked: 'top',
                items: [
                    {
                        xtype: 'button',
                        iconCls: 'ss-back',
                        cls: 'toolbarBtn',
                        style: 'border: 0px; background-color: rgba(17, 89, 140, 0);',
                        action: 'backToIssues',
                        align: 'left'
                    },
                    {
                        xtype: 'spacer'
                    }
                ]
            },
            {
                // id: 'welcome',
                title: 'Welcome',
                iconCls: 'home',
                scrollable: null,
                styleHtmlContent: true,

                layout: 'hbox',

                items: [
                    {
                        layout: {
                            type: 'vbox'
                        },
                        defaults: {
                            style: 'margin: 5px;'
                            //  readOnly: true
                        },
                        items: [
                            {
                                xtype: 'textfield',
                                label: 'Shout: ',
                                itemId: 'issue_id',
                                id: 'issueId',
                                name: 'issue_id',
                                placeHolder: 'issueID',
                                readOnly: true
                            },
                            {
                                xtype: 'textfield',
                                label: 'Keywords: ',
                                name: 'keywords'
                            },
                            {
                                xtype: 'textfield',
                                label: 'Title: ',
                                name: 'title'
                            },
                            {
                                xtype: 'textfield',
                                label: 'Subtitle: ',
                                name: 'subtitle'
                            },
                            {
                                xtype: 'textfield',
                                label: 'Description: ',
                                name: 'description'
                            },
                            {
                                xtype: 'textfield',
                                label: 'Filename: ',
                                name: 'filename'
                            },
                            {
                                xtype: 'datepickerfield',
                                dateFormat: 'Y-m-d',
                                name: 'date_start',
                                label: 'Date Start:',
                                value: new Date(),
                                picker: {
                                    yearFrom: new Date().getFullYear(),
                                    yearTo: 2020,
                                    slotOrder: ['year', 'month', 'day']
                                }
                            },
                            {
                                xtype: 'datepickerfield',
                                dateFormat: 'Y-m-d',
                                name: 'date_end',
                                label: 'Date End:',
                                picker: {
                                    yearFrom: new Date().getFullYear(),
                                    yearTo: 2020,
                                    slotOrder: ['year', 'month', 'day']
                                }
                            },
                            {
                                xtype: 'togglefield',
                                name: 'active',
                                label: 'Active',
                                align: 'right'
                            },
                            {
                                layout: 'hbox',
                                defaults: {
                                    cls: 'mainBtn'
                                },

                                items: [
                                    {
                                        itemId: 'fileBtn',
                                        xtype: 'fileupload',
                                        autoUpload: true,
                                        url: '',
                                        style: 'margin: 5px; height: 100px;',
                                        flex: 1,
                                        handler: function () {

                                            var valueID = Ext.getCmp('issueId').getValue();

                                            var n = valueID.length;

                                            if (n == 1) {
                                                this.setUrl(servicesMSMS + '/getfile.php?i=' + 'shout00' + valueID);
                                            }
                                            else if (n == 2) {
                                                this.setUrl(servicesMSMS + '/getfile.php?i=' + 'shout0' + valueID);
                                            }
                                            else {
                                                this.setUrl(servicesMSMS + '/getfile.php?i=' + 'shout' + valueID);
                                            }
                                        } // handler
                                    },
                                    {
                                        itemId: 'fileLoadBtn',
                                        xtype: 'fileupload',
                                        style: 'margin: 5px; height: 100px;',
                                        iconCls: 'add',
                                        autoUpload: true,
                                        loadAsDataUrl: true,
                                        states: {
                                            browse: {
                                                text: 'Upload assets'
                                            },
                                            ready: {
                                                text: 'Load'
                                            },
                                            uploading: {
                                                text: 'Loading',
                                                loading: true
                                            }
                                        },
                                        flex: 1
                                        // For success and failure callbacks setup look into controller
                                    },
//                                    {
//                                        xtype: 'button',
//                                        text: 'Convert',
//                                        cls: 'mainBtn',
//                                        action: 'uploadFile',
//                                        style: 'margin: 5px',
//                                        flex: 1
//                                    },
//                                    {
//                                        xtype: 'button',
//                                        //text: 'Assets',
//                                        iconCls: 'ss-picture',
//                                        iconAlign:'center',
//                                        action: 'uploadAssets',
//                                        style: 'margin: 5px; height: 100px;',
//                                        flex: 1
//                                    },
                                    {
                                        layout: 'vbox',

                                        items: [
                                            {
                                                xtype: 'button',
                                                text: 'Save',
                                                action: 'updateIssue',
                                                ui: 'confirm',
                                                align: 'right',
                                                style: 'margin: 5px',
                                                flex: 1
                                            },
                                            {
                                                xtype: 'button',
                                                text: 'delete',
                                                style: 'margin: 5px',
                                                itemId: 'deleteIssue',
                                                action: 'deleteIssue',
                                                ui: 'decline',
                                                flex: 1
                                            }
//                                    {
//
////                                        layout: 'hbox',
////                                        items: [
////                                            {
//                                        xtype: 'button',
//                                        text: 'edit',
//                                        style: 'margin: 5px',
//                                        itemId: 'editIssue',
//                                        action: 'editIssue',
//                                        flex: 1
//                                    },
//                                            {
//                                                xtype: 'button',
//                                                text: 'save',
//                                                itemId: 'saveIssue',
//                                                action: 'saveIssue',
//                                                hidden: true,
//                                                flex: 1
//                                            }

                                        ],
                                        flex: 3
                                    }

                                ]
                            }

                        ],
                        flex: 1
                    },
                    {
                        layout: 'vbox',

                        items: [
                            {
                                itemId: 'loadedImage',
                                xtype: 'img',
                                name: 'thumbnail',
                                cls: 'thumbnailImage',
                                style: 'margin-top:11px; margin-left:30px; margin-right:30px;'
                            },
                            {
                                xtype: 'button',
                                action: 'downloadPdf',
                                iconCls: 'ss-download',
                                style: 'margin-left: 30px; width: 212px;'
                            }
                        ]
                    }
                ],
                flex: 1
            }
        ]
    }

});
