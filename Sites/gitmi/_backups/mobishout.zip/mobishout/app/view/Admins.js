Ext.define('MobiShout_Admin.view.Admins', {
    extend: 'Ext.NavigationView',
    xtype: 'admins',

    config: {

        navigationBar: {
            hidden: true
        },

        items: [
            {
              //  cls: 'loginCard',
                title: 'Login',
                //  iconCls: 'user',
                layout: {type: 'vbox', align: 'center', pack: 'center'},
                defaults: {
                    margin: 5,
                    readOnly: true
                },
                items: [
                    {
                        xtype: 'textfield',
                        name: 'username',
                        itemId: 'usernameField',
                        //label: '<span style="font-family: SSStandard">&#x1F464;</span>',
                        label: '&#x1F464;',
                        labelCls: 'ss-icon',
                        labelWidth: 40,
                        id: 'logEmail',
                        placeHolder: 'mobishout',
                        cls: 'adminFields',
                        width: 300
                    },
                    {
                        xtype: 'button',
                        text: 'logout',
                        action: 'logout',
                        cls: 'logoutBtn'
                    }
                ]
            }]}
});
