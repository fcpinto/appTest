Ext.define('MobiShout_Admin.view.ViewCards', {

    extend: 'Ext.Container',
    xtype: 'viewCards',

    config: {

        layout: 'card',
        activeItem: 'home',
        items: [
            {
//                showAnimation: {type: 'slide', direction: 'left', duration: 300},
//                hideAnimation: {type: 'slide', direction: 'left', duration: 300, out: true},
                showAnimation: {type: 'fade', duration: 200},
                hideAnimation: {type: 'fade', duration: 200, out: true},
                xtype: 'main',
                itemId: 'mainCard'
            },
            {
                showAnimation: 'fade',
                xtype: 'home',
                itemId: 'home'
            },
            {
                showAnimation: 'fade',
                xtype: 'admins',
                itemId: 'adminsCard'
            },
            {
                showAnimation: {type: 'fade', duration: 200},
                hideAnimation: {type: 'fade', duration: 200, out: true},
                style: 'text-align: center',
                xtype: 'issues',
                itemId: 'issuesCard'
            },
            {
                showAnimation: {type: 'fade', duration: 200},
                hideAnimation: {type: 'fade', duration: 200, out: true},
                xtype: 'selectedIssue',
                itemId: 'selectedIssue'
            }
        ]
    }
});
