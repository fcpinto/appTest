Ext.define('MobiShout_Admin.view.Ad', {

    extend: 'Ext.form.Panel',
    xtype: 'ad',

    config: {
        items: [
            {
                xtype: 'fieldset',
                title: 'Ad',
                items: [
                    {
                        xtype: 'textfield',
                        label: 'Delay',
                        name: 'delay'
                    },
                    {
                        xtype: 'textfield',
                        label: 'Link',
                        name: 'link'
                    }
                ]
            },
            {
                xtype:'button',
                text:'save',
                action:'saveAd',
                margin:10
            }
        ]
    }
});