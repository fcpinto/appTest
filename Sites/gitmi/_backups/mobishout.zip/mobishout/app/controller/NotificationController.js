Ext.define('MobiShout_Admin.controller.NotificationController', {
    extend: 'Ext.app.Controller',

    config: {

        refs: {
            form:'notification'
        },

        control: {
            'notification button[action = sendNotification]': {
                tap: 'sendNotification'
            }
        }
    },

    sendNotification: function () {
        console.log();
        this.makeRequest(this.getForm().getValues(), Ext.emptyFn);
    },
    makeRequest:function(values, callback){
        Ext.Viewport.setMasked({xtype: 'loadmask'});

        Ext.data.JsonP.request({
            //http://www.mobi-shout.com/mobishout/mobipromos/web/admin/srv1.1/?q={"Notification_sendNotification":[{"title":"mobishout","message":"message"}]}
            url: servicesMSMS,
            callbackKey: 'callback',

            params: {
                q: Ext.encode({"Notification_sendNotification": [values]})
            },

            success: function (response) {
                console.log(response);
                callback();
                Ext.Viewport.setMasked(false);
            },
            failure: function (error) {
                Ext.Msg.alert('Internet', 'Lost connection', Ext.emptyFn);
                Ext.Viewport.setMasked(false);
            }
        });
    }

});
