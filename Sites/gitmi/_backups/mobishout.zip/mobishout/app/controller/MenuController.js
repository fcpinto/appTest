Ext.define('MobiShout_Admin.controller.MenuController', {

    extend: 'Ext.app.Controller',

    config: {

        refs: {
            menuList: 'menu',
            fileUploadCard: 'menu #fileUploadCard',
            viewCards: 'viewCards',
            'newIssueCard': 'viewCards #mainCard',
            'selectedIssueCard': 'viewCards #selectedIssue',
            'issuesCard': 'viewCards #issuesCard',
            'hideMenuBtn': 'menu #hideMenuBtn',
            'profileImg': 'menu #profileImg',
            'logoutBtn': 'menu #logout',
            'userLabel': 'menu #userLabel'
        },

        control: {
            menuList: {itemtap: 'menuTap'},
            'menu button[action = pushList]': {tap: 'pushList'},
            'menu button[action = hideMenu]': {tap: 'hideMenu'},
            'menu button[action = logout]': {tap: 'logoutFn'}

        },
        menuFlag: false
    },

    pushList: function () {
        if (this.getMenuList().isHidden()) {
            //    this.getMenuList().show();
            //    this.getFileUploadCard().setMasked(true);
        }
        else {
            //  this.getMenuList().hide();
            //   this.getFileUploadCard().setMasked(false);
        }
    },

    menuTap: function (dataview, index, target, record, e, options) {
        if (record.data.title.toLowerCase() == 'issues') {
            this.getIssuesCard().show()
        }
        this.getViewCards().setActiveItem(record.data.title.toLowerCase());
        this.getNewIssueCard().hide(),
            this.getSelectedIssueCard().hide()
    },

    hideMenu: function (dataview, index, target, record, e, options) {

        if (!this.menuFlag) {
            this.getMenuList().setWidth(57);
            this.menuFlag = true;
            this.getProfileImg().setWidth(50);
            this.getProfileImg().setHeight(50);
            this.getHideMenuBtn().setIconCls('ss-fwd'),
            this.getUserLabel().hide();
            this.getLogoutBtn().setText('<span style="font-size: 70%;">logout</span>');
        } else {
            this.getMenuList().setWidth(200);
            this.menuFlag = false;
            this.getProfileImg().setWidth(100);
            this.getProfileImg().setHeight(100);
            this.getLogoutBtn().setText('logout');
            this.getUserLabel().show();
            this.getHideMenuBtn().setIconCls('ss-back')
        }

    },

    logoutFn: function () {
        localStorage.clear();
        Ext.Viewport.setActiveItem('login');
    }
});
