Ext.define('MobiShout_Admin.controller.AdController', {
    extend: 'Ext.app.Controller',

    config: {

        refs: {
            form:'ad'
        },

        control: {
            'ad button[action = saveAd]': {
                tap: 'saveAd'
            }
        }
    },

    saveAd: function () {
        console.log(this.getForm().getValues());
    }

});
