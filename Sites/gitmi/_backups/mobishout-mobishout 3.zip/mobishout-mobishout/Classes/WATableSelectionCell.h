//
//  WATableSelectionCell.h
//  Librelio
//
//  Created by Volodymyr Obrizan on 01.03.12.
//  Copyright (c) 2012 WidgetAvenue - Librelio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WATableSelectionCell : UITableViewCell

@end
