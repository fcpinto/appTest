//  Copyright 2011 WidgetAvenue - Librelio. All rights reserved.
//

#import "WAParserProtocol.h"



@interface WAZippedHtmlParser : NSObject <WAParserProtocol> {
	
	NSString * urlString;
    int intParam;
	
	
}



@end
