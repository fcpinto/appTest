//  Copyright 2011 WidgetAvenue - Librelio. All rights reserved.

#import <UIKit/UIKit.h>

/**
 *	@brief Manages cells for WAThumbnialsView
 **/
@interface WAThumbnailCell : UITableViewCell {

}

@end
