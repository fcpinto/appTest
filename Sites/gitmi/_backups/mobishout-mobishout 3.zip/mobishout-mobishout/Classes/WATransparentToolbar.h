//
//  TransparentToolbar.h
//  Librelio
//
//  Copyright (c) 2011 WidgetAvenue - Librelio. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface WATransparentToolbar : UIToolbar

@end
