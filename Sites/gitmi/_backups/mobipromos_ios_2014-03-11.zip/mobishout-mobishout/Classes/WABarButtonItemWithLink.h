//
//  WABarButtonItemWithLink.h
//  Librelio
//
//  Copyright (c) 2011 WidgetAvenue - Librelio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WABarButtonItemWithLink : UIBarButtonItem{
	NSString *link;
}
@property (nonatomic, retain) NSString *link;


@end
