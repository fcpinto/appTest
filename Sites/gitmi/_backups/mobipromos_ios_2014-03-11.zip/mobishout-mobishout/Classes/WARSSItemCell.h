//  Copyright 2011 WidgetAvenue - Librelio. All rights reserved.


@interface WARSSItemCell : UITableViewCell {
}


@end
