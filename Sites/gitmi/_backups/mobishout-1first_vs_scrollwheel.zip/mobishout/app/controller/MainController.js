Ext.define('MobiShout_Admin.controller.MainController', {
    extend: 'Ext.app.Controller',

    requires: [
        'Ext.device.Notification',
        'Ext.Img'
    ],

    config: {
        refs: {
            dataview: 'issues dataview',
            'fileBtn': 'main #fileBtn',
            'fileBtn2': 'selectedIssue #fileBtn',
            'main': 'main',
            'mainFieldset': 'main fieldset',
            'mainFieldtext': 'main #issue_id',
            'selectedFieldtext': 'selectedIssue #issue_id',
            'fileLoadBtn': 'main #fileLoadBtn',
            'fileLoadBtn2': 'selectedIssue #fileLoadBtn',
            'loadedImage': 'main #loadedImage',
            'loadedImageSelected': 'selectedIssue #loadedImage',
            'issuesCard': 'viewCards #issuesCard',
            'newIssueCard': 'viewCards #mainCard',
            'selectedIssue': 'viewCards #selectedIssue',
            'editIssueBtn': 'selectedIssue #editIssue',
            'saveIssueBtn': 'selectedIssue #saveIssue',
            'issueId': 'selectedIssue #issue_id'
        },

        control: {

            dataview: {itemtap: 'onitemtapDataview'},
            'issues button[action = newIssue]': {tap: 'newIssue'},
            'main button[action = backToIssues]': {tap: 'deleteFolder'},
            //  'main button[action = uploadFile]': {tap: 'uploadFile'},
            'selectedIssue button[action = backToIssues]': {tap: 'backToIssues'},
            'selectedIssue button[action = editIssue]': {tap: 'editIssue'},
            'selectedIssue button[action = saveIssue]': {tap: 'editIssue'},
            'selectedIssue button[action = deleteIssue]': {tap: 'deleteIssue'},
            'main button[action = deleteFolder]': {tap: 'deleteFolder'},
            'selectedIssue button[action = updateIssue]': {tap: 'updateIssue'},
            'main button[action = saveIssue]': {tap: 'updateIssue'},


            fileBtn: {
                success: 'onFileUploadSuccess',
                failure: 'onFileUploadFailure'
            },

            fileBtn2: {
                success: 'onFileUploadSuccess2',
                failure: 'onFileUploadFailure'
            },

            fileLoadBtn: {
                loadsuccess: 'onFileLoadSuccess',
                loadfailure: 'onFileLoadFailure'
            },

            fileLoadBtn2: {
                loadsuccess: 'onFileLoadSuccess',
                loadfailure: 'onFileLoadFailure'
            }
        },
        issueFormDisabled: true
    },

    onFileUploadSuccess: function () {
        var image = "";
        var values = this.getNewIssueCard().getValues();

        this.getLoadedImage().setSrc(image);

        Ext.device.Notification.show({
            title: 'All right',
            message: 'File uploaded successfully',
            buttons: Ext.MessageBox.OK,
            callback: Ext.emptyFn
        });

        console.log('img');
        console.log(this.getMainFieldset().getTitle());

        image = servicesMSMSroot + this.getMainFieldset().getTitle() + "/" + btoa(this.getMainFieldset().getTitle()) + ".png";

        image = image.replace("=", "");

        this.getLoadedImage().setSrc(image);
    },


    onFileUploadSuccess2: function () {
        var image = "";
        var values = this.getNewIssueCard().getValues();

        this.getLoadedImage().setSrc(image);

        Ext.device.Notification.show({
            title: 'All right',
            message: 'File uploaded successfully',
            buttons: Ext.MessageBox.OK,
            callback: Ext.emptyFn
        });

        var value = this.getSelectedFieldtext().getValue();

        value = value.replace("shout", "");

        if (value.length == 1) {
            value = 'shout00' + value
        }
        if (value.length == 2) {
            value = 'shout0' + value
        }

        console.log(value);

        image = servicesMSMSroot + value + "/" + btoa(value) + ".png";

        image = image.replace("=", "");
        console.log(image);

        this.getLoadedImageSelected().setSrc(image);
    },

    onFileUploadFailure: function (message) {
        console.log('Failure');

        Ext.device.Notification.show({
            title: 'Uploading error',
            message: message,
            buttons: Ext.MessageBox.OK,
            callback: Ext.emptyFn
        });
    },

    onFileLoadSuccess: function (dataurl, e) {
        var me = this;
        var image = me.getLoadedImage();
        var image2 = me.getLoadedImageSelected();
        image.setSrc(dataurl);
        image2.setSrc(dataurl);

    },

    onFileLoadFailure: function (message) {
        Ext.device.Notification.show({
            title: 'Loading error',
            message: message,
            buttons: Ext.MessageBox.OK,
            callback: Ext.emptyFn
        });
    },

    backToIssues: function () {
        //     Ext.Msg.confirm("Confirmation", "Are you sure you want to delete?", Ext.bind(this.delFolder, this));
        this.getNewIssueCard().hide(),
            this.getSelectedIssue().hide(),
            this.getIssuesCard().show(),
            Ext.getStore('IssuesStore').load();

    },

    editIssue: function (btn) {

        var array = this.getSelectedIssue().query('field');

        if (!this.getIssueFormDisabled()) {
            for (var i in array) {
                array[i].setReadOnly(true);
            }

            this.getEditIssueBtn().show();
            this.getSaveIssueBtn().hide();

            this.setIssueFormDisabled(true);

        } else {
            for (var i in array) {
                array[i].setReadOnly(false);
                this.getIssueId().setReadOnly(true);
            }
            this.getEditIssueBtn().hide();
            this.getSaveIssueBtn().show();

            this.setIssueFormDisabled(false);
        }
    },

    onitemtapDataview: function (list, index, target, record, e) {
        if ((e.target.className == 'activeState') || (e.target.className == 'deactiveState')) {

            var values = record.data;

            if (record.data.active == '1') {
                values.active = '0'
            }
            else {
                values.active = '1'
            }

            Ext.Viewport.setMasked(
                {
                    xtype: 'loadmask'
                });

            Ext.Ajax.request({

                method: 'POST',
                url: servicesMSMS,

                params: {
                    q: Ext.encode({"Issues_setIssue": [values],  "CreatePlist_create": [{}]})
                },

                success: function (response, request) {
               //     Ext.getStore('IssuesStore').load();
                    record.set('active', values.active);
                    Ext.Viewport.setMasked(false);
                },

                failure: function () {
                    Ext.Msg.alert('Info', 'Something went wrong!', Ext.emptyFn);
                    record.set('active', values.active=0?1:0);
                    Ext.Viewport.setMasked(false);
                }
            });
        } else {
            var me = MobiShout_Admin.app.getController('MainController');
            me.getSelectedIssue().show();
            me.getIssuesCard().hide();
            var params = record.data;
            this.getSelectedIssue().setValues(params);
            this.getSelectedIssue().down('img').setSrc(params.thumbnail);
        }
    },

    newIssue: function (list, index, target, record) {

        this.getNewIssueCard().show(),
            this.getIssuesCard().hide(),

            this.getLoadedImage().setSrc("");

        var array = this.getMain().query('field');

        for (var i in array) {
            array[i].setValue("");
        }

        Ext.data.JsonP.request({

            url: servicesMSMS,
            callbackKey: 'callback',

            params: {
                q: Ext.encode({"Issues_newIssueFolder": [
                    {}
                ]})
            },

            success: function (response, request) {
                var params = "shout" + response.Issues_newIssueFolder;
                var paramID = response.Issues_newIssueFolder;

                MobiShout_Admin.app.getController('MainController').getMainFieldset().setTitle(params);
                Ext.Viewport.setMasked(false);
            },

            failure: function () {
                Ext.Msg.alert('Info', 'Something went wrong, unable to create folder!', Ext.emptyFn);
                Ext.Viewport.setMasked(false);
            }
        });
    },

    updateIssue: function (btn) {

        this.getNewIssueCard().hide();
        this.getIssuesCard().show();

        if (btn.getText() == 'Save') {
            var values = this.getSelectedIssue().getValues();
            values.thumbnail = this.getLoadedImageSelected().getSrc();
        }

        if (btn.getText() == 'Create Shout') {
            var values = this.getMain().getValues();
            values.thumbnail = this.getLoadedImage().getSrc();
            values.issue_id = this.getMainFieldset().getTitle().replace("shout", "");
        }

        Ext.Viewport.setMasked(
            {
                xtype: 'loadmask'
            });

        Ext.Ajax.request({

            method: 'POST',
            url: servicesMSMS,

            params: {
                q: Ext.encode({"Issues_setIssue": [values]})
            },

            success: function (response, request) {
                Ext.Msg.alert('Info', 'Issue has been saved successfully!', Ext.emptyFn);
                Ext.getStore('IssuesStore').load();
                Ext.Viewport.setMasked(false);
            },

            failure: function () {
                Ext.Msg.alert('Info', 'Something went wrong, unable to create folder!', Ext.emptyFn);
                Ext.getStore('IssuesStore').load();
                Ext.Viewport.setMasked(false);
            }
        });

        Ext.Ajax.request({

            method: 'POST',
            url: servicesMSMS,

            params: {
                q: Ext.encode({"CreatePlist_create": [
                    {}
                ]})
            },

            success: function (response, request) {
                Ext.getStore('IssuesStore').load();
                Ext.Viewport.setMasked(false);
            },

            failure: function () {
                Ext.Msg.alert('Info', 'Something went wrong, unable to create plist!', Ext.emptyFn);
                Ext.getStore('IssuesStore').load();
                Ext.Viewport.setMasked(false);
            }
        });
    },

    setIssue: function (list, index, target, record) {

        this.getNewIssueCard().hide();
        this.getIssuesCard().show();

        var values = this.getMain().getValues();

        var issueIdValue = MobiShout_Admin.app.getController('MainController').getMainFieldset().getTitle();

        values.issue_id = issueIdValue.replace("shout", "");

        Ext.Viewport.setMasked(
            {
                xtype: 'loadmask'
            });

        Ext.data.JsonP.request({

            url: servicesMSMS,
            callbackKey: 'callback',

            params: {
                q: Ext.encode({"Issues_setIssue": [values]})
            },

            success: function (response, request) {
                console.log(response);

                Ext.Msg.alert('Info', 'Issue has been saved successfully!', Ext.emptyFn);
                Ext.getStore('IssuesStore').load();
                Ext.Viewport.setMasked(false);
            },

            failure: function () {
                Ext.Msg.alert('Info', 'Something went wrong, unable to create folder!', Ext.emptyFn);
                Ext.Viewport.setMasked(false);
            }
        });
    },

    deleteFolder: function (e) {

        Ext.Msg.confirm("Confirmation", "Are you sure you want to delete?", Ext.bind(this.delFolder, this));
    },

    delFolder: function (e) {

        if (e == 'yes') {
            this.getNewIssueCard().hide();
            this.getIssuesCard().show();

            Ext.data.JsonP.request({

                url: servicesMSMS,
                callbackKey: 'callback',

                params: {
                    q: Ext.encode({"Issues_deleteIssueFolder": [
                        {}
                    ]})
                },

                success: function (response, request) {
                       Ext.getStore('IssuesStore').load();
                },

                failure: function () {

                }
            });

            Ext.Ajax.request({

                method: 'POST',
                url: servicesMSMS,

                params: {
                    q: Ext.encode({"CreatePlist_create": [
                        {}
                    ]})
                },

                success: function (response, request) {
                    Ext.getStore('IssuesStore').load();
                    Ext.Viewport.setMasked(false);
                },

                failure: function () {
                    Ext.Viewport.setMasked(false);
                }
            });
        }
    },

    deleteIssue: function (e) {

        Ext.Msg.confirm("Confirmation", "Are you sure you want to delete this issue?", Ext.bind(this.delService, this));
    },

    delService: function (e) {

        var value = this.getSelectedIssue().getValues().issue_id;

        console.log(value);

        if (e == 'yes') {

            this.getSelectedIssue().hide();
            this.getIssuesCard().show();

            Ext.data.JsonP.request({

                url: servicesMSMS,
                callbackKey: 'callback',

                params: {
                    q: Ext.encode({"Issues_deleteIssue": [
                        {"issue_id": value}
                    ]})
                },

                success: function (response, request) {
                    console.log(response);
                    Ext.Msg.alert('Info', 'Issue has been deleted successfully!', Ext.emptyFn);
                    Ext.getStore('IssuesStore').load();
                    Ext.Viewport.setMasked(false);
                },

                failure: function () {
                    Ext.Msg.alert('Info', 'Something went wrong!', Ext.emptyFn);
                    Ext.Viewport.setMasked(false);
                }
            });

            Ext.Ajax.request({

                method: 'POST',
                url: servicesMSMS,

                params: {
                    q: Ext.encode({"CreatePlist_create": [
                        {}
                    ]})
                },

                success: function (response, request) {
                    Ext.getStore('IssuesStore').load();
                    Ext.Viewport.setMasked(false);
                },

                failure: function () {
                    Ext.Viewport.setMasked(false);
                }
            });
        }
    }
});
