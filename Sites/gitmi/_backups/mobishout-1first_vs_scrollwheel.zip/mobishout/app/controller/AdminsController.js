Ext.define('MobiShout_Admin.controller.AdminsController', {

    extend: 'Ext.app.Controller',

    requires: [

    ],

    config: {

        refs: {
        },

        control: {
            'admins button[action = logout]': {tap: 'logout'}
        }
    },

    logout: function () {
        localStorage.clear();
        Ext.Viewport.setActiveItem('login');
    }


});
