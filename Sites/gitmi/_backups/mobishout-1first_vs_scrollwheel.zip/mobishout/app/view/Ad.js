Ext.define('MobiShout_Admin.view.Ad', {

    extend: 'Ext.Container',
    xtype: 'ad',

    config: {
        //  tabBarPosition: 'bottom',

        navigationBar: {
            hidden: true
        },
        scrollable:true,
        items: [
            {
                layout: {type: 'vbox', pack: 'center', align: 'center'},
                cls: 'home',
                //style:'background-repeat: no-repeat;background-size: auto 100%;background-position: center;',
                items: {
                    style: 'text-align: center;',
                    html: [
                       // <div>About Page</div>
                        '<img width="100%" src="resources/images/mobishout.png" />',
                        '<div>Ad view</div>'
                    ].join("")
                }

            },
            {
                xtype: 'container',
                html: 'Cras mattis consectetur purus sit amet fermentum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Vestibulum id ligula porta felis euismod semper. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Sed posuere consectetur est at lobortis. Donec ullamcorper nulla non metus auctor fringilla.<br><br>Cras mattis consectetur purus sit amet fermentum. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Aenean lacinia bibendum nulla sed consectetur. Donec id elit non mi porta gravida at eget metus. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.Cras mattis consectetur purus sit amet fermentum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Vestibulum id ligula porta felis euismod semper. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Sed posuere consectetur est at lobortis. Donec ullamcorper nulla non metus auctor fringilla.<br><br>Cras mattis consectetur purus sit amet fermentum. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Aenean lacinia bibendum nulla sed consectetur. Donec id elit non mi porta gravida at eget metus. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.'
            }
        ]
    }
});