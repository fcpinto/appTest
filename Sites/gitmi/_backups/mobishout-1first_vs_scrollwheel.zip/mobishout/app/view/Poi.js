Ext.define('MobiShout_Admin.view.Poi', {

    extend: 'Ext.NavigationView',
    xtype: 'poi',

    config: {
        //  tabBarPosition: 'bottom',

        navigationBar: {
            hidden: true
        },
        items: [
            {
                layout: {type: 'vbox', pack: 'center', align: 'center'},
                cls: 'home',
                //style:'background-repeat: no-repeat;background-size: auto 100%;background-position: center;',
                items: {
                    style: 'text-align: center;',
                    html: [
                       // <div>About Page</div>
                        '<img width="100%" src="resources/images/mobishout.png" />'
                    ].join("")
                }

            }
        ]
    }
});

