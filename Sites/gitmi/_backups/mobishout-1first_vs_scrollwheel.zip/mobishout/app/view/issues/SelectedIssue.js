Ext.define('MobiShout_Admin.view.issues.SelectedIssue', {
    extend: 'Ext.form.Panel',
    xtype: 'selectedIssue',

    requires: [
        'Ext.TitleBar',
        'Ext.Button',
        'Ext.ux.Fileup'
    ],

    config: {
        navigationBar: {
            hidden: true
        },
        //   tabBarPosition: 'bottom',
        items: [
            {
                xtype: 'toolbar',
                docked: 'top',
                items: [
                    {
                        xtype: 'button',
                        iconCls: 'ss-back',
                        cls: 'toolbarBtn',
                        style: 'border: 0px; background-color: rgba(17, 89, 140, 0);',
                        action: 'backToIssues',
                        align: 'left'
                    },
                    {
                        xtype: 'spacer'
                    }
                ]
            },
            {
                // id: 'welcome',
                title: 'Welcome',
                iconCls: 'home',
                scrollable: null,
                styleHtmlContent: true,

                layout: 'hbox',

                items: [
                    {
                        layout: {
                            type: 'vbox'
                        },
                        defaults: {
                            style: 'margin: 5px;'
                          //  readOnly: true
                        },
                        items: [
                            {
                                xtype: 'textfield',
                                label: 'Shout: ',
                                itemId: 'issue_id',
                                id: 'issueId',
                                name: 'issue_id',
                                placeHolder: 'issueID',
                                readOnly: true
                            },
                            {
                                xtype: 'textfield',
                                label: 'Keywords: ',
                                name: 'keywords'
                            },
                            {
                                xtype: 'textfield',
                                label: 'Title: ',
                                name: 'title'
                            },
                            {
                                xtype: 'textfield',
                                label: 'Subtitle: ',
                                name: 'subtitle'
                            },
                            {
                                xtype: 'textfield',
                                label: 'Description: ',
                                name: 'description'
                            },
                            {
                                xtype: 'textfield',
                                label: 'Filename: ',
                                name: 'filename'
                            },
//                            {
//                                xtype: 'textfield',
//                                name: 'date_start',
//                                label: 'Date Start:',
//                                placeHolder: 'Issue Date',
//
//                                listeners: {
//                                    initialize: function (textfield) {
//                                        var input = textfield.element.dom.getElementsByTagName('input')[0];
//                                        input.type = 'date';
//                                    }
//                                }
//                            },
                            {
                                xtype: 'datepickerfield',
                                dateFormat: 'Y-m-d',
                                name: 'date_start',
                                label: 'Date Start:',
                                picker: {
                                    yearFrom: new Date().getFullYear(),
                                    yearTo: 2020,
                                    slotOrder: ['year', 'month', 'day']
                                }
                            },
//                            {
//                                xtype: 'textfield',
//                                name: 'date_end',
//                                label: 'Date End:',
//                                placeHolder: 'Issue Date',
//
//                                listeners: {
//                                    initialize: function (textfield) {
//                                        var input = textfield.element.dom.getElementsByTagName('input')[0];
//                                        input.type = 'date';
//                                    }
//                                }
//                            },
                            {
                                xtype: 'datepickerfield',
                                dateFormat: 'Y-m-d',
                                name: 'date_end',
                                label: 'Date End:',
                                picker: {
                                    yearFrom: new Date().getFullYear(),
                                    yearTo: 2020,
                                    slotOrder: ['year', 'month', 'day']
                                }
                            },
                            {
                                xtype: 'togglefield',
                                name: 'active',
                                label: 'Active',
                                align: 'right'
                            },
                            {
                                layout: 'hbox',
                                defaults: {
                                    cls: 'mainBtn'
                                },

                                items: [
                                    {
                                        itemId: 'fileBtn',
                                        xtype: 'fileupload',
                                        autoUpload: true,
                                        url: '',
                                        style: 'margin: 5px; height: 100px;',
                                        flex: 1,
                                        handler: function () {

                                            var valueID = Ext.getCmp('issueId').getValue();

                                            var n = valueID.length;

                                            if(n==1){
                                                this.setUrl(servicesMSMS + '/getfile.php?i=' + 'shout00' + valueID);
                                            }
                                            else if(n==2){
                                                this.setUrl(servicesMSMS + '/getfile.php?i=' + 'shout0' + valueID);
                                            }
                                            else{
                                                    this.setUrl(servicesMSMS + '/getfile.php?i=' + 'shout' + valueID);
                                            }
                                        } // handler
                                    },
                                    {
                                        itemId: 'fileLoadBtn',
                                        xtype: 'fileupload',
                                        style: 'margin: 5px; height: 100px;',
                                        iconCls: 'add',
                                        autoUpload: true,
                                        loadAsDataUrl: true,
                                        states: {
                                            browse: {
                                                text: '✓'
                                            },
                                            ready: {
                                                text: 'Load'
                                            },
                                            uploading: {
                                                text: 'Loading',
                                                loading: true
                                            }
                                        },
                                        flex: 1
                                        // For success and failure callbacks setup look into controller
                                    },
//                                    {
//                                        xtype: 'button',
//                                        text: 'Convert',
//                                        cls: 'mainBtn',
//                                        action: 'uploadFile',
//                                        style: 'margin: 5px',
//                                        flex: 1
//                                    },
//                                    {
//                                        xtype: 'button',
//                                        //text: 'Assets',
//                                        iconCls: 'ss-picture',
//                                        iconAlign:'center',
//                                        action: 'uploadAssets',
//                                        style: 'margin: 5px; height: 100px;',
//                                        flex: 1
//                                    },
                                    {
                                        layout: 'vbox',

                                        items: [
                                            {
                                                xtype: 'button',
                                                text: 'Save',
                                                action: 'updateIssue',
                                                ui: 'confirm',
                                                align: 'right',
                                                style: 'margin: 5px',
                                                flex: 1
                                            },
                                            {
                                                xtype: 'button',
                                                text: 'delete',
                                                style: 'margin: 5px',
                                                itemId: 'deleteIssue',
                                                action: 'deleteIssue',
                                                ui: 'decline',
                                                flex: 1
                                            }
//                                    {
//                                        xtype: 'button',
//                                        text: 'Delete',
//                                        action: 'deleteFolder',
//                                        style: 'margin: 5px',
//                                        ui: 'decline',
//                                        flex: 1
//                                    },
//                                    {
//
////                                        layout: 'hbox',
////                                        items: [
////                                            {
//                                        xtype: 'button',
//                                        text: 'edit',
//                                        style: 'margin: 5px',
//                                        itemId: 'editIssue',
//                                        action: 'editIssue',
//                                        flex: 1
//                                    },
//                                            {
//                                                xtype: 'button',
//                                                text: 'save',
//                                                itemId: 'saveIssue',
//                                                action: 'saveIssue',
//                                                hidden: true,
//                                                flex: 1
//                                            }

                                        ],
                                        flex: 3
                                    }

                                ]
                            }

                        ],
                        flex: 1
                    },
                    {
                        itemId: 'loadedImage',
                        xtype: 'img',
                        name: 'thumbnail',
                        cls: 'thumbnailImage',
                        style: 'margin-top:11px; margin-left:30px; margin-right:30px;'
                    }
                ],
                flex: 1
            }
        ]
    }


//    requires: ['Ext.event.Dom'],
//    handledEvents: ['dragstart', 'drag', 'dragend'],
//
//    constructor: function() {
//        this.callParent(arguments);
//
//        this.onMouseWheel = Ext.Function.bind(this.onMouseWheel, this);
//        this.fireDragEnd = Ext.Function.bind(this.fireDragEnd, this);
//
//        document.addEventListener('mousewheel', this.onMouseWheel, true);
//    },
//
//    onMouseWheel: function(e) {
//        var helper = Ext.event.publisher.Dom.prototype,
//            target = helper.getElementTarget(e.target),
//            targets = helper.getBubblingTargets(target),
//            deltaX = e.hasOwnProperty('wheelDeltaX') ? e.wheelDeltaX : e.wheelDelta,
//            deltaY = e.hasOwnProperty('wheelDeltaY') ? e.wheelDeltaY : e.wheelDelta,
//            touches = [
//                {
//                    targets: targets
//                }
//            ],
//            lastPoint, time;
//
//        e = new Ext.event.Dom(e);
//        time = e.time;
//
//        this.lastEvent = e;
//        this.lastTouches = touches;
//
//        if (!this.startPoint) {
//            this.startTime = time;
//            this.startPoint = lastPoint = {
//                x: e.pageX,
//                y: e.pageY
//            };
//
//            this.previousPoint = lastPoint;
//            this.previousTime = time;
//
//            this.lastPoint = lastPoint;
//            this.lastTime = time;
//
//            this.fireAction('dragstart', e, touches, this.getInfo(e));
//        }
//
//        lastPoint = this.lastPoint;
//
//        this.previousTime = this.lastTime;
//        this.previousPoint = lastPoint;
//
//        this.lastPoint = {
//            x: lastPoint.x + deltaX,
//            y: lastPoint.y + deltaY
//        };
//        this.lastTime = time;
//
//        this.fireAction('drag', e, touches, this.getInfo(e));
//
//        clearTimeout(this.dragEndTimer);
//        this.dragEndTimer = setTimeout(this.fireDragEnd, 50);
//    },
//
//    fireDragEnd: function() {
//        var e = this.lastEvent;
//
//        this.fireAction('dragend', e, this.lastTouches, this.getInfo(e));
//
//        this.startTime = 0;
//        this.previousTime = 0;
//        this.lastTime = 0;
//
//        this.startPoint = null;
//        this.previousPoint = null;
//        this.lastPoint = null;
//        this.lastMoveEvent = null;
//        this.lastEvent = null;
//        this.lastTouches = null;
//    },
//
//    getInfo: function(e, touch) {
//
//        var slowCoefficient = .1,
//            time = e.time,
//            startPoint = this.startPoint,
//            previousPoint = this.previousPoint,
//            startTime = this.startTime,
//            previousTime = this.previousTime,
//            point = this.lastPoint,
//            deltaX = (point.x - startPoint.x) * slowCoefficient,
//            deltaY = (point.y - startPoint.y) * slowCoefficient,
//            previousDeltaX = (point.x - previousPoint.x) * slowCoefficient,
//            previousDeltaY = (point.y - previousPoint.y) * slowCoefficient;
//
//        // Adjust points to lowered deltas
//        point.x += deltaX;
//        point.y += deltaY;
//        previousPoint.x += previousDeltaX;
//        previousPoint.y += previousDeltaY;
//
//        return {
//            flick: {
//                velocity: {
//                    x: 0,
//                    y: 0
//                }
//            },
//            touch: touch,
//            startX: startPoint.x,
//            startY: startPoint.y,
//            previousX: previousPoint.x,
//            previousY: previousPoint.y,
//            pageX: point.x,
//            pageY: point.y,
//            deltaX: deltaX,
//            deltaY: deltaY,
//            absDeltaX: Math.abs(deltaX),
//            absDeltaY: Math.abs(deltaY),
//            previousDeltaX: previousDeltaX,
//            previousDeltaY: previousDeltaY,
//            time: time,
//            startTime: startTime,
//            previousTime: previousTime,
//            deltaTime: time - startTime,
//            previousDeltaTime: time - previousTime
//        };
//
//    }
//
//});


});
