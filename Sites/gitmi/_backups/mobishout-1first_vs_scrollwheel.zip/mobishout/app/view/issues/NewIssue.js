Ext.define('MobiShout_Admin.view.issues.NewIssue', {
    extend: 'Ext.NavigationView',
    xtype: 'newIssue',

    requires: [
        'Ext.TitleBar',
        'Ext.Button',
        'Ext.ux.Fileup'
    ],

    config: {

        navigationBar: {
            hidden: true
        },

        //   tabBarPosition: 'bottom',

        items: [
            {
                id: 'welcome',
                title: 'Welcome',
                iconCls: 'home',
                scrollable: null,
                styleHtmlContent: true,

                layout: 'hbox',

                items: [
                    {
                        layout: {
                            type: 'vbox'
                        },
                        defaults: {
                            style: 'margin: 12px;'
                        },
                        items: [
                            {
                                xtype: 'textfield',
                                name: 'fileTitle',
                                placeHolder: 'Title'
                            },
                            {
                                xtype: 'textfield',
                                name: 'fileSubTitle',
                                placeHolder: 'Subtitles'
                            },
                            {
                                xtype: 'textfield',
                                name: 'issueDate',
                                //label: 'Time:',
                                placeHolder: 'Issue Date',

                                listeners: {
                                    initialize: function (textfield) {
                                        var input = textfield.element.dom.getElementsByTagName('input')[0];
                                        input.type = 'date';
                                    }
                                }
                            },
                            {

                                layout: 'hbox',

                                items: [
                                    {
                                        itemId: 'fileBtn',
                                        xtype: 'fileupload',
                                        autoUpload: true,
                                        url: 'src/php/getfile.php',
                                        style: 'margin-right: 10px',
                                        flex: 1
                                    },
                                    {
                                        itemId: 'fileLoadBtn',
                                        xtype: 'fileupload',
                                        autoUpload: true,
                                        loadAsDataUrl: true,
                                        states: {
                                            browse: {
                                                text: 'Select Thumbnail'
                                            },
                                            ready: {
                                                text: 'Load'
                                            },
                                            uploading: {
                                                text: 'Loading',
                                                loading: true
                                            }
                                        },
                                        flex: 1
                                        // For success and failure callbacks setup look into controller
                                    }
                                ]
                            }
                        ],
                        flex: 1
                    },
                    {
                        itemId: 'loadedImage',
                        xtype: 'img',
                        // width: '80%',
                        height: '200px',
                        style: 'margin-top:15px;',

                        flex: 1
                    }
                ]
            }
        ]
    }
});
