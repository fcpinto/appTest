Ext.define('MobiShout_Admin.store.IssuesStore', {

    extend: 'Ext.data.Store',

        requires: [
            'Ext.data.proxy.JsonP'
        ],

        config: {
            model: 'MobiShout_Admin.model.IssuesModel',

            sorters:'issue_id',
                  //  Ext.Date.format(new Date(), 'Y-m-d H:i');

            proxy: {
                type: "jsonp",
                url: servicesMSMS,
                pageParam: false,
                limitParam: false,
                startParam: false,

                extraParams: {
                    q: Ext.encode({
                        "Issues_getIssues": []
                    })
                },

                callbackKey: 'callback',
                reader: {
                    type: "json",
                    rootProperty: "Issues_getIssues"
                }
            },
            autoLoad: true,
            listeners: {
                beforeload: function (store, records, successful) {
                    Ext.Viewport.setMasked({xtype:"loadmask"})
                },
                load: function (store, records, successful) {
                 Ext.Viewport.setMasked();
                }
            }
        }
    });
























//    config: {
//
//        model: 'MobiShout_Admin.model.IssuesModel',
//        // sorters: 'lastName',
//
////    //GROUPED LIST
////    grouper: {
////        groupFn: function(record) {
////            return record.get('lastName')[0];
////        }
////    },
//
////        proxy: {
////            type: 'memory'
////        },
//        data: [
//            {icon: '&#x2302;' ,title: 'Home'},
//            {icon: '&#x1F4DD;',title: 'Issues'},
//            {icon: '&#x1F465;',title: 'Admins'},
//            {icon: '&#xE570;',title: 'Analytics'},
//            {icon: '&#x2139;',title: 'About'}
//
//        ]
//
//
//    }
//
//
//});