/**
 * Created by zul on 06/03/14.
 */
Ext.define("MobiShout_Admin.util.TimePicker", {
    extend: "Ext.field.Text",
    xtype: "timepickerfield",

    config: {
        ui: 'select',
        clearIcon: false,
        destroyPickerOnHide: false
    },

    initialize: function () {

        var me = this,
            component = me.getComponent();

        me.callParent();

        component.on({
            scope: me,
            masktap: 'onMaskTap'
        });


        component.doMaskTap = Ext.emptyFn;

        if (Ext.browser.is.AndroidStock2) {
            component.input.dom.disabled = true;
        }
    },

    getPicker: function() {
        var picker = this._picker,
            values = this.getValue().split(':'),
            me = this;

        //console.log(picker);
        if (!picker) {
            picker = Ext.create("Ext.Picker", {
                hidden: true,
                zIndex: 9999,
                slots: [
                    {
                        name: "hours",
                        title: "Hours",
                        data: me.getHoursSlot()
                    },
                    {
                        name: "minutes",
                        title: "Minuts",
                        data: me.getMinutesSlot()
                    }/*,
                    {
                        name: "AMPM",
                        title: "am/pm",
                        data: me.getAmPmSlot()
                    }*/
                ]
            });

        }
        if (values != null) {
            picker.setValue({hours:values[0],minutes:values[1]});
        }

        picker.on({
            scope: this,
            change: 'onPickerChange',
            hide  : 'onPickerHide'
        });

        this._picker = picker;

        return picker;
    },

    onMaskTap: function() {
        if (this.getDisabled()) {
            return false;
        }

        this.onFocus();

        return false;
    },

    onPickerChange: function(picker, value) {
        console.log(value)
        var me = this,
            oldValue = me.getValue();

        me.setValue(value.hours + ':' + value.minutes);
        me.fireEvent('select', me, value);
        me.onChange(me, value, oldValue);
    },

    onChange: Ext.emptyFn,

    onPickerHide: function() {
        var me     = this,
            picker = me.getPicker();

        if (me.getDestroyPickerOnHide() && picker) {
            picker.destroy();
            me._picker = me.getInitialConfig().picker || true;
        }
    },

    reset: function() {
        this.setValue(this.originalValue);
    },

    onFocus:function(e){
        var component = this.getComponent();
        this.fireEvent('focus', this, e);

        if (Ext.os.is.Android4) {
            component.input.dom.focus();
        }
        component.input.dom.blur();

        if (this.getReadOnly()) {
            return false;
        }

        this.isFocused = true;

        this.getPicker().show();
    },

    getHoursSlot:function(){

        var data_hours = [],
            interval = 1;
        for (var i = 0; i < 24; (i+=interval)) {
            data_hours.push({
                text: Ext.String.leftPad(i, 2, '0'),
                value: Ext.String.leftPad(i, 2, '0')
            });
        }
        return data_hours;

    },

    getMinutesSlot:function(){

        var data_minuts = [],
            interval = 15;
        for (var i = 0; i < 60; (i+=interval)) {
            data_minuts.push({
                text: Ext.String.leftPad(i, 2, '0'),
                value: Ext.String.leftPad(i, 2, '0')
            });
        }
        return data_minuts;

    },

    getAmPmSlot: function () {

        var data_AMPM = [
            {
                text: 'AM',
                value: 'AM'
            },
            {
                text: 'PM',
                value: 'PM'
            }
        ]

        return data_AMPM;
    }
});
