/**
 * Created by zul on 07/03/14.
 */

Ext.define('MobiShout_Admin.util.ScrollWheel', {
    override: 'Ext.scroll.Scroller',

    applyElement: function (element) {
        if (!element) {
            return;
        }
        this.wheelEvent(element);
        return Ext.get(element);
    },
    wheelEvent: function (element) {
        if (Ext.os.is.Desktop) {
            var scroller = this,
                move = 0,
                direction = '',
                moveIt = function (evt) {
                    direction = (scroller._direction == 'horizontal') ? 'x' : 'y';
                    move = scroller.position[direction] - (evt.wheelDelta / 10);
                    if (move > scroller.maxPosition[direction]) {
                        move = scroller.maxPosition[direction];
                    }
                    else if (move < scroller.minPosition[direction]) {
                        move = scroller.minPosition[direction];
                    }
                    scroller.scrollTo((direction == 'x') ? move : scroller.position.x, (direction == 'y') ? move : scroller.position.y, true);
                };

            element.dom.addEventListener('mousewheel', moveIt, true);
        }
    }
});