//
//  WARootViewController.h
//  Librelio
//
//  Created by Emmanuel on 11/09/13.
//  Copyright (c) 2013 WidgetAvenue - Librelio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WARootViewController : UITabBarController

@end
