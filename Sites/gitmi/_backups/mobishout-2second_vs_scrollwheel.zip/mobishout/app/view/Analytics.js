Ext.define('MobiShout_Admin.view.Analytics', {

    extend: 'Ext.NavigationView',
    xtype: 'analytics',

    config: {
        //  tabBarPosition: 'bottom',

        navigationBar: {
            hidden: true
        },
        items: [
            {
                layout: {type: 'vbox', align: 'center', pack: 'top'},
                style: 'margin: 20px',
                cls: 'analyticsContainer',
                items: [
                    {
                        xtype: 'img',
                        src: 'http://infotrustllc.com/wp-content/uploads/2014/01/google-analytics-logo.png',
                        style: 'margin-top: 20px; margin-bottom: 20px;',
                        height: '118px',
                        width: '100%'

                    },
                    {
                        xtype: 'container',
                        cls: 'analyticsText',
                        html: ['<div> <b>mobiSHOUT</b> is integrated with Google Analytics. To access your app Google Analytics account please use the following credentials:</div>' +
                            '</br>' +
                            '<div>' +
                            '<b>User:</b> mobishoutvozdamadeira@gmail.com</div><div>' +
                            '<b>Pass:</b> v0zdamadeira14</div>'
                        ]
                    },
                    {
                        layout: {type: 'vbox', align: 'center', pack: 'top'},
                        items: [
                            {
                                xtype: 'button',
                                style: 'margin-top: 100px;',
                                text: 'Access Google Analytics',
                                cls: 'googleAnalyticsBtn',
                                    listeners : {
                                        tap: function() {
                                            window.open('http://www.google.com/Analytics/');
                                        }
                                    }
                            }
                        ]
                    }

                    //{
                    //  style: 'text-align: center;',

//                    html: [
//                        '<a href="javascript:gi("googleanalyticslogin").submit();"></a>',
//                        '<form id="googleanalyticslogin" action="https://accounts.google.com/ServiceLogin" method="post">',
//                        '<input type="text" name="Email" class="gaia le val" id="Email" size="18" value="mobinteg@gmail.com" />',
//                        '</br><input type="password" name="Passwd" class="gaia le val" id="Passwd" size="18" value="" />',
//                        '<input type="hidden" name="rmShown" value="1" />',
//                        '</br></br><input type="hidden" name="continue" value="http://www.google.com/analytics/web/?et=reset&hl=en-US" />',
//                        '<input type="hidden" name="service" value="analytics" />',
//                        '<input type="hidden" name="nui" value="1" />',
//                        '<input type="hidden" name="hl" value="en-US" />',
//                        '<input type="hidden" name="GA3T" value="oCGYxIWWGUE" />',
//                        '<input type="hidden" name="GALX" value="3Jces-nq404" />',
//                        '<input type="submit" />',
//                        '</form>'].join("")
//                }]

                ]

            }
        ]}
});

/**
 * Created by pmartins on 27-01-2014.
 */
