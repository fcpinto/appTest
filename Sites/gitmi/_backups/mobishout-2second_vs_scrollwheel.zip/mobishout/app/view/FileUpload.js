Ext.define('MobiShout_Admin.view.FileUpload', {
    extend: 'Ext.NavigationView',
    xtype: 'fileUpload',

    requires: [
        'Ext.TitleBar',
        'Ext.Button',
        'Ext.ux.Fileup'
    ],

    config: {
        tabBarPosition: 'bottom',

        navigationBar: {
            hidden: true
        },

        items: [
            {
                id: 'welcome',
                title: 'Welcome',
                iconCls: 'home',
                scrollable: true,
                styleHtmlContent: true,

                layout: {
                    type: 'vbox',
                    align: 'center'
                },

                items: [
//                    {
//                        docked: 'top',
//                        xtype: 'titlebar',
//                        title: 'Upload Files',
//                        hidden: true
//                    },
                    {
                        xtype: 'label',
                        html: 'You can upload file to server',
                        cls: 'fieldsetAddPatient',
                        readOnly: true,
                        align: 'right',
                        flex: 6
                    },

                    {
                        itemId: 'fileBtn',
                        xtype: 'fileupload',
                        autoUpload: false,
                        url: 'src/php/getfile.php'

                        // For success and failure callbacks setup look into controller
                    },

                    {
                        html: 'Or just load locally as DataUrl (for images)',
                        style: 'margin-top: 10px;'
                    },

                    {
                        itemId: 'fileLoadBtn',
                        xtype: 'fileupload',
                        autoUpload: true,
                        loadAsDataUrl: true,
                        states: {
                            browse: {
                                text: 'Browse and load'
                            },
                            ready: {
                                text: 'Load'
                            },

                            uploading: {
                                text: 'Loading',
                                loading: true
                            }
                        }
                        // For success and failure callbacks setup look into controller
                    },
                    {
                        itemId: 'loadedImage',
                        xtype: 'img',
                        width: '80%',
                        height: '200px',
                        style: 'margin-top:15px;'
                    }
                ]
            }
        ]
    }
});
