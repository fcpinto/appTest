Ext.define('MobiShout_Admin.view.Loader', {

     extend: 'Ext.Container',
     xtype: 'loadmask',
     config: {

         html:'<div id="appLoadingIndicator">' +
             '<div class="spinner"><div class="cube1">' +
             '</div><div class="cube2"></div></div></div>',
             style:'z-index: 9999; background: rgba(0,0,0,0.25);'
     }
    }
);
