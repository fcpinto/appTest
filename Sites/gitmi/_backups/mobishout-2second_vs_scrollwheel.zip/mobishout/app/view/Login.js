Ext.define('MobiShout_Admin.view.Login', {
    extend: 'Ext.Container',
    xtype: 'login',


    requires: ['Ext.form.FieldSet', 'Ext.TitleBar', 'Ext.field.Password'],

    config: {
        itemId: 'loginForm',
        cls: 'login',
        scrollable: true,
        showAnimation: {
            firstTime: true,
            type: 'fadeIn',
            duration: 250
        },
        layout: 'fit',
        //LOGIN
        items: [
            {
                cls: 'loginCard',
                title: 'Login',
                //  iconCls: 'user',
                layout: {type: 'vbox', align: 'center', pack: 'center'},
                defaults:{
                    margin: 5
                },
                items: [
                    {
                      xtype: 'img',
                      src: 'resources/images/mobishout.png',
                      height: '118px',
                      width: '340px'
                    },
                            {
                                xtype: 'textfield',
                                name: 'username',
                                itemId: 'usernameField',
                                //label: '<span style="font-family: SSStandard">&#x1F464;</span>',
                                label: '&#x1F464;',
                                labelCls: 'ss-icon',
                                labelWidth: 40,
                                id: 'logEmail',
                                placeHolder: 'user',
                                cls: 'loginFields',
                                width: 300
                            },
                            {
                                xtype: 'passwordfield',
                                name: 'password',
                                itemId: 'passwordField',
                                label: '&#x1F512;',
                                labelCls: 'ss-icon',
                                labelWidth: 40,
                                id: 'logPassword',
                                placeHolder: 'password',
                                cls: 'loginFields',
                                width: 300
                            }
                    ,
                    {
                        layout: 'hbox',

                        items: [
                            {

                                xtype: 'textfield',
                                name: 'email',
                                placeHolder: 'insert your email',
                                cls: 'loginField',
                                itemId: 'emailField',
                                width: 300,
                                hidden: true
                            },
                            {
                                xtype: 'button',
                                name: 'button4',
                                itemId: 'recoverPasswordBtn',
                                text: 'Ok',
                                action: 'recoverPassword',
                                hidden: true
                            }
                        ]
                    },
                    {
                        xtype: 'button',
                        name: 'button1',
                        iconCls: 'ss-select',
                        cls: 'loginBtn',
                        itemId: 'loginBtn',
                        action: 'pushView',
                        width: 300
                    },
                    {
                        xtype: 'button',
                        name: 'button2',
                        itemId: 'recoverBtn',
                        text: 'Forgot your Password?',
                        cls: 'lostPassBtn',
                        action: 'recoverBtn',
                        width: 300,
                        ui: 'plain',
                        hidden: true
                    },
                    {
                        xtype: 'button',
                        name: 'button3',
                        itemId: 'backBtn',
                        text: 'Back',
                        action: 'backBtn',
                        width: 348,
                        hidden: true
                    }
                ]
            }
        ]
    }
});