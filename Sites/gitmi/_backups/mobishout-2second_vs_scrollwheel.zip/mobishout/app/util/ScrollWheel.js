/**
 * Created by zul on 07/03/14.
 */

Ext.define('MobiShout_Admin.util.ScrollWheel', {
    override: 'Ext.scroll.Scroller',

    applyElement: function (element) {
        if (!element) {
            return;
        }
        this.wheelEvent(element);
        return Ext.get(element);
    },
    wheelEvent: function (element) {
        if (Ext.os.is.Desktop) {
            var scroller = this,
                moveX = 0,
                moveY = 0,
                deltaX = 0,
                deltaY = 0,
                margin = 150,
                moveIt = function (evt) {
                    deltaX = Ext.Number.constrain(evt.deltaX * margin, -margin, margin);//evt.deltaX * 10;
                    deltaY = Ext.Number.constrain(evt.deltaY * margin, -margin, margin);//evt.deltaY * 10;
                    moveX = Ext.Number.constrain(scroller.position.x + deltaX, scroller.minPosition.x, scroller.maxPosition.x);
                    moveY = Ext.Number.constrain(scroller.position.y + deltaY, scroller.minPosition.y, scroller.maxPosition.y);
                    scroller.scrollTo(moveX, moveY, true);
                };

            element.dom.addEventListener('mousewheel', moveIt, true);
        }
    }
});