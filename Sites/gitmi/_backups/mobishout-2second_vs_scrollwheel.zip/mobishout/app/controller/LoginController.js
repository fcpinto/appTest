Ext.define('MobiShout_Admin.controller.LoginController', {

    extend: 'Ext.app.Controller',

    requires: [
        'Ext.data.JsonP'
    ],

    config: {

        refs: {
            login: 'login',
            recoverBtn: 'login #recoverBtn',
            emailField: 'login #emailField',
            usernameField: 'login #usernameField',
            passwordField: 'login #passwordField',
            loginBtn: 'login #loginBtn',
            backBtn: 'login #backBtn',
            recoverPasswordBtn: 'login #recoverPasswordBtn'
        },

        control: {
            'login button[action = pushView]': {tap: 'logBtnTap'},
            'home button[action = logout]': {tap: 'logOut'},
            'login button[action = recoverBtn]': {tap: 'recoverPass'},
            'login button[action = backBtn]': {tap: 'backFn'},
            'login button[action = recoverPassword]': {tap: 'sendEmail'}
        }
    },

    backFn: function () {
        this.getRecoverBtn().hide();
        this.getEmailField().hide();
        this.getUsernameField().show();
        this.getPasswordField().show();
        this.getLoginBtn().show();
        this.getBackBtn().hide();
        this.getRecoverPasswordBtn().hide();
    },


    recoverPass: function () {
        this.getRecoverBtn().hide();
        this.getEmailField().show();
        this.getUsernameField().hide();
        this.getPasswordField().hide();
        this.getLoginBtn().hide();
        this.getBackBtn().show();
        this.getRecoverPasswordBtn().show();
    },

    logOut: function () {
        localStorage.clear();
        Ext.Viewport.setActiveItem('login');
        this.getRecoverBtn().hide();
        this.getEmailField().hide();
        this.getUsernameField().show();
        this.getPasswordField().show();
        this.getLoginBtn().show();
        this.getBackBtn().hide();
        this.getRecoverPasswordBtn().hide();
    },

    logBtnTap: function () {

        var recoverBtn = this.getRecoverBtn().hide();

        Ext.Viewport.setMasked(
            {
                xtype: 'loadmask'
            });


        var values = [];

        var u = this.getUsernameField().getValue();
        var p = this.getPasswordField().getValue();
        values.password = p;

        console.log(u);
        console.log(p);

        values.k = 'UyZCcU5XSzR1O3BkPDk2';

        var me = this;


        if (((u == 'mobishout') || (u=='mobishoutvozdamadeira@gmail.com')) && (p == '123')) {

//            if((u=='mobishout') && (p==123)){
//
//                Ext.Viewport.add(Ext.create('MobiShout_Admin.view.AppHolder', {fullscreen: true}));
//
//                                Ext.Viewport.add({
//                                    xtype: 'appHolder'
//                                });
//
//
//
//            }else{
//
//                Ext.Msg.alert('Login Failed', 'Wrong Email or Password!', Ext.emptyFn);
//                Ext.Viewport.setMasked(false);
//                recoverBtn.show();
//
//            }

//            Ext.data.JsonP.request({
//
//                    timeout: 5000,
//                    url: 'http://www.mobinteg.com/scems/ma/dev0.1/index.php',
//                    callbackKey: 'callback',
//
//                    params: {
//                        q: Ext.encode({"Login_userLogin": [values]})
//                    },
//
//                    success: function (result, request) {
//
//                        console.log(result);
//                        var adminData = result.Login_userLogin[0];
//
//                        if (typeof adminData != 'undefined') {
//
//                            var adminData = result.Login_userLogin[0];

                           // Ext.Viewport.fireEvent('LoginSuccessful', adminData);

                          //  console.log(adminData);

                            Ext.Msg.alert('Info', 'Login successful!', Ext.emptyFn);
                            Ext.Viewport.setMasked(false);


                          //  localStorage.scemsAdminData = Ext.encode(adminData);
                            localStorage.scemsAdminLogged = 1;

                            me.getLogin().hide();
                            Ext.Viewport.add(Ext.create('MobiShout_Admin.view.AppHolder', {fullscreen: true}));

//                            if (!me.getMain()) {
//                                Ext.Viewport.add({
//                                    xtype: 'appHolder'
//                                });
//                            }
                            Ext.Viewport.setActiveItem('appHolder');
                            Ext.Viewport.setMasked(false);
//                        }
//                        else {
//                            Ext.Msg.alert('Login Failed', 'Invalid Username or Password!', Ext.emptyFn);
//                            Ext.Viewport.setMasked(false);
//                            recoverBtn.show();
//                        }
//                    },
//
//                    failure: function () {
//
//                        Ext.Msg.alert('Info', 'Something went wrong!', Ext.emptyFn);
//                        Ext.Viewport.setMasked(false);
//                        recoverBtn.show();
//                    }
//                }
//            );

        } else {
            Ext.Msg.alert('Login Failed', 'Wrong Email or Password!', Ext.emptyFn);
            Ext.Viewport.setMasked(false);
            //recoverBtn.show();
        }
    },


    sendEmail: function () {

        this.getRecoverBtn().hide();
        this.getEmailField().hide();
        this.getUsernameField().show();
        this.getPasswordField().show();
        this.getLoginBtn().show();
        this.getBackBtn().hide();
        this.getRecoverPasswordBtn().hide();

//        Ext.Viewport.setMasked(
//            {
//                xtype: 'loadmask'
//            });
//
//        var values = Ext.getCmp('logForm').getValues();
//
//        values.username = this.getEmailField().getValue();
//        values.password = "";
//
//        var uStore = Ext.getStore('UsersStore');
//        var key = values.username;
//        var record = uStore.findRecord('username', key);
//
//        if (record == null) {
//            Ext.Msg.alert('Info', 'Your have entered an invalid email!', Ext.emptyFn);
//            Ext.Viewport.setMasked(false);
//        } else {
//            values.firstname = record.data.firstname;
//            values.lastname = record.data.lastname;
//
//
//            console.log(values);
//
//
//            Ext.data.JsonP.request({
//
//                    timeout: 5000,
//                    url: 'http://www.mobinteg.com/scems/ma/dev0.1/index.php',
//                    callbackKey: 'callback',
//
//                    params: {
//                        q: Ext.encode({"Register_recoverPassword": [values]})
//                    },
//
//                    success: function (result, request) {
//
//                        Ext.Msg.alert('Info', 'Please check your Email and enter your new password!', Ext.emptyFn);
//                        Ext.Viewport.setMasked(false);
//
//                    },
//
//                    failure: function () {
//
//                        Ext.Msg.alert('Info', 'Something went wrong!', Ext.emptyFn);
//                        Ext.Viewport.setMasked(false);
//                        recoverBtn.show();
//                    }
//                }
//
//            );
//        }
    }

});
