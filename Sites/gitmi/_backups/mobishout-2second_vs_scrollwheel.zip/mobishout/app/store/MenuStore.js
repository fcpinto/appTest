Ext.define('MobiShout_Admin.store.MenuStore', {

    extend: 'Ext.data.Store',


    config: {

        model: 'MobiShout_Admin.model.MenuModel',
        // sorters: 'lastName',

//    //GROUPED LIST
//    grouper: {
//        groupFn: function(record) {
//            return record.get('lastName')[0];
//        }
//    },

//        proxy: {
//            type: 'memory'
//        },
        data: [
            {icon: '&#x2302;' ,title: 'Home'},
            {icon: '&#x1F4DD;',title: 'Issues'},
            //{icon: '&#x1F465;',title: 'Admins'},
            {icon: '&#xE570;',title: 'Analytics'},
            //{icon: '&#xE6D0;',title: 'Poi'},
            {icon: '&#xF4C0;', title: 'Ad'},
            {icon: '&#x2699;', title: 'Settings'}
            //{icon: '&#x2139;',title: 'About'}

        ]
    }
});