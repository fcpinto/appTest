/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.FilterTema', {
    extend: 'Manchete.view.FilterMeio',
    xtype: 'filterTema',

    config: {
        title:'Temas',
        store: 'FilterTema'
    }
});