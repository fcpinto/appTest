/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 18/09/13
 * Time: 11:21
 */
Ext.define('Manchete.view.MediaTypeView', {
    extend: 'Ext.navigation.View',
    xtype: 'mediaType',

    config: {
        defaultBackButtonText:'',
        useTitleForBackButtonText: false,
        navigationBar:{
            cls:'mediaTypeNav',
            backButton:{
                iconCls:'ss-directleft',
                ui: 'plain'
            }
        },

        items:[
            {
                xtype:'list',
                cls: 'manchetes-list',
                navlist:'mediaType',
                selectedCls: '',
                padding: 0,
                margin: 0,
                styleHtmlContent: true,
                store: 'News',
                masked:{
                    xtype: 'loadmask',
                    message:'Por favor aguarde'
                    //messageCls:'news-load-msg'
                    //hidden:false
                },
                loadingText:'Por favor aguarde',
                scrollable:{
                    direction:'vertical',
                    directionLock:true
                },
                scrollToTopOnRefresh:false,
                striped: true,
                emptyText:'Não existem notícias disponíveis, por favor faça refresh, ou tente mais tarde.',
                itemTpl: Ext.os.is.Phone?Ext.create('Ext.XTemplate',
                    '<div class="boxPhone{[this.isInHistory(values.link)]} completed{completed}">',
                    '   <div class="title bold{bold}">{titulo}</div>',
                    '   <div class="others">',
                    '       <div class="provider">{publicacao}</div>',
                    '       <div class="date">{data}</div>',
                    '       <div class="paginas">{paginas}</div>',
                    '       <div class="favorite{favorito} iconios"></div>',
                    '       <div class="share iconios"></div>',
                    '       <div class="{linkType}{downloaded} iconios files"></div>',
                    '   </div>',
                    '</div>',
                    '<div class="deleteBtn"></div>',
                    {
                        isInHistory:function(vl){
                            return vl==''?' notInHistory':''
                        },
                        pagHora:function(vl){
                            var str = '';
                            if(vl!=''){
                                str += ' | ' + (vl.lastIndexOf(':')> -1 ? vl : 'pág. ' + vl);
                            }
                            return str;
                        }
                    }
                ):Ext.create('Ext.XTemplate',
                    '<div class="box{[this.isInHistory(values.link)]} completed{completed}">',
                    '   <div class="title bold{bold}">{titulo}</div>',
                    '       <div class="provider">{publicacao}</div>',
                    '       <div class="date">{data}</div>',
                    '       <div class="paginas">{paginas}</div>',
                    '       <div class="favorite{favorito} iconios"></div>',
                    '       <div class="share iconios"></div>',
                    '       <div class="{linkType}{downloaded} iconios files"></div>',
                    '</div>',
                    '<div class="deleteBtn"></div>',
                    {
                        isInHistory:function(vl){
                            return vl==''?' notInHistory':''
                        },
                        pagHora:function(vl){
                            var str = '';
                            if(vl!=''){
                                str += ' | ' + (vl.lastIndexOf(':')> -1 ? vl : 'pág. ' + vl);
                            }
                            return str;
                        }
                    }
                ),
                items:[
                    /*{
                        xtype:'component',
                        docked:'top',
                        itemId:'titleBar',
                        cls:'tabbar-list',
                        //style:'font-size: 0.7em;',
                        html:'&nbsp;'
                    },*/
                    {
                        xtype:'container',
                        style:'text-align:center; padding:10px 0 10px 0; background-color:#ffffff; color:#0775c1; font-weight: bold;',
                        html:'﹀',
                        itemId:'toNext',
                        scrollDock:'bottom',
                        hidden:true,
                        listeners: {
                            tap: {
                                fn: function(){
                                    var list = this.up('list'),
                                        store = list.getStore(),
                                        totalItems = store.getProxy().totalItems,
                                        totalPages = Math.ceil(totalItems/store.getPageSize());

                                    list.setLoadingText('Por favor aguarde');

                                    if(store.currentPage < totalPages){
                                        list.setEmptyText('');
                                        store.removeAll();
                                        list.setScrollToTopOnRefresh(true);
                                        //list.getScrollable().getScroller().scrollTo(0, 0);
                                        store.nextPage();
                                    }
                                },
                                element: 'element'
                            }
                        }
                    },
                    {
                        xtype:'container',
                        style:'text-align:center; padding:10px 0 10px 0; background-color:#ffffff; color:#0775c1; font-weight: bold;',
                        html:'︿',
                        itemId:'toPrev',
                        scrollDock:'top',
                        hidden:true,
                        listeners: {
                            tap: {
                                fn: function(){
                                    var list = this.up('list'),
                                        store = list.getStore(),
                                        currentPage = store.currentPage;

                                    list.setLoadingText('Por favor aguarde');

                                    if(currentPage > 1){
                                        store.previousPage();
                                    }
                                },
                                element: 'element'
                            }
                        }
                    }
                ],
                listeners:{
                    initialize:function(list){
                        list.config.title = list.getStore().title;
                        if(!list.getStore().isLoading()){
                            list.setMasked(false);
                        }
                        if(list.config.title == "Favoritos"){
                            list.setEmptyText('Não existem notícias marcadas como favoritas');
                        }
                        else if(list.config.title == "Histórico"){
                            list.setEmptyText('Não existem notícias guardadas no histórico');
                        }
                    },
                    painted:{
                        buffer:500,
                        fn:function(el){
                            //this.refresh();
                        }
                    },
                    refresh: function (list) {
                        console.log('***** REFRESH *****');
                        var store = list.getStore(),
                            totalItems = store.getProxy().totalItems,
                            totalPages = Math.ceil(totalItems / store.getPageSize()),
                            currentPage = store.currentPage,
                            toPrev = list.down('#toPrev'),
                            toNext = list.down('#toNext');

                        toPrev.setHidden(currentPage <= 1);
                        toNext.setHidden(store.currentPage >= totalPages);
                        list.setScrollToTopOnRefresh(false);
                    },
                    activate:function(list){
                        var store = list.getStore();
                        if (store.isFiltered) {
                            if (list.config.title.lastIndexOf('Tema') > -1) {
                                list.setEmptyText('Não existem notícias do disponíveis para o(s) tema(s) selecionado(s)');
                            }
                            else{
                                list.setEmptyText('Não existem notícias que obedeçam aos critérios de filtragem');
                            }
                        }
                    }
                }
            }
        ],
        listeners:{
            initialize:function(nav){
                /*setTimeout(function(){
                    var titleBar = nav.down('#titleBar');
                    if(titleBar){
                        titleBar.setHtml(Ext.getCmp('m-menu').getSelection()[0].data.clipping)
                    }
                },100);*/
            },
            destroy:function(nav){
                //console.log(nav.config.cleanSearch);
                if(nav.config.cleanSearch){
                    Ext.getStore('SearchRemover').load();
                }
            }
        }

    }
});