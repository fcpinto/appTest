/**
 * Created by zul on 04/11/13.
 */
Ext.define('Manchete.view.MailSender', {
    extend:'Ext.Container',

    xtype:'mailSender',

    config:{

        modal: true,
        centered:true,
        hideOnMaskTap: true,
        styleHtmlContent: true,
        contentEl: 'content',
        width: !Ext.os.is.Phone? 400 : 260,
        style:'background-color:#ffffff;',
        padding:0,

        /*showAnimation:{
            type:'slide',
            direction:'up'
        },
        hideAnimation:{
            type:'slide',
            direction:'up',
            out:true
        },*/
        cls:'login-view',

        items:[
            {
                xtype:'formpanel',
                scrollable:null,
                padding:10,
                items:[
                    {
                        xtype: 'img',
                        src: 'resources/images/manchete_logo.png',
                        style: 'background-size:contain;',
                        margin:!Ext.os.is.Phone? '0 40 0 40' : 0,
                        height:100
                    },
                    {
                        xtype: 'emailfield',
                        action:'moveViewport',
                        placeHolder:'e-mail do remetente',
                        name: 'emailSender',
                        margin:'0 0 10 0',
                        hidden:true
                    },
                    {
                        xtype: 'textfield',
                        action:'moveViewport',
                        placeHolder:'nome do remetente',
                        name: 'nameSender',
                        margin:'0 0 10 0',
                        hidden:true
                    },
                    {
                        xtype: 'emailfield',
                        action:'moveViewport',
                        placeHolder:'e-mail do destinatário',
                        name: 'emailDestination',
                        margin:'0 0 10 0'
                    },
                    {
                        xtype: 'textfield',
                        action:'moveViewport',
                        placeHolder:'nome do destinatário',
                        name: 'nameDestination',
                        margin:'0 0 10 0'
                    },
                    {
                        xtype: 'textareafield',
                        action:'moveViewport',
                        placeHolder:'mensagem',
                        name: 'message',
                        margin:'0 0 10 0'
                    },
                    {
                        xtype:'container',
                        layout:'hbox',
                        items:[
                            {
                                xtype: 'button',
                                ui: 'decline',
                                iconCls:'ss-close',
                                iconAlign:'center',
                                padding:10,
                                flex:1,
                                handler:function(){
                                    this.up('mailSender').hide();
                                }
                            },
                            {
                                xtype: 'button',
                                ui: 'confirm',
                                action: 'sendMail',
                                iconCls:'ss-select',
                                iconAlign:'center',
                                padding:10,
                                flex:1
                            }
                        ]
                    }
                ]
            }
        ],
        listeners:{
            initialize:function(view){
                if(!localStorage.mancheteuser){
                    view.down('field[name=emailSender]').setHidden(false);
                    view.down('field[name=nameSender]').setHidden(false);
                }
            },
            hide:function(view){
                view.destroy();
            }
        }
    }
});