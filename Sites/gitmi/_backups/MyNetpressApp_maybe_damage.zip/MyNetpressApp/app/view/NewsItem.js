/**
 * Created by zul on 01/10/13.
 */
Ext.define('Manchete.view.NewsItem', {
    extend: 'Ext.DataView',
    xtype: 'newsItem',

    config: {
        styleHtmlContent: true,
        padding:'0 10 10 10',
        scrollable:{
            direction:'vertical',
            directionLock:true
        },
        style:'background-color:#ffffff;',
        store:'NewsItem',
        masked: false,/*{
            xtype: 'loadmask',
            message: '',
            hidden: false
        },*/
        loadingText:false,
        cls:'news-item',
        /*hideAnimation:{
            duration: 300,
            easing: 'ease-out',
            type: 'slide',
            out: true
        },*/
        itemTpl: Ext.create('Ext.XTemplate',
            '<div class="box">',
            '   <span class="title"><b>{titulo}</b></span><br>',
            '   <div class="info">',
            '       <div class="jorn-pub">{[this.hasJornalist(values.jornalista)]}{publicacao}</div>',
            '       <div class="date">{data}{[this.pagHora(values.paginas)]}</div>',
            '   </div>',
            '   <div class="ss-icons">',
            //'       <span class="back"></span>',
            '       <span class="favorite{favorito}"></span>',
            '       <span class="share"></span>',
            '       <span class="{linkType}{downloaded} files"></span>',
            '       <span class="trash"></span>',
            '   </div>',
            '</div>',
            '<div class="text">{[this.deCodeText(values.texto)]}</div>',
            '<div class="footer"><b>manchete</b> | <i>Intelligence Based Platform</i></div>',
            {
                deCodeText:function(vl){
                    return Ext.htmlDecode(vl);
                },
                hasJornalist:function(vl){
                    return vl!=''?(vl+' | '):'';
                },
                fileType:function(vl){
                    if(vl == 'pdf'){
                        return 'p';
                    }
                    else if(vl == 'video'){
                        return 'v';
                    }
                    else if(vl == 'audio'){
                        return 'a';
                    }
                    return 'l';
                },
                pagHora:function(vl){
                    var str = '';
                    if(vl!=''){
                        str += ' | ' + (vl.lastIndexOf(':')> -1 ? vl : 'pág. ' + vl);
                    }
                    return str;
                }
            }
        ),
        items:[
            {
                xtype:'button',
                docked:'bottom',
                width:40,
                height:40,
                style:'position: absolute; bottom: 0;right: 0;',
                ui:'plain',
                iconCls:'ss-navigateup',
                hidden:true,
                handler:function(btn){
                    var newsItem = btn.up('newsItem'),
                        scroller = newsItem.getScrollable().getScroller();

                    scroller.scrollTo(0,0,true);
                }
            }
        ],
        listeners:{
            initialize:function(dv){
                dv.getScrollable().getScroller().on('scrollend',function(scroller, x, y){
                    dv.down('button[iconCls=ss-navigateup]').setHidden(y <= 0);
                });

            },
            hide:function(cmp){
                cmp.setMasked();
            },
            refresh:function(dv){
                /*var items = dv.getStore().getData().items,
                    data = (items.length > 0)?items[0].data:null;

                if(data){
                    dv.down('#topbar').setData(dv.getStore().getData().items[0].data);
                }*/
            }
        }
    }
});