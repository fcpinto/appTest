/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.NewsFilters', {
    extend: 'Ext.form.Panel',
    xtype: 'newsFilters',

    config: {
        itemId:'newsFilters',
        styleHtmlContent: true,
        style: 'background:#ffffff;',
        padding:5,
        items: [
            {
                xtype:'filterSet'
            },
            {
                xtype: 'sliderfield',
                itemId:'days',
                label: 'Dias: 7',
                value: 7,
                minValue: 1,
                maxValue: 30,
                name:'days',
                listeners: {
                    change: function (cmp, sl, thumb, newValue, oldValue) {
                        cmp.setLabel('Dias: ' + newValue);
                    }
                }
            },
            {
                xtype: 'container',
                layout:'hbox',
                docked: 'bottom',
                action: 'filtrar',
                style:'background:#EEEEEE;',
                padding:5,
                items:[
                    {
                        xtype: 'button',
                        //itemId: 'filterBtn',
                        text: 'Limpar',
                        ui: 'decline',
                        margin: '0 3 0 0',
                        padding: 10,
                        flex:1,
                        action: 'filtrarLimpar'
                    },
                    {
                        xtype: 'button',
                        itemId: 'filterBtn',
                        text: 'Filtrar',
                        ui: 'confirm',
                        margin: '0 0 0 3',
                        padding: 10,
                        flex:1,
                        action: 'filtrar'
                    }
                ]
            }
            /*{
                xtype: 'button',
                itemId: 'filterBtn',
                text: 'Filtrar',
                ui: 'confirm',
                margin: 5,
                padding: 10,
                docked: 'bottom',
                action: 'filtrar'
            }*/
        ]

    }
});
