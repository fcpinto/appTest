/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.UserView', {
    extend: 'Ext.form.Panel',
    xtype: 'userView',

    requires:[
        'Ext.field.Toggle'
    ],

    config: {
        styleHtmlContent:true,
        cls:'settings-form',
        padding:10,
        items:[
            {
                xtype: 'container',
                items: [
                    {
                        xtype: 'component',
                        cls:'set-title',
                        html:'Perfil'
                    },
                    {
                        xtype: 'component',
                        style: 'margin-top: 10px;',
                        tpl: '<span class="set-grey">Name:</span> <span class="set-blue">{nomeacesso}</span><br>' +
                            '<span class="set-grey">Organização:</span> <span class="set-blue">{nomecliente}</span><br>' +
                            '<span class="set-grey">Mail:</span> <span class="set-blue"><a href="#" style="pointer-events: none; cursor: default;">{mail}</a></span><br><br>' +//<span class="set-blue" style="pointer-events: none; cursor: default;">{mail}</span><br><br>' +
                            '<img src="{logo}" style="max-width: 200px; max-height: 200px;">',
                        listeners: {
                            initialize: function (cmp) {
                                var updateuserdata = function(data) {
                                    cmp.setData(data);
                                };
                                var onupdateuserdata = Ext.getStore('UserDetails').on('onupdateuserdata', updateuserdata);

                                cmp.on('destroy',function(){
                                    Ext.getStore('UserDetails').un('onupdateuserdata',updateuserdata);
                                });
                            }
                        }
                    }
                ]
            },
            {
                xtype:'button',
                text:'Remover conta',
                action: 'removerconta',
                ui: 'decline',
                padding:10,
                margin:'20 0 10 0'
            },
            {
                xtype:'button',
                text:'Log out',
                action: 'logout',
                ui: 'decline',
                padding:10
            }
        ]
    }
});