/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 18/09/13
 * Time: 11:21
 */
Ext.define('Manchete.view.Manchetes', {
    extend: 'Ext.dataview.List',
    xtype: 'manchetes',

    config: {
        title: 'Manchetes',
        cls: 'manchetes-list',
        selectedCls: '',
        padding: 0,
        margin: 0,
        styleHtmlContent: true,
        store: 'HeadlinesTable',
        grouped: true,
        scrollToTopOnRefresh:false,
        striped: true,
        scrollable:{
            direction:'vertical',
            directionLock:true
        },
        /*itemTpl: [
         '<span class="title">{titulo}</span><br>',
         '<span class="date" style="opacity: 0.7; font-size: 90%;">{data}</span>'
         ].join(''),*/
        emptyText:'Não existem notícias disponíveis, por favor faça refresh, ou tente mais tarde.',
        itemTpl: Ext.os.is.Phone ? [
            '<div class="boxPhone completed0">',
            '   <div class="title">{titulo}</div>',
            '   <div class="others">',
            '       <div class="date">{data}</div>',
            '       <div class="share iconios"></div>',
            '       <div class="open{[values.link == \"\"?0:1]} iconios"></div>',
            '   </div>',
            '</div>'
        ].join('') : [
            '<div class="box completed0">',
            '   <div class="title">{titulo}</div>',
            '       <div class="date">{data}</div>',
            '       <div class="share iconios"></div>',
            '       <div class="open{[values.link == \"\"?0:1]} iconios"></div>',
            '</div>'
        ].join(''),
        items: [
            {
                xtype: 'container',
                style: 'text-align:center; padding:10px 0 10px 0; background-color:#ffffff; color:#0775c1; font-weight: bold;', //font-family: iOSss;',
                html: '﹀',
                itemId: 'toNext',
                scrollDock: 'bottom',
                hidden: true,
                listeners: {
                    tap: {
                        fn: function () {
                            var list = this.up('list'),
                                store = list.getStore(),
                                totalItems = store.getProxy().totalItems,
                                totalPages = Math.ceil(totalItems / store.getPageSize());

                            list.setLoadingText('Por favor aguarde');

                            if (store.currentPage < totalPages) {
                                list.setEmptyText('');
                                store.removeAll();
                                list.setScrollToTopOnRefresh(true);
                                store.nextPage();
                            }
                        },
                        element: 'element'
                    }
                }
            },
            {
                xtype: 'container',
                style: 'text-align:center; padding:10px 0 10px 0; background-color:#ffffff; color:#0775c1; font-weight: bold;',
                html: '︿',
                itemId: 'toPrev',
                scrollDock: 'top',
                hidden: true,
                listeners: {
                    tap: {
                        fn: function () {
                            var list = this.up('list'),
                                store = list.getStore(),
                                currentPage = store.currentPage;

                            list.setLoadingText('Por favor aguarde');

                            if (currentPage > 1) {
                                store.previousPage();
                            }
                        },
                        element: 'element'
                    }
                }
            }
        ],
        listeners: {
            initialize:function(list){
                list.setEmptyText('Não existem notícias disponíveis, por favor faça refresh, ou tente mais tarde.');
            },
            refresh: function (list) {
                console.log('********** Refresh Manchetes **********');
                console.log(list.getStore().getData().items.length);
                var store = list.getStore(),
                    totalItems = store.getProxy().totalItems,
                    totalPages = Math.ceil(totalItems / store.getPageSize()),
                    currentPage = store.currentPage,
                    toPrev = list.down('#toPrev'),
                    toNext = list.down('#toNext');

                toPrev.setHidden(currentPage <= 1);
                toNext.setHidden(store.currentPage >= totalPages);
                list.setScrollToTopOnRefresh(false);
            }
        }
    }
});
