/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 27/08/13
 * Time: 12:13
 */
Ext.define('Manchete.view.ManchetesGrid', {
    extend: 'Ext.carousel.Carousel',
    xtype: 'manchetesGrid',

    config: {
        title: 'Manchetes',
        padding: 0,
        cls:'manchetes-grid',
        styleHtmlContent:true,

        listeners: {
            initialize: function (cmp) {
                Manchete.app.fireEvent('getTodayCovers', function (data) {
                    var len = data.length,
                        maxItemsPerPage = !Ext.os.is.Phone ? 6 : 4,
                        totalPages = Math.ceil(len / maxItemsPerPage),
                        itemsPerPage,
                        pages = [],
                        items = [],
                        width = !Ext.os.is.Phone ? '33.3%' : '50%';

                    //console.log(len, maxItemsPerPage, totalPages);

                    for (var i = 0; i < totalPages; i++) {
                        //console.log('----------');
                        pages.push(Ext.create('Ext.Container', {
                            style: 'background-color:#EAEDF0;'
                        }));
                        itemsPerPage = (maxItemsPerPage * (i + 1) < len) ? maxItemsPerPage : len - (maxItemsPerPage * (i));
                        items = [];
                        for (var j = 0; j < itemsPerPage; j++) {
                            //console.log('✹ ');
                            items.push({
                                xtype: 'container',
                                width: width,
                                height: '50%',
                                //html: ((i * maxItemsPerPage) + (j)) + '',
                                style: 'float: left; display: inline-block!important; padding:10px;',
                                layout: 'fit',
                                items: [
                                    {
                                        xtype: 'img',
                                        width: '100%',
                                        height: '100%',
                                        ref: ((i * maxItemsPerPage) + (j)) + '',
                                        //source: data[(i * maxItemsPerPage) + (j)].linkBig,
                                        //src: data[(i * maxItemsPerPage) + (j)].linkBig,
                                        html:'<div class="rotationObj"></div>',
                                        src: data[(i * maxItemsPerPage) + (j)].linkBig,
                                        style: 'padding:10px; background-size:contain;',// background-image: url(resources/images/picture.svg);',//  float: left; display: inline-block!important; -webkit-box-shadow: 0 5px 10px -6px black; background-color:#ffffff;' +
                                        listeners: {
                                            tap:{
                                                fn:function () {
                                                    Manchete.app.mancheteActiveItem = this.config.ref;
                                                    this.up('manchetesGrid').fireEvent('mancheteImgtap', this);
                                                },
                                                element: 'element'
                                            },
                                            load: function (img) {
                                                img.setHtml('');
                                            },
                                            error: function (img) {
                                                img.setHtml('');
                                                img.setSrc('resources/images/picture.svg');
                                            }
                                        }
                                    }

                                ]
                            });
                        }
                        pages[i].setItems(items);
                    }
                    cmp.add(pages);

                    if(len == 0){
                        cmp.setHtml('Não existem notícias disponíveis, por favor faça refresh, ou tente mais tarde.');
                    }
                });
            }
        }
    }
});
