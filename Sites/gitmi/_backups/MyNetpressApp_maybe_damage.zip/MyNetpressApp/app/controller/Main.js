/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 26/08/13
 * Time: 20:20
 */
Ext.define('Manchete.controller.Main', {
    extend: 'Ext.app.Controller',

    requires: [
        'Ext.Img',
        'Ext.field.Slider',
        'Ext.form.Panel',
        'Ext.field.Select',
        'Ext.field.Hidden',
        'Ext.Anim',
        'Ext.device.Notification'
    ],

    config: {
        refs: {
            menu: 'menuClipping',
            contentView: '#contentView',
            mediaType:'mediaType list',
            mediaGrid:'newsGrid dataview[cls=newsGrid-list]',
            ordinaryNav:'ordinaryNav',
            mancheteList:'manchetes',
            filterField:'newsFilters',
            newsItem:'newsItem',
            //newsItemTopbar:'newsItem #topbar',
            manchetesCarousel:'manchetesCarousel',
            manchetesGrid:'manchetesGrid',
            newsFilters:'newsFilters',
            mainToolbar:'#mainToolbar',
            searchNewsBtn:'button[action=searchNews]',
            mancheteNewsBtn:'button[action=mancheteNews]',
            filterNewsBtn:'button[action=filterNews]',
            viewport:'viewport'
        },
        control: {
            menu: {
                initialize: 'onInitialize',
                itemtap: 'onMenuItemtap'
            },
            mediaType: {
                itemtap: 'onMediaItemtap',
                itemswipe:'onMediaItemswipe'
            },
            mediaGrid: {
                itemtap: 'onMediaItemtap'
            },
            contentView: {
                add: 'onAdd'
            },
            mancheteList:{
                itemtap:'onMancheteItemtap'
            },
            newsItem:{
                initialize:'setNewsItemEvents',
                itemtap:'onMediaItemtap'//,
                //itemswipe:'newsItemSwipe'
            },
            /*newsItemTopbar:{
                itemtap:'onMediaItemtap'
            },*/
            manchetesCarousel:{
                mancheteImgtap:'onMancheteImgtap'
            },
            manchetesGrid: {
                mancheteImgtap: 'onMancheteGridImgtap'
            },
            'button[action=searchNews]': {
                tap: 'searchNews'
            },
            'button[action=filterNews]': {
                tap: 'filterNews'
            },
            'button[action=refreshNews]': {
                tap: 'refreshNews'
            },
            'button[action=coverNews]': {
                tap: 'coverNews'
            },
            'button[action=mancheteNews]': {
                tap: 'mancheteNews'
            },
            'button[action=settings]': {
                tap: 'openSettings'
            },
            'button[action=user]': {
                tap: 'openUser'
            },
            'button[action=info]': {
                tap: 'openInfo'
            },
            'button[action=newsLayout]': {
                tap: 'newsLayout'
            },
            'button[action=backToManchetes]': {
                tap: 'backToManchetes'
            },
            viewport:{
                headlinesLoaded:'headlinesLoaded'
            },
            'textfield[action=moveViewport]':{
                //focus:'onfocus',
                //blur:'onblur'
            }
        },
        newsLoaded: false,
        headlinesLoaded: false,
        allPubsDone:false
    },
    onfocus:function(cmp){
        //console.log('FOCUS');
        var ost = cmp.element.dom.offsetTop;
        Ext.Viewport.setStyle('-webkit-transform: translateY(-'+ost+'px)');
    },
    onblur:function(cmp){
        //console.log('BLUR');
        Ext.Viewport.setStyle('-webkit-transform: translateY(0px)');
    },
    init: function () {

        var me = this;
        this.actualStore = 0;
        this.actualView = 'manchetesGrid';
        this.optionData = {};
        document.addEventListener("resume", function () {
            me.onResumeApp();
        }, false);
        document.addEventListener("backbutton", function () {
            Ext.device.Notification.show({
                title: 'My Netpress App',
                message: 'Tem a certeza que pertende sair da aplicação',
                buttons: Ext.MessageBox.OKCANCEL,
                callback: function(button) {
                    if (button === "ok") {
                        window.navigator.app.exitApp();
                    }
                }
            });
        }, false);
        /*document.addEventListener("online", function () {
            // Handle the online event
            alert('online');
        }, false);
        document.addEventListener("offline", function () {
            // Handle the online event
            alert('offline');
        }, false);*/

        if(Ext.os.is.Android && Ext.browser.is.WebView){
            Ext.Viewport.setHeight(window.innerHeight);
        }

        Ext.Viewport.setMasked({xtype: 'loadmask', message:'Por favor aguarde', hidden:true});
        this.fromLogin = null;
        localStorage.manchetenewsview = !localStorage.manchetenewsview?'newsGrid':localStorage.manchetenewsview;
    },
    onResumeApp:function(){
        console.log('onResumeApp!!');
        setTimeout(function() {
            Ext.getStore('NewsRemover').load();
        }, 100);
    },
    onInitialize: function (menu) {

        if (!Ext.os.is.Phone === false) {
            this.getContentView().element.on('tap', function (view) {
                if (!Ext.getCmp('m-menu').isHidden()) {
                    Ext.getCmp('m-menu').hide();
                }
            });
            this.getContentView().element.on('swipe', function (evt, node) {
                if (evt.direction === 'right' && evt.startX < 50) {
                    Ext.getCmp('m-menu').show();
                }
                if (evt.direction === 'left') {
                    Ext.getCmp('m-menu').hide();
                }
            });
        }

    },
    onMenuItemtap: function (list, index, target, record) {
        var me = this;
        var data = record.data;

        me.optionData = data;
        me.fromLogin = null;

        if (data.activo == '2'){
            /*var view = data.referencia3;
            if(view == 'manchetesCarousel' && Ext.getCmp('contentView').down('manchetesCarousel')){
                view = 'manchetes';
            }*/
            me.showViews(data.referencia3);
            me.getMancheteNewsBtn().setIconCls('ss-rows');
        }
        else if (data.activo == '5'){
            Ext.getStore('News').title = 'Pesquisa';
            Manchete.app.getController('NewsFilters').setPubTableName('PUBLICATIONS');
            me.showViews(data.referencia3);
        }
        else if(data.activo == '0'){
            if(!localStorage.mancheteuser){
                if(!me.loginForm){
                    me.loginForm = Ext.Viewport.add({xtype:'loginForm'});
                }
                me.loginForm.show();
                me.fromLogin = index;
            }
            else{
                Ext.device.Notification.show({
                    title: 'Permissões',
                    message: 'O seu utilizador não dispõe de acesso a este item. Por favor contacte o seu gestor de contrato.',
                    buttons: Ext.MessageBox.OK
                });
            }
            //setTimeout(function(){Ext.getCmp('m-menu').deselectAll();},100);
        }
        else if(data.activo == '4'){
            var activeItem = this.getContentView().getActiveItem();
            if(activeItem){
                activeItem.hide();
            }
            Manchete.app.getController('NewsFilters').createList(data.referencia3, record);
        }
        else{
            this.showNews(data);
            Manchete.app.getController('NewsFilters').cleaner(record);
        }

        if (!Ext.os.is.Phone === false) {
            Ext.getCmp('m-menu').hide();
        }

    },
    showViews:function(view, flag, title){
        view = (view=='mediaType')?localStorage.manchetenewsview:view;

        this.actualView = view;
        this.showAndHideBtns(view);
        Ext.getCmp('contentView').setActiveItem({
            xtype: view,
            cleanSearch: !flag?false:flag,
            title:!title?'':title
        });
        if (!Ext.os.is.Phone === false) {
            Ext.getCmp('m-menu').hide();
        }
        this.getFilterNewsBtn().element.removeCls('activeBtn');
    },
    showNews:function(result){
        var newsStore = Ext.getStore('News');

        newsStore.removeAll();
        //newsStore.loaded
        newsStore.currentPage = 1;
        newsStore.setSorters(result.sorters);
        newsStore.setFilters(result.filters);
        newsStore.title = result.clipping;
        newsStore.isFiltered = false;
        newsStore.load();

        //console.log(result)

        this.showViews('mediaType', false, result.clipping);//'mediaType'//'newsGrid'
    },
    onAdd: function (cmp, newView) {
        //console.log(newView.config.xtype);
        if(newView.config.xtype != 'loadmask'){
            if (!Ext.os.is.android) {
                newView.setShowAnimation('slide');
                newView.setHideAnimation({type: 'slide', out: true});
            }
            newView.on('hide', function (view) {
                view.destroy();
            });
        }

    },
    openlink:function(link, target, linkType){
        if(!target){
            target = '_blank';
        }
        //        window.open(link, target, 'location=no,toolbar=yes,EnableViewPortScale=yes,transitionstyle=fliphorizontal');

        if(linkType == 'pdf' && Ext.os.is.Android){
            console.log(fileopener);
            fileopener.open(link);
        }
        else{
            var ref = window.open(link, target, 'location=no,EnableViewPortScale=yes');
            ref.addEventListener('exit', function(event) {
                Manchete.app.getController('MancheteDB').db = rootdb;
            });
        }

    },
    onMancheteImgtap:function(img){
        //this.openlink(img.getSrc());
        this.openlink(Ext.htmlDecode(window.readerFiles+'?file='+img.getSrc()+'&type=img'));
    },
    onMancheteItemtap:function(dv, index, target, record, e) {
        var node = e.target;
        if(node.className.indexOf('share') > -1){

            if(!Manchete.app.shareFromList){
                Manchete.app.shareFromList = Ext.Viewport.add({
                    xtype:'shareNews'
                });
            }
            Manchete.app.shareFromList.setData(record.data);
            Manchete.app.shareFromList.showBy(Ext.get(node));
        }
        else{
            if(record.data.linkBig != ''){
                //this.openlink(record.data.linkBig);
                this.openlink(Ext.htmlDecode(window.readerFiles+'?file='+record.data.linkBig+'&type=img'));
            }
            else{

            }

        }

    },
    onMancheteGridImgtap:function(){
        this.getMancheteNewsBtn().setIconCls('ss-grid');
        this.showViews('manchetesCarousel');
    },
    onMediaItemtap: function (list, idx, el, record, e) {
        var node = e.target;
        console.log(node.className, list.getStore().getStoreId());
        /*if(record.data.link == ''){
            this.openNewsItem(list,idx);
        }
        else */if (node.className.indexOf('files') > -1) {

            if(record.data.downloaded == 0){
                if(Ext.browser.is.WebView && record.data.linkType == 'pdf'){
                    if(!Ext.os.is.Android){
                        this.openlink(Ext.htmlDecode(record.data.link), '_blank',record.data.linkType);
                    }
                    this.saveFile(record);
                }
                else if(record.data.linkType == 'video' || record.data.linkType == 'audio'){
                    //console.log(Ext.htmlDecode(window.readerFiles+'?file='+record.data.link+'&type='+record.data.linkType));
                    if(Ext.os.is.Android==true){
                        this.openlink(Ext.htmlDecode(record.data.link), '_system');
                    }
                    else{
                        this.openlink(Ext.htmlDecode(window.readerFiles+'?file='+record.data.link+'&type='+record.data.linkType));
                    }

                }
                else if (record.data.linkType == 'nolink') {
                    Ext.device.Notification.show({
                        title: 'Notícia',
                        message: 'Link não disponível para o seu perfil',
                        buttons: Ext.MessageBox.OK
                    });
                }
                else{
                    this.openlink(Ext.htmlDecode(record.data.link), Ext.os.is.Android==true?'_system':'_blank');
                }
            }
            else{
                var splitter = record.data.link.split('/'),
                    fileStr = '/'+splitter[splitter.length-1];
                //console.log(rootFolder+fileStr);

                this.openlink(encodeURI(rootFolder+fileStr), Ext.os.is.Android==true?'_system':'_blank',record.data.linkType);
            }
        }
        else if (node.className.indexOf('favorite1') > -1) {
            //node.className = "favorite0";
            record.set('favorito', 0);
            Manchete.app.getController('MancheteDB').updateFieldById(record.data.id,'favorito', 0);
            //record.setDirty();
            //list.getStore().sync();
        }
        else if (node.className.indexOf('favorite0') > -1) {
            //node.className = "favorite1";
            record.set('favorito', 1);
            Manchete.app.getController('MancheteDB').updateFieldById(record.data.id,'favorito', 1);
            //record.setDirty();
            //list.getStore().sync();
        }
        else if(node.className=='trash' || node.className.indexOf('deleteBtn') > -1){
            var me = this;
            Ext.device.Notification.show({
                title: 'Notícia',
                message: 'Pretende apagar esta notícia do seu dispositivo?',
                buttons: [{text: 'Não'}, {text: 'Sim', ui: 'action'}],
                callback: function (button) {
                    if (button.toLowerCase() == "sim") {
                        if (record.data.downloaded == 1) {
                            this.removeFile(record.data.link);
                        }
                        list.getStore().remove(record);
                        list.getStore().sync();

                        if (list.config.navlist == 'newsGrid') {
                            me.getMediaGrid().msnry.reloadItems();
                            me.getMediaGrid().msnry.layout();
                        }
                        setTimeout(function () {
                            list.up('navigationview').pop();
                        }, 100);
                    }
                }
            });
        }
        else if(node.className.indexOf('share') > -1){

            if(!Manchete.app.shareFromList){
                Manchete.app.shareFromList = Ext.Viewport.add({
                    xtype:'shareNews'
                });
            }
            Manchete.app.shareFromList.setData(record.data);
            Manchete.app.shareFromList.showBy(Ext.get(node));

            /*if(list.getStore().getStoreId() == 'News'){
                if(!Manchete.app.shareFromList){
                    Manchete.app.shareFromList = Ext.Viewport.add({
                        xtype:'shareNews'
                    });
                }
                Manchete.app.shareFromList.setData(record.data);
                Manchete.app.shareFromList.showBy(el);
                //Manchete.app.shareFromList.showBy(Ext.get(node));
            }
            else{
                if(!Manchete.app.shareFromItem){
                    Manchete.app.shareFromItem = Ext.Viewport.add({
                        xtype:'shareNews'
                    });
                }
                Manchete.app.shareFromItem.setData(record.data);
                Manchete.app.shareFromItem.show();
            }*/

            //window.myEl = el;
        }
        else if (node.className.indexOf('back') > -1) {
            list.up('navigationview').pop();
        }
        else{
            this.openNewsItem(list,idx);
        }
    },
    openNewsItem:function(list,idx){
        if(list.getStore().getStoreId() == 'News')
        {
            var store = list.getStore(),
                newItemStore = Ext.getStore('NewsItem'),
                currentPage = store.currentPage,
                pageSize = store.getPageSize(),
                page = (pageSize*(currentPage-1))+idx+1;

            newItemStore.setSorters([]);
            newItemStore.setSorters(store.getSorters());
            newItemStore.setFilters(store.getFilters());
            newItemStore.removeAll();
            newItemStore.currentPage = page;
            newItemStore.load();

            list.up('navigationview').push({
                xtype:'container',
                layout:'card',
                title:list.config.title,
                items:[
                    {
                        xtype:'newsItem',
                        navlist:list.config.navlist
                    }
                ]
            });
        }
    },
    onMediaItemswipe:function(list, index, target, record, e){
        window.myTarget = target;
        if (e.direction == "left") {

            /*var del = target.element.createChild({
                tag:'div',
                cls:'deleteBtn',
                html: 't'
            });
            /*Ext.Anim.run(del, 'slide', {
                direction: 'left',
                easing: 'ease',
                out: false
            });*/

            var removeDeleteButton = function () {
                //console.log('removeDeleteButton')
                //del.destroy();
                target.removeCls('moveIt');
            };

            if(target.getCls().lastIndexOf('moveIt')==-1){
                list.on({
                    single: true,
                    buffer: 250,
                    itemtouchstart: removeDeleteButton
                });
                list.element.on({
                    single: true,
                    buffer: 250,
                    touchstart: removeDeleteButton
                });
            }
            target.addCls('moveIt');

        }

    },
    setNewsItemEvents:function(cmp){
        //cmp.element.on('tap', this.newsItemTap, cmp);
        cmp.element.on('swipe', this.newsItemSwipe, cmp);
    },
    newsItemTap:function(e,target){
        var data = this.getData();
        if(target.className=='favorite'){

        }
        if(target.className=='file'){
            var ref = window.open(Ext.htmlDecode(data.link), '_blank', 'location=yes,EnableViewPortScale=yes');
            ref.addEventListener('exit', function(event) {
                Manchete.app.getController('MancheteDB').db = rootdb;
            });
        }
        if(target.className=='trash'){
            this.up('navigationview').pop();
        }
    },
    newsItemSwipe:function(e, target){
        //console.log('swipe: ' + e.direction);
        var store = this.getStore();
        if(e.direction == 'left'){

            if(store.currentPage < store.getProxy().totalItems){
                store.nextPage();
            }
            else{
                this.up('navigationview').pop();
            }

        }
        else if(e.direction == 'right'){
            if(store.currentPage > 1){
                store.previousPage();
            }
            else{
                this.up('navigationview').pop();
            }
        }

        this.setShowAnimation({
            duration: 300,
            easing: 'ease-out',
            type: 'slide',
            direction: e.direction
        }).show();
        /*var idx = this.getData().idx,
            nextItem,data;
        if(e.direction == 'left'){
            idx++;
        }
        else{
            idx--;
        }
        nextItem = this.getData().store.getData().items[idx];
        //console.log(nextItem.data.texto != '');
        /*Manchete.app.getController('MancheteDB').getFieldById(nextItem.data.id, 'publicacao', function(data){
            console.log(data)
        });*/


        /*if(nextItem){
            Ext.getStore('NewsItem').load({
                params:{
                    Id: JSON.stringify({
                        "id": nextItem.data.id,
                        "tipo": nextItem.data.tipo,
                        "data": nextItem.data.data
                    })
                },
                callback:function(records,operation, successful){
                    if(successful){
                        console.log(records[0].data.texto);
                    }
                }
            });
            /*Ext.data.JsonP.request({
             url: 'https://services.manchete.pt:8002/Clientes.asmx/getTextbyId',
             callbackKey: 'callback',
             params: {
             user: 'pgeraldes@mobinteg.com',
             password: 'Pass123',
             Id: JSON.stringify({
             "id": nextItem.data.id,
             "tipo": nextItem.data.tipo,
             "data": nextItem.data.data
             })
             },
             success: function (result, request) {
             nextItem.data.text = result;
             console.log(nextItem.data.text);
             }
             });*/
            /*data = nextItem.data;
            data.idx = idx;
            data.store = this.getData().store;

            this.hide();
            this.setData(nextItem.data);
            this.setShowAnimation({
                duration: 300,
                easing: 'ease-out',
                type: 'slide',
                direction: e.direction
            }).show();

        }*/
    },
    saveFile:function(record){
        var me = this,
            url = Ext.htmlDecode(record.data.link),
            id = record.data.id;

        Ext.Viewport.setMasked({xtype: 'loadmask', message:'<div style="padding:10px; background-color:rgba(0, 0, 0, 0.25); ">' +
            '<span style="color:#ffffff;">loading...</span>' +
            '</div>'});

        window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function(fs){

            //fs.root.getDirectory('mynetpress', {create: true, exclusive: false}, function(parent){

                var splitter = url.split('/'),
                    fileStr = '/'+splitter[splitter.length-1],
                    pdfPath = rootFolder + fileStr,//pdfPath = fs.root.fullPath + '/mynetpress' + fileStr,//parent.fullPath + fileStr,
                    fileTransfer = new FileTransfer();


            /*fileTransfer.onprogress = function (progressEvent) {
                if (progressEvent.lengthComputable) {
                    console.log(progressEvent.loaded / progressEvent.total);
                    //loadingStatus.setPercentage(progressEvent.loaded / progressEvent.total);
                } else {
                    //loadingStatus.increment();
                }
            };*/

                fileTransfer.download(url, pdfPath, function (entry) {
                    Ext.Viewport.setMasked(false);
                    if(record.stores.length > 0){
                        record.set('downloaded', 1);
                        Manchete.app.getController('MancheteDB').updateFieldById(id,'downloaded', 1);
                        //record.setDirty();
                        //record.stores[0].sync();

                        //console.log('pdfPath: '+pdfPath);

                        if(Ext.os.is.Android){
                            me.openlink(pdfPath, '_system','pdf');
                        }
                    }
                    else{
                        Manchete.app.getController('MancheteDB').updateFieldById(id, 'downloaded', 1);
                    }
                    //console.log(JSON.stringify(entry));
                }, function (){
                    //console.log('download error!!!');
                    Ext.Viewport.setMasked(false);
                });

            //}, me.onFSError);

        }, me.onFSError);
    },
    removeFile:function(url){
        var me = this,
            splitter = url.split('/'),
            fileStr = '/'+splitter[splitter.length-1],
            pdfPath = rootFolder + fileStr;

        window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function(fs){
            fs.root.getFile(pdfPath, {create: false, exclusive: false}, function(entry){
                entry.remove(function(){
                    //console.log('removed');
                }, function (){
                    //console.log('remove file error!!!');
                })
            }, me.onFSError);
        }, me.onFSError);
    },
    removeMultipleFiles:function(urls){
        var me = this;

        window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function(fs){

            var me = this,
                len = urls.length,
                splitter,fileStr,pdfPath;

            for(var i=0;i<len;i++){
                splitter = urls[i].split('/');
                fileStr = '/'+splitter[splitter.length-1];
                pdfPath = rootFolder + fileStr;

                fs.root.getFile(pdfPath, {create: false, exclusive: false}, function(entry){
                    entry.remove(function(){
                        //console.log('removed');
                    }, function (){
                        //console.log('remove file error!!!');
                    })
                }, me.onFSError);

            }
        }, me.onFSError);
    },
    onFSError:function(){
        //console.log('FileSystem error!!!');
    },




    searchNews:function(btn){
        //exemplo: 'SELECT id,titulo,texto FROM NEWS WHERE texto LIKE "%indignado%" OR titulo LIKE "%indignado%"'
        //console.log(Ext.getCmp('contentView').getActiveItem().getXTypes());

        /*if (Ext.getCmp('contentView').down('mediaType')){// && !Ext.getCmp('contentView').down('#newsSearch')) {
            Ext.getCmp('contentView').down('mediaType').push({
                xtype: 'container',
                layout: 'card',
                items: [
                    {
                        xtype: 'newsSearch'
                        //data: this.optionData
                    }
                ]

            });
        }*/
        if (!Ext.getCmp('contentView').down('newsSearch')){
            this.showViews('newsSearch');
        }
    },
    filterNews:function(btn){
        //if(this.actualView != '' && this.actualView != 'manchetesCarousel'){
        //this.showViews('newsFilters');
        if ((Ext.getCmp('contentView').down('mediaType') || Ext.getCmp('contentView').down('newsGrid')) && !Ext.getCmp('contentView').down('#newsFilters')) {
            var flag = !Ext.getCmp('contentView').down('mediaType'),
                view = flag?Ext.getCmp('contentView').down('newsGrid'):Ext.getCmp('contentView').down('mediaType');

            view.push({
                xtype: 'container',
                layout: 'card',
                items: [
                    {
                        xtype: 'newsFilters'
                        //data: this.optionData
                    }
                ]

            });
        }
        else if(Ext.getCmp('contentView').down('manchetes') && !Ext.getCmp('contentView').down('#newsFilters')){

            this.showViews('headlinesFilters');
        }


        //}
    },
    refreshNews:function(btn){
        if(window.navigator.onLine){
            Ext.Viewport.getMasked().setHidden(false);
            Ext.getCmp('contentView').getActiveItem().hide();
            if(!localStorage.mancheteuser){
                //this.showViews(this.actualView);
                //Ext.getCmp('contentView').getActiveItem().hide();
            }
            else{
                var records = Ext.getStore('MenuClippingTable').getData().items,
                    realRecords = [];

                for(var i in records){
                    if(records[i].data.activo == 1){
                        realRecords.push(records[i]);
                    }
                }
                //Ext.getCmp('contentView').getActiveItem().hide();
                this.setNewsLoaded(false);
                this.setHeadlinesLoaded(false);
                this.loadStores(realRecords);

            }
            Ext.getStore('Headlines').load();
        }
        else{
            Ext.device.Notification.show({
                title: 'Internet',
                message: 'Sem ligação à internet.',
                buttons:['OK']
            });
        }

    },
    newsLayout:function(btn){
        if(!btn.getDisabled()){
            var type = btn.getIconCls();
            btn.setDisabled(true);
            if(type == 'ss-rows'){
                btn.setIconCls('ss-grid');
                localStorage.manchetenewsview = 'mediaType';
            }
            else{
                btn.setIconCls('ss-rows');
                localStorage.manchetenewsview = 'newsGrid';
            }
            this.showViews(localStorage.manchetenewsview);
            //Ext.getStore('News').load();
            setTimeout(function(){
                btn.setDisabled(false);
            },300);
        }


    },
    backToManchetes:function(){
        this.showViews('manchetes');
    },
    mancheteNews:function(btn){
        //this.showViews('manchetesCarousel');

        if(!btn.getDisabled()){
            var type = btn.getIconCls();
            btn.setDisabled(true);
            if(type == 'ss-rows'){
                btn.setIconCls('ss-grid');
                this.showViews('manchetes');
            }
            else{
                btn.setIconCls('ss-rows');
                this.showViews('manchetesGrid');
            }
            //Ext.getStore('News').load();
            setTimeout(function(){
                btn.setDisabled(false);
            },300);
        }
    },
    coverNews:function(btn){
        this.showViews('manchetes');
    },
    openSettings:function(){
        this.fromLogin = null;
        if(!localStorage.mancheteuser){
            if(!this.loginForm){
                this.loginForm = Ext.Viewport.add({xtype:'loginForm'});
            }
            this.loginForm.show();
            this.fromLogin = 'settingsView';
        }
        else{
            if (!Ext.getCmp('contentView').down('settingsView')){
                this.showViews('settingsView');
            }
        }
    },
    openUser:function(){
        this.fromLogin = null;
        if(!localStorage.mancheteuser){
            if(!this.loginForm){
                this.loginForm = Ext.Viewport.add({xtype:'loginForm'});
            }
            this.loginForm.show();
            this.fromLogin = 'settingsView';
        }
        else{
            if (!Ext.getCmp('contentView').down('userView')){
                Ext.getStore('UserDetails').load();
                this.showViews('userView');
            }

        }
    },
    openInfo:function(){
        if (!Ext.getCmp('contentView').down('infoView')){
            this.showViews('infoView');
        }
    },

    showAndHideBtns:function(ref){
        var btns = this.getMainToolbar().query('button'),
            len = btns.length,
            whenHide;

        for(var i=0;i<len;i++){
            whenHide = btns[i].config.whenHide;
            btns[i].setHidden((whenHide[0]=='always')?'true':whenHide.lastIndexOf(ref) >= 0);
        }
        /*if(ref == 'mediaType' && Ext.getStore('News').getFilters().length < 2){
            this.getSearchNewsBtn().setHidden(false);
        }*/
    },

    loadRemoteNews:function(){
        var me = this,
            sevenDays = 24 * 60 * 60 * 1000 * 1,
            datafim = new Date(),
            store = Ext.getStore('MediaType'),
            lastTime, datainicio;
        lastTime = localStorage.mancheteLastTimeALLNews;
        datainicio = new Date(!lastTime ? datafim.getTime() - sevenDays : lastTime);

        if ((datafim.getTime() - datainicio.getTime()) >= sevenDays) {
            datainicio.setTime(datafim.getTime() - sevenDays);
        }
        //console.log(Ext.Date.format(datainicio, 'Y-m-d H:i'));
        //console.log(Ext.Date.format(datafim, 'Y-m-d H:i'));

        Ext.Viewport.setMasked({xtype: 'loadmask', message:'<span style="color:#ffffff;">loading...</span>'});

        store.load({
            params: {
                user: localStorage.mancheteuser,//'teste@manchete.pt',
                password: localStorage.manchetepass,//'b9Wk9Yeq',
                datainicio: Ext.Date.format(datainicio, 'Y-m-d H:i'),//Ext.Date.format(dt, 'm-d-Y'),
                datafim: Ext.Date.format(datafim, 'Y-m-d H:i'),//Ext.Date.format(new Date(), 'm-d-Y'),
                referencia3: ''
            },
            callback:function(){
                Ext.Viewport.setMasked(false);
            }
        });
    },


    loadStores: function (records) {
        var me = this;
        me.totalStores = records.length;

        var sevenDays = 24 * 60 * 60 * 1000 * 1,
            datafim = new Date(),
            store = Ext.getStore('MediaType'),
            lastTime, datainicio;
        //console.log(records[me.actualStore].data);
        lastTime = localStorage['mancheteLastTime' + records[me.actualStore].data.referencia3];
        datainicio = new Date(!lastTime ? datafim.getTime() - sevenDays : lastTime);

        if ((datafim.getTime() - datainicio.getTime()) >= sevenDays) {
            datainicio.setTime(datafim.getTime() - sevenDays);
        }
        //console.log(Ext.Date.format(datainicio, 'Y-m-d H:i'));
        //console.log(Ext.Date.format(datafim, 'Y-m-d H:i'));

        if (me.getMediaType()) {
            me.getMediaType().setLoadingText(false);
        }
        /*Ext.Viewport.setMasked({xtype: 'loadmask', message:'<div style="padding:10px; background-color:rgba(0, 0, 0, 0.25); ">' +
         '<span style="color:#ffffff;">'+records[me.actualStore].data.clipping+'</span>' +
         '</div>'});*/
        if (Ext.Viewport.getMasked().isHidden()) {
            Ext.Viewport.getMasked().setHidden(false);
        }

        /*
         var ldText = ''
         for(var i=0;i< me.totalStores;i++){
         ldText += (i<=me.actualStore?'● ':'○ ');
         }
         Ext.Viewport.getMasked().setMessage('<div style="padding:10px; background-color:rgba(0, 0, 0, 0.25); color:#ffffff;">' +
         '<span>'+ldText+'</span></div>');
         */
        //console.log('************ ' + me.actualStore);
        if(me.actualStore == 0 && (typeof(window.deviceToken) != "undefined")){
                // prepare here to clean DB
            this.stateNotification();
        }

        store.load({
            params: {
                user: localStorage.mancheteuser,
                password: localStorage.manchetepass,
                datainicio: Ext.Date.format(datainicio, 'Y-m-d H:i'),//Ext.Date.format(dt, 'm-d-Y'),
                datafim: Ext.Date.format(datafim, 'Y-m-d H:i'),//Ext.Date.format(new Date(), 'm-d-Y'),
                referencia3: records[me.actualStore].data.referencia3
            },
            callback: function (recs, operation, success) {
                //console.log('$$$$$$$$$$$$$$$$$')
                //console.log(me.actualStore > me.totalStores)
                if (success) {
                    me.actualStore++;
                    if (me.actualStore < me.totalStores) {
                        me.loadStores(records);
                    }
                    else {
                        me.actualStore = 0;
                        me.allPubsDone = true;
                        //me.getMediaType().setLoadingText(' ');
                        me.setNewsLoaded(true);
                        if (me.getHeadlinesLoaded()) {
                            Ext.Viewport.setMasked(false);
                            me.showViews(me.actualView);
                            me.setNewsLoaded(false);
                            me.setHeadlinesLoaded(false);
                        }
                        if (!me.fromLogin == false) {
                            if (typeof(me.fromLogin) == 'string') {
                                me.showViews(me.fromLogin);
                            }
                            else {
                                var menu = Ext.getCmp('m-menu'),
                                    idx = me.fromLogin,
                                    el = menu.getItemAt(idx);
                                Manchete.app.getController('Main').onMenuItemtap(menu, idx, el, el.getRecord());

                                //me.showNews(Ext.getCmp('m-menu').getItemAt(me.fromLogin).getRecord().data);
                            }
                            me.fromLogin = null;
                        }
                        //Manchete.app.getController('Publications').loadPublications(records);
                    }
                }
                else {
                    Ext.Viewport.setMasked(false);
                    me.showViews(me.actualView);
                    me.setNewsLoaded(false);
                    me.setHeadlinesLoaded(false);
                    me.actualStore = 0;
                    Ext.device.Notification.show({
                        title: 'Internet',
                        message: 'Não foi possível obter novas notícias, por favor tente mais tarde.',
                        buttons: ['OK']
                    });
                }
            }
        });
        if(!me.getAllPubsDone()){
            Manchete.app.getController('Publications').setPublications1by1(records[me.actualStore].data);
        }
    },
    headlinesLoaded:function(){
        this.setHeadlinesLoaded(true);
        if(this.getNewsLoaded()){

            this.showViews(this.actualView);
            this.setNewsLoaded(false);
            this.setHeadlinesLoaded(false);
            Ext.Viewport.setMasked(false);
        }
        if(!localStorage.mancheteuser){
            this.showViews(this.actualView);
            Ext.Viewport.setMasked(false);
        }
        /*if(Ext.getCmp('contentView').down('manchetesGrid')){

        }
        else if(Ext.getCmp('contentView').down('manchetesCarousel')){

        }*/
    },
     stateNotification:function(){
         Ext.data.JsonP.request({
             url: 'https://services.manchete.pt:8002/Clientes.asmx/StateNotifications',
             callbackKey: 'callback',
             params: {
                 user:localStorage.mancheteuser,
                 password:localStorage.manchetepass,
                 deviceType:device.platform,
                 deviceToken:window.deviceToken
             },
             success: function (response) {
                 var result = response.estadoNot;
                 if(result != null){
                     localStorage.manchetenotification = (result=='true')?1:0;
                 }

             },
             failure: function (error) {

                 /*Ext.device.Notification.show({
                     title: 'Notificações',
                     message: 'Sem ligação à internet. Não foi possível alterar',
                     buttons: Ext.MessageBox.OK
                 });*/
             }
         });
     },


























    fullStores:function(records){
        var me = this;
        me.totalStores = records.length;

        var sevenDays = 24 * 60 * 60 * 1000 * 1,
            store = Ext.getStore('MediaType'),
            datafim = !localStorage.mancheteLastTimeFULL?new Date():new Date(parseInt(localStorage.mancheteLastTimeFULL)),
            lastTime = datafim.getTime(),
            datainicio;

        datainicio = new Date(lastTime - sevenDays);

        //console.log(Ext.Date.format(datainicio, 'Y-m-d H:i'));
        //console.log(Ext.Date.format(datafim, 'Y-m-d H:i'));

        if(me.getMediaType()){
            me.getMediaType().setLoadingText(false);
        }
        if(Ext.Viewport.getMasked().isHidden()){
            Ext.Viewport.getMasked().setHidden(false);
        }

        store.load({
            params: {
                user: localStorage.mancheteuser,
                password: localStorage.manchetepass,
                datainicio: Ext.Date.format(datainicio, 'Y-m-d H:i'),//Ext.Date.format(dt, 'm-d-Y'),
                datafim: Ext.Date.format(datafim, 'Y-m-d H:i'),//Ext.Date.format(new Date(), 'm-d-Y'),
                referencia3: records[me.actualStore].data.referencia3
            },
            callback:function(){
                me.actualStore++;
                if(me.actualStore < me.totalStores ){
                    //me.fullStores(records);
                }
                else{
                    localStorage.mancheteLastTimeFULL = datainicio.getTime();
                    me.actualStore = 0;
                    //me.fullStores(records);
                    //Ext.Viewport.setMasked(false);
                }
                if(Ext.Date.diff(datainicio, new Date(), Ext.Date.MONTH) < 4){
                    me.fullStores(records);
                }
                else{
                    delete localStorage.mancheteLastTimeFULL;
                    Ext.Viewport.setMasked(false);
                }
            }
        });
    }
});


