/**
 * Created by zul on 21/01/14.
 */
Ext.define('Manchete.controller.Publications', {
    extend: 'Ext.app.Controller',

    config: {
        refs: {

        },
        control: {

        },
        totalClippings:0,
        clippingId:0,
        clippingRecords:null
    },
    init: function () {

    },
    loadPublications:function(records){

        var len = records.length;

        this.setTotalClippings(records.length);
        this.setClippingRecords(records);

        if(len > 0){
            this.setPublications1by1(records[0].data);
            //this.setPublications(records, len);
        }


    },
    setPublications1by1:function(data){
        var me = this;
        Ext.getStore('Publications').load({
            params:{
                user: localStorage.mancheteuser,
                password: localStorage.manchetepass,
                tipo:data.referencia3
            },
            callback:function(recs, operation, success){

                if(success){
                    Manchete.app.fireEvent('deletePublications', data.referencia3);
                    Manchete.app.fireEvent('insertRecords', recs, 'PublicationsTable');
                }
                var len = me.getTotalClippings(),
                    id = me.getClippingId(),
                    records = me.getClippingRecords();
                if(id < len-1){
                    me.setPublications1by1(records[id+1].data);
                    me.setClippingId(id+1);
                }
            }
        });
    },
    setPublications:function(records, total){
        var me = this,
            data = null;

        for(var i=0; i<total; i++){

            data = records[i].data;

            Ext.getStore('Publications').load({
                params:{
                    user: localStorage.mancheteuser,
                    password: localStorage.manchetepass,
                    tipo:data.referencia3
                },
                callback:function(recs, operation, success){

                    if(success){

                        Manchete.app.fireEvent('deletePublications', recs[0].data.tipo);
                        Manchete.app.fireEvent('insertRecords', recs, 'PublicationsTable');
                    }
                }
            });
        }
    }
});