/**
 * Created by zul on 08/10/13.
 */
Ext.define('Manchete.controller.Settings', {
    extend: 'Ext.app.Controller',

    config: {
        refs: {
            settingsView:'settingsView',
            titleHistory:'settingsView #titleHistory',
            sliderHistory:'settingsView #sliderHistory',
            loginClean: 'loginClean formpanel'
        },
        control: {
            settingsView:{
                initialize:'setInit'
            },
            sliderHistory:{
                change:'hSliderChange'
            },
            'button[action=limpardados]': {
                tap: 'limpardados'
            },
            'togglefield[name=language]': {
                initialize:'giveTapEvent'
            },
            'togglefield[name=notification]': {
                initialize:'notificationONOFF',
                change:'onNotificationChange'
            },
            'button[action=confirmToClean]': {
                tap: 'confirmToClean'
            }
        },
        howManyDays: localStorage.manchetemaxhistory
    },
    init: function () {
         this.cleanTimer = 0;
    },
    setInit:function(){
        this.getTitleHistory().setHtml('Histórico: <span class="set-blue">' + localStorage.manchetemaxhistory + 'dias</span>');
        this.getSliderHistory().setValue(localStorage.manchetemaxhistory);
    },
    limpardados: function (btn) {

        if(!this.loginForm){
            this.loginForm = Ext.Viewport.add({xtype:'loginClean'});
        }
        this.loginForm.show();
    },
    confirmToClean:function(){
        var form = this.getLoginClean(),
            values = form.getValues(),
            store;

        if (values.user != '' && values.password != '') {

            if (this.isMail(values.user)) {
                if (values.user == localStorage.mancheteuser && values.password == localStorage.manchetepass) {
                    this.cleanWarn();
                }
                else {
                    Ext.Msg.alert("Login", "Nome de utilizador ou palavra passe errados.", Ext.emptyFn);
                }
            }
            else {
                Ext.Msg.alert('Login', 'O seu e-mail não é válido.', Ext.emptyFn);
            }
        }
        else {
            Ext.Msg.alert('Login', 'Os dois campos são obrigatórios', Ext.emptyFn);
        }
    },
    cleanWarn:function(){
        var me = this,
            newValue = this.getHowManyDays();

        if(localStorage.manchetemaxhistory > newValue){
            Ext.device.Notification.show({
                title: 'Confirmação',
                message: 'Todos os dados posteriores ao máximo definidos no histórico serão removidos, excepto favoritos.',
                buttons: [{text: 'Não'}, {text: 'Sim', ui: 'action'}],
                callback: function (button) {
                    if (button.toLowerCase() == "sim") {
                        me.startClean(true, newValue);
                    }
                }
            });
        }
        else{
            me.startClean(false, newValue);
        }
    },
    startClean:function(flag, newValue){
        localStorage.manchetemaxhistory = newValue;

        Ext.getStore('NewsRemover').setFilters([
            {
                property: 'favorito',
                value   : '0'
            },
            {
                property: 'data?<=',
                value: 'date("now", "-'+newValue+' days")'
            }
        ]);
        if(flag){
            Ext.getStore('NewsRemover').load();
        }
        this.loginForm.hide();
        /*clearTimeout(this.cleanTimer);
         this.cleanTimer = setTimeout(function(){
         Ext.getStore('NewsRemover').load();
         },3000);*/
    },
    hSliderChange:function(cmp, sl, thumb, newValue, oldValue){
        var th = this.getTitleHistory();
        th.setHtml('Histórico: <span class="set-blue">' + newValue + 'dias</span>');
        this.setHowManyDays(newValue);
    },
    giveTapEvent:function(cmp){
        //isto é temporário
        cmp.element.on('tap',function(){
            Ext.Msg.alert("Language", "Ainda não está disponível!", Ext.emptyFn);
        });
    },
    isMail: function (mail) {
        var emailRegEx = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;

        return mail.search(emailRegEx) != -1 ? true : false;
    },
    notificationONOFF:function(toggle){
        var flag = (localStorage.getItem('manchetenotification') != 0);
        toggle.ignoreChange = flag;
        toggle.setValue(flag?1:0);
    },
    onNotificationChange:function(toggle, newValue, oldValue){

        if(!toggle.ignoreChange){

            if(typeof(window.deviceToken) != "undefined"){
                var message = 'As suas notificações foram '+(newValue==1?'ativadas':'desativadas');
                Ext.Viewport.getMasked().setHidden(false);
                Ext.data.JsonP.request({
                    url: 'https://services.manchete.pt:8002/Clientes.asmx/ActivateNotifications',
                    callbackKey: 'callback',
                    params: {
                        user:localStorage.mancheteuser,
                        password:localStorage.manchetepass,
                        deviceType:device.platform,
                        deviceToken:window.deviceToken,
                        activate:(newValue==1)
                    },
                    success: function (response) {

                        localStorage.manchetenotification = newValue;
                        if(newValue==1){
                            startPushNotification();
                        }
                        else{
                            stopPushNotification();
                        }
                        Ext.device.Notification.show({
                            title: 'Notificações',
                            message: message,
                            buttons: Ext.MessageBox.OK
                        });
                        Ext.Viewport.setMasked(false);
                    },
                    failure: function (error) {
                        localStorage.manchetenotification = oldValue;
                        if(toggle){
                            toggle.ignoreChange = true;
                            toggle.setValue(oldValue);
                        }
                        Ext.device.Notification.show({
                            title: 'Notificações',
                            message: 'Sem ligação à internet. Não foi possível alterar',
                            buttons: Ext.MessageBox.OK
                        });
                        Ext.Viewport.setMasked(false);
                    }
                });
            }
            else{
                localStorage.manchetenotification = newValue;
            }
        }
        toggle.ignoreChange = false;
    }
});