/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 17/09/13
 * Time: 00:52
 */
Ext.define('Manchete.model.MediaType', {
    extend: 'Ext.data.Model',

    config: {
        fields: [
            'id',
            'titulo',
            'publicacao',
            'suplemento',
            {
                name:'tipo',
                convert:function(vl){
                    vl = vl.split(';')[0];
                    if(vl == 'jaa' || vl == 'jab'){
                        return 'ja';
                    }
                    return vl;
                }
            },
            'tema',
            'bold',
            'link',
            {
                name:'linkType',
                mapping:'link',
                convert: function (vl) {
                    var linkExt = !vl?'':vl.substring(vl.lastIndexOf('.')+1);
                    if (linkExt == 'pdf') {
                        return 'pdf';
                    }
                    else if (linkExt == 'mp3') {
                        return 'audio';
                    }
                    else if (linkExt == 'mp4') {
                        return 'video';
                    }
                    else if (linkExt == '') {
                        return 'nolink'
                    }
                    return 'site';
                }
            },
            /*{
                name:'linkType',
                mapping:'tipo',
                convert: function (vl) {
                    if (vl[0] == 'j') {
                        return 'pdf'
                    }
                    else if (vl[0] == 'r') {
                        return 'audio'
                    }
                    else if (vl[0] == 't') {
                        return 'video'
                    }
                    return 'site';
                }
            },*/
            {
                name:'data',
                convert:function(vl){
                    var str = !vl?'':vl.split(' ')[0];
                    return str;
                }
            },
            {
                name:'data_insercao',
                convert:function(vl){
                    var str = !vl?'':vl.split(' ')[0];
                    return str;
                }
            },
            'hora_insercao',
            'jornalista',
            'paginas',
            'duracoes',
            {
                name:'texto',
                //mapping:'resumo',
                /*convert:function(vl, rec){
                    var texto = !rec.raw.texto?rec.raw.resumo:rec.raw.texto;
                    return texto;
                },*/
                defaultValue:''
            },
            {
                name:'favorito',
                type:'int',
                allowNull:false,
                defaultValue:0
            },
            {
                name:'downloaded',
                type:'int',
                allowNull:false,
                defaultValue:0
            },
            {
                name:'completed',
                type:'int',
                defaultValue:0
            }
        ]
    }
});