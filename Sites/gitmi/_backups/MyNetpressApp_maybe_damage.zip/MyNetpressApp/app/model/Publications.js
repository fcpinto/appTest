/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 17/09/13
 * Time: 00:52
 */
Ext.define('Manchete.model.Publications', {
    extend: 'Ext.data.Model',

    config: {
        //idProperty:'fonte',
        identifier: 'uuid',
        fields:[
            {
                name:'publicacao',
                mapping:'fonte'
            },
            'tipo',
            {
                name:'text',
                mapping:'fonte'
            },
            {
                name:'value',
                mapping:'fonte'
            }
        ]
    }
});


