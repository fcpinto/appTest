/**
 * Created by zul on 30/09/13.
 */
Ext.define('Manchete.util.MancheteSql', {
    override: 'Ext.data.proxy.Sql',

    config: {
        tableExists: true
    },

    constructor: function (config) {
        this.callParent(arguments); // calls My.app.Panel's constructor

    },
    selectRecords: function(transaction, params, callback, scope) {
        var me = this,
            table = me.getTable(),
            idProperty = me.getModel().getIdProperty(),
            selectColumn = me.config.selectColumn,
            existColumn = (typeof (selectColumn) == 'string'),
            sql = 'SELECT '+(existColumn?selectColumn:'*')+' FROM ' + table,
            records = [],
            filterStatement = ' WHERE ',
            sortStatement = ' ORDER BY ',
            i, ln, data, result, count, rows, filter, sorter, property, value, biggerSmaller,
            ownQuery = '';

        console.log(typeof (column) == 'string');

        result = new Ext.data.ResultSet({
            records: records,
            success: true
        });

        if (!Ext.isObject(params)) {
            sql += filterStatement + idProperty + ' = ' + params;
        } else {
            ln = params.filters && params.filters.length;
            if (ln) {
                for (i = 0; i < ln; i++) {
                    filter = params.filters[i];
                    property = filter.getProperty();
                    value = filter.getValue();
                    if (property !== null) {
                        if(property.lastIndexOf('?')>=0){
                            biggerSmaller = property.split('?');
                            sql += filterStatement + biggerSmaller[0] + ' ' + (filter.getAnyMatch() ? ('LIKE \'%' + value + '%\'') : (biggerSmaller[1] + ' ' + value));
                            filterStatement = ' AND ';
                        }
                        else if(property == 'ownQuery'){
                            ownQuery = value;
                            sql = value;
                        }
                        else{
                            if(filter.config.values){
                                var values = filter.config.values;
                                var vlsLen = values.length;

                                if(filter.getAnyMatch())
                                {
                                    sql += filterStatement + '(';
                                    filterStatement = '';
                                    for(var j=0;j<vlsLen;j++){
                                        sql += filterStatement + property + (' LIKE \'%' + values[j] + '%\'');
                                        filterStatement = (j<vlsLen-1)?' OR ':'';
                                    }
                                    sql += ')';
                                    filterStatement = ' AND ';
                                }
                                else{
                                    sql += filterStatement + property + ' IN ("';
                                    sql += values.join('","');
                                    sql += '")';
                                    filterStatement = ' AND ';
                                }
                            }
                            else{
                                sql += filterStatement + property + ' ' + (filter.getAnyMatch() ? ('LIKE \'%' + value + '%\'') : ('= \'' + value + '\''));
                                filterStatement = ' AND ';
                            }
                        }

                    }
                }
            }

            ln = params.sorters && params.sorters.length;
            if (ln) {
                for (i = 0; i < ln; i++) {
                    sorter = params.sorters[i];
                    property = sorter.getProperty();
                    if (property !== null) {
                        sql += sortStatement + property + ' ' + sorter.getDirection();
                        sortStatement = ', ';
                    }
                }
            }

            // handle start, limit, sort, filter and group params
            if (params.page !== undefined) {
                me.getTotalItems(transaction,sql);
                if(params.limit !== false){
                    sql += ' LIMIT ' + parseInt(params.start, 10) + ', ' + parseInt(params.limit, 10);
                }
            }
        }
        /*if(ownQuery != ''){
            sql = ownQuery;
        }*/
        console.log(sql);
        transaction.executeSql(sql, null,
            function(transaction, resultSet) {
                rows = resultSet.rows;
                count = rows.length;

                for (i = 0, ln = count; i < ln; i++) {
                    data = rows.item(i);
                    records.push({
                        clientId: null,
                        id: data[idProperty],
                        data: data,
                        node: data
                    });
                }

                result.setSuccess(true);
                result.setTotal(count);
                result.setCount(count);
                //console.log(result)
                if (typeof callback == 'function') {
                    callback.call(scope || me, result);
                }
                //console.log(callback, scope, me, result);
            },
            function(transaction, errors) {
                result.setSuccess(false);
                result.setTotal(0);
                result.setCount(0);

                if (typeof callback == 'function') {
                    callback.call(scope || me, result);
                }
            }
        );
    },
    getTotalItems:function(transaction,sql){
        var me = this,
            countSql = sql.replace('SELECT * ', 'SELECT COUNT(*) ');

        transaction.executeSql(countSql, [],
            function(tx,resultSet){
                me.totalItems = resultSet.rows.item(0)['COUNT(*)'];
            },
            function(tx, errors) {
                me.totalItems = null;
            }
        );
    },
    getDatabaseObject: function() {
        return rootdb;
    }
});
