//
//  SocialMessage.h
//  Copyright (c) 2013 Lee Crossley - http://ilee.co.uk
//

#import "Cordova/CDV.h"
#import "Foundation/Foundation.h"
#import <MessageUI/MessageUI.h>

@interface SocialMessage : CDVPlugin <MFMailComposeViewControllerDelegate>

- (void) send:(CDVInvokedUrlCommand*)command;
    

@end