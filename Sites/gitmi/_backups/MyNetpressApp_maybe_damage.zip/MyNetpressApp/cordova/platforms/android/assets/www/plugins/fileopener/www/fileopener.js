cordova.define("fileopener.FileOpener", function(require, exports, module) {
var exec = require("cordova/exec");

var FileOpener = function () {
    this.name = "FileOpener";
};


FileOpener.prototype.open = function(url) {
    exec(null, null, "FileOpener", "openFile", [url]);
};


module.exports = new FileOpener();

});