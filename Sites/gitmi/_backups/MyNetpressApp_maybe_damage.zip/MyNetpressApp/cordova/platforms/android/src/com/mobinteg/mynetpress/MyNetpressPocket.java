/*
       Licensed to the Apache Software Foundation (ASF) under one
       or more contributor license agreements.  See the NOTICE file
       distributed with this work for additional information
       regarding copyright ownership.  The ASF licenses this file
       to you under the Apache License, Version 2.0 (the
       "License"); you may not use this file except in compliance
       with the License.  You may obtain a copy of the License at

         http://www.apache.org/licenses/LICENSE-2.0

       Unless required by applicable law or agreed to in writing,
       software distributed under the License is distributed on an
       "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
       KIND, either express or implied.  See the License for the
       specific language governing permissions and limitations
       under the License.
 */

package com.mobinteg.mynetpress;

//import android.content.Intent;
import java.util.List;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;

import org.apache.cordova.*;

@TargetApi(19)
public class MyNetpressPocket extends CordovaActivity 
{
	//mi::DG
	public static String twitter = null;
	public static Context test = null;
	
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        
        //mi::DG - altera��o feita para splashscreen 
        super.setIntegerProperty("splashscreen", R.drawable.screen);
        
        super.init();
        
        //mi::DG
        twitter = appInstalledOrNot("com.twitter.android");
        test = getApplicationContext();
        
        // Set by <content src="index.html" /> in config.xml
        super.loadUrl(Config.getStartUrl());
        //super.loadUrl("file:///android_asset/www/index.html")
        
        //mi::DG
        if ((getResources().getConfiguration().screenLayout &      Configuration.SCREENLAYOUT_SIZE_MASK) == Configuration.SCREENLAYOUT_SIZE_LARGE) {     
            Log.d("MancheteLog","********* Large screen *********");
            setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        }
        else if ((getResources().getConfiguration().screenLayout &      Configuration.SCREENLAYOUT_SIZE_MASK) == Configuration.SCREENLAYOUT_SIZE_NORMAL) {     
            Log.d("MancheteLog","********* Normal sized screen *********");
            setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } 
        else if ((getResources().getConfiguration().screenLayout &      Configuration.SCREENLAYOUT_SIZE_MASK) == Configuration.SCREENLAYOUT_SIZE_SMALL) {     
            Log.d("MancheteLog","********* Small sized screen *********");
            setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        else {
            Log.d("MancheteLog","********* Screen size is neither large, normal or small *********");
            //setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT){
            if(0 != (getApplicationInfo().flags = ApplicationInfo.FLAG_DEBUGGABLE)){
                Log.i("Your app", "Enabling web debugging");
                WebView.setWebContentsDebuggingEnabled(true);
            }
        }
    }
    
  //mi::DG
    private String appInstalledOrNot(String uri)
    {
        PackageManager pm = getPackageManager();
        String app_installed = null;
        try
        {
           pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
           
           Intent intent = new Intent(Intent.ACTION_SEND);
           intent.putExtra(Intent.EXTRA_TEXT, 0);
           intent.setType("text/plain");
           List<ResolveInfo> resolvedInfoList = pm.queryIntentActivities(intent,  0);
           int len =  resolvedInfoList.size();
           for (int i = 0; i < len; i++) {
        	   final ResolveInfo app = resolvedInfoList.get(i);
        	   if("com.twitter.applib.composer.TextFirstComposerActivity".equals(app.activityInfo.name)){
        		   app_installed = app.activityInfo.name; 
        	   }
        	   if ("com.twitter.applib.PostActivity".equals(app.activityInfo.name)) {
        		   app_installed = app.activityInfo.name; 
        	   }
           }
	    }
        catch (PackageManager.NameNotFoundException e)
        {
               app_installed = null;
        }
        return app_installed ;
    }
}

