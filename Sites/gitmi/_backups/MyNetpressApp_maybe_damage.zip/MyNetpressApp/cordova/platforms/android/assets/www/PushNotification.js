var PushNotification = function() {
};


// Call this to register for push notifications. Content of [options] depends on whether we are working with APNS (iOS) or GCM (Android)
PushNotification.prototype.register = function(successCallback, errorCallback, options) {
    if (errorCallback == null) { errorCallback = function() {}}

    if (typeof errorCallback != "function")  {
        console.log("PushNotification.register failure: failure parameter not a function");
        return
    }

    if (typeof successCallback != "function") {
        console.log("PushNotification.register failure: success callback parameter must be a function");
        return
    }

	cordova.exec(successCallback, errorCallback, "PushPlugin", "register", [options]);
};

// Call this to unregister for push notifications
PushNotification.prototype.unregister = function(successCallback, errorCallback) {
    if (errorCallback == null) { errorCallback = function() {}}

    if (typeof errorCallback != "function")  {
        console.log("PushNotification.unregister failure: failure parameter not a function");
        return
    }

    if (typeof successCallback != "function") {
        console.log("PushNotification.unregister failure: success callback parameter must be a function");
        return
    }

     cordova.exec(successCallback, errorCallback, "PushPlugin", "unregister", []);
};
 
 
// Call this to set the application icon badge
PushNotification.prototype.setApplicationIconBadgeNumber = function(successCallback, errorCallback, badge) {
    if (errorCallback == null) { errorCallback = function() {}}

    if (typeof errorCallback != "function")  {
        console.log("PushNotification.setApplicationIconBadgeNumber failure: failure parameter not a function");
        return
    }

    if (typeof successCallback != "function") {
        console.log("PushNotification.setApplicationIconBadgeNumber failure: success callback parameter must be a function");
        return
    }

    cordova.exec(successCallback, errorCallback, "PushPlugin", "setApplicationIconBadgeNumber", [{badge: badge}]);
};

//-------------------------------------------------------------------

if(!window.plugins) {
    window.plugins = {};
}
if (!window.plugins.pushNotification) {
    window.plugins.pushNotification = new PushNotification();
}

try{
    if (module.exports) {
        module.exports = PushNotification;
    }
}
catch (error){
    console.log('Error: module is not defined - line 67');
}



//---------------------------------------------------------------------

function startPushNotification(){
    var pushNotification = window.plugins.pushNotification;
    try
    {
        pushNotification = window.plugins.pushNotification;
        if (device.platform == 'android' || device.platform == 'Android') {
            console.log('registering android');
            pushNotification.register(successHandler, errorHandler, {"senderID":"356585683198","ecb":"onNotificationGCM"}); // required!
        } else {
            console.log('registering iOS');
            pushNotification.register(tokenHandler, errorHandler, {"badge":"true","sound":"true","alert":"true","ecb":"onNotificationAPN"}); // required!
        }
    }
    catch(err)
    {
        console.log("There was an error on this page.\n\n");
        console.log("Error description: " + err.message + "\n\n");
    }
}

// handle APNS notifications for iOS
function onNotificationAPN(e) {
    if (e.alert) {
        console.log('push-notification: ' + e.alert);
        navigator.notification.alert(e.alert);
    }

    if (e.sound) {
        var snd = new Media(e.sound);
        snd.play();
    }

    if (e.badge) {
        pushNotification.setApplicationIconBadgeNumber(successHandler, e.badge);
    }
}

// handle GCM notifications for Android
function onNotificationGCM(e) {
    console.log('EVENT -> RECEIVED:' + e.event);

    switch( e.event )
    {
        case 'registered':
            if ( e.regid.length > 0 )
            {
                console.log('REGISTERED -> REGID:' + e.regid);
                // Your GCM push server needs to know the regID before it can push to this device
                // here is where you might want to send it the regID for later use.
                //console.log("regID = " + e.regid);
                window.deviceToken = e.regid;
            }
            break;

        case 'message':
            // if this flag is set, this notification happened while we were in the foreground.
            // you might want to play a sound to get the user's attention, throw up a dialog, etc.
            if (e.foreground)
            {
                console.log('--INLINE NOTIFICATION--');

                // if the notification contains a soundname, play it.
                var my_media = new Media("/android_asset/www/"+e.soundname);
                my_media.play();
            }
            else
            {        // otherwise we were launched because the user touched a notification in the notification tray.
                if (e.coldstart)
                    console.log('--COLDSTART NOTIFICATION--');
                else
                    console.log('--BACKGROUND NOTIFICATION--');
            }

            console.log('MESSAGE -> MSG: ' + e.payload.message);
            console.log('MESSAGE -> MSGCNT: ' + e.payload.msgcnt);
            break;

        case 'error':
            console.log('ERROR -> MSG:' + e.msg);
            break;

        default:
            console.log('EVENT -> Unknown, an event was received and we do not know what it is');
            break;
    }
}

function tokenHandler (result) {
    console.log('token: '+ result);
    window.deviceToken = result;
    // Your iOS push server needs to know the token before it can push to this device
    // here is where you might want to send it the token for later use.
}

function successHandler (result) {
    console.log('success: '+ result);
}

function errorHandler (error) {
    console.log('error :'+ error);
}

function stopPushNotification(){
    var pushNotification = window.plugins.pushNotification;
    try
    {
        pushNotification = window.plugins.pushNotification;
        pushNotification.unregister(function(){
            console.log('UNREGISTERED DEVICE!!');
        }, function(){});
    }
    catch(err)
    {
        console.log("There was an error on this page.\n\n");
        console.log("Error description: " + err.message + "\n\n");
    }
}