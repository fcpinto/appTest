/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 27/08/13
 * Time: 12:13
 */
Ext.define('Manchete.view.ManchetesCarousel', {
    extend: 'Ext.carousel.Carousel',
    xtype: 'manchetesCarousel',

    config: {
        title: 'Manchetes',
        padding: 0,
        cls:'manchetes-carousel',

        /*html:[
            '<div style="background-color: #d0d0d0; color: #ffffff; width: 99%; position: absolute; top: 0; padding: 2px 5px 2px 5px; border-bottom: 1px solid #9d9d9d;"> </div>',
            '<div style="background-color: rgba(0, 0, 0, 0.8); height: 30px; color: #ffffff; width: 99%; position: absolute; bottom: 0;"></div>'
        ].join(''),*/

        listeners: {
            initialize: function (cmp) {
                Manchete.app.fireEvent('getTodayCovers', function (data) {
                    var items = [];
                    for (var i in data) {
                        items.push({
                            xtype:'container',
                            styleHtmlContent:true,
                            layout:'vbox',
                            style:'background-color:#ffffff;',
                            items:[
                                {
                                    xtype:'component',
                                    style:'background-color: rgba(0, 0, 0, 0.7); height: 30px; color: #ffffff; text-align: center; padding: 6px 5px 2px 5px; font-size: 80%;',
                                    html:data[i].data,
                                    docked:'top'
                                },
                                {
                                    xtype: 'img',
                                    src: data[i].linkBig,
                                    style: 'background-size:contain;',
                                    flex:1,
                                    listeners: {
                                        tap: function () {
                                            this.up('manchetesCarousel').fireEvent('mancheteImgtap', this);
                                        },
                                        element: 'element'
                                    }
                                },
                                {
                                    xtype:'component',
                                    style:'background-color: rgba(0, 0, 0, 0.7); height: 30px; color: #ffffff;',
                                    docked:'bottom'
                                }
                            ]
                        })
                    }
                    cmp.add(items);
                    cmp.setActiveItem(parseInt(Manchete.app.mancheteActiveItem));
                });
            }
        }
    }
});
