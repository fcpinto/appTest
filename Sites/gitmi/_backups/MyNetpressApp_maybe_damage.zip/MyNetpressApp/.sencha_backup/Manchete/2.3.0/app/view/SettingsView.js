/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.SettingsView', {
    extend: 'Ext.form.Panel',
    xtype: 'settingsView',

    requires:[
        'Ext.field.Toggle'
    ],

    config: {
        styleHtmlContent:true,
        defaults:{
          padding: '0 0 20 0'
        },
        cls:'settings-form',
        items:[
            {
                xtype: 'container',
                hidden:true,
                items:[
                    {
                        xtype: 'component',
                        cls:'set-title',
                        html:'Espaço Disco(15mb)'
                    },
                    {
                        xtype: 'component',
                        cls:'set-info-t',
                        html:'<div style="padding: 5px 10px 5px 10px;">0 <span style="float: right">MAX</span></div>'
                    },
                    {
                        xtype: 'sliderfield',
                        minValue: 0,
                        maxValue: 100
                    }
                ]
            },
            {
                xtype: 'container',
                items:[
                    {
                        xtype: 'component',
                        itemId:'titleHistory',
                        cls:'set-title',
                        html:'Histórico'
                    },
                    {
                        xtype: 'component',
                        cls:'set-info-t',
                        html:'<div style="padding: 5px 10px 5px 10px;">1 <span style="float: right">30</span></div>'
                    },
                    {
                        xtype: 'sliderfield',
                        itemId: 'sliderHistory',
                        minValue: 1,
                        maxValue: 30
                    }
                ]
            },
            {
                xtype: 'container',
                items:[
                    {
                        xtype: 'component',
                        cls:'set-title',
                        html:'Idioma'
                    },
                    {
                        xtype: 'container',
                        layout:'hbox',
                        cls:'set-info-tb',
                        defaults:{
                            flex: '1'
                        },
                        items:[
                            {
                                xtype: 'component',
                                html: 'PT'
                            },
                            {
                                xtype: 'togglefield',
                                name: 'language',
                                disabled:true
                            },
                            {
                                xtype: 'component',
                                html: 'EN'
                            }
                        ]
                    }
                ]
            },
            {
                xtype:'container',
                html:'<span class="set-grey" style="padding-top: 5px;">limpa todos os dados anteriores ao máximo definido no histório excepto favoritos</span>',
                items:[
                    {
                        xtype:'button',
                        text:'Limpar',
                        action: 'limpardados',
                        ui: 'decline',
                        padding:10,
                        margin:'0 0 5 0 '
                    }
                ]
            }

        ]
    }
});