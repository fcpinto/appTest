/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 16/09/13
 * Time: 15:29
 */
Ext.define('Manchete.store.MenuClippingTable', {
    extend: 'Ext.data.Store',

    config: {
        model: 'Manchete.model.MenuClippingTable',

        sorters: ['priority', 'id'],
        grouper: {
            groupFn: function (record) {
                var cls = record.get('tipo').split(' ')[0].toLowerCase();
                return '<div class="' + cls + '"></div><div class="' + cls + '-color">' + record.get('tipo') + '</div>';
            }
        },
        startTable: true,
        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'CLIPPING',
            enablePagingParams: false
        },
        listeners: {
            beforeload: function (store, operation) {
                //console.log(store.getData().items);
            },
            load: function (st, records, successful, operation) {
                //console.log('MenuClippingTable: ' + successful);
                var notLoggedIn = !localStorage.mancheteuser;

                st.insert(0, [
                    {
                        id: 2004,
                        clipping: 'Manchetes',
                        activo: '2',
                        referencia3: 'manchetesGrid',
                        tipo: 'Notícias',
                        priority: '-1',
                        filters: btoa(JSON.stringify([])),
                        sorters: btoa(JSON.stringify([]))
                    },
                    {
                        id: 2005,
                        clipping: 'Notícias do Dia',
                        activo: notLoggedIn ? '0' : '3',
                        referencia3: 'dia',
                        tipo: 'Notícias',
                        priority: '-1',
                        filters: btoa(JSON.stringify([
                            {
                                property: 'data?>=',
                                value: 'date("now")'
                            }
                        ])),
                        sorters: btoa(JSON.stringify([
                            {
                                property: 'bold',
                                direction: 'DESC'
                            },
                            {
                                property: 'data',
                                direction: 'DESC'
                            },
                            {
                                property: 'publicacao',
                                direction: 'ASC'
                            }
                        ]))
                    },
                    {
                        id: 2006,
                        clipping: 'Notícias do Dia (por Tema)',
                        activo: notLoggedIn ? '0' : '4',
                        referencia3: 'FilterTema',
                        tipo: 'Notícias',
                        priority: '-1',
                        filters: btoa(JSON.stringify([
                            {
                                property: 'data?>=',
                                value: 'date("now")'
                            }
                        ])),
                        sorters: btoa(JSON.stringify([
                            {
                                property: 'data',
                                direction: 'DESC'
                            },
                            {
                                property: 'publicacao',
                                direction: 'ASC'
                            }
                        ]))
                    },
                    {
                        id: 2007,
                        clipping: 'Favoritos',
                        activo: notLoggedIn ? '0' : '3',
                        referencia3: 'favorito',
                        tipo: 'Notícias',
                        priority: '0',
                        filters: btoa(JSON.stringify([
                            {
                                property: 'favorito',
                                value: 1
                            }
                        ])),
                        sorters: btoa(JSON.stringify([
                            {
                                property: 'data',
                                direction: 'DESC'
                            }
                        ]))
                    },
                    {
                        id: 2008,
                        clipping: 'Histórico',
                        activo: notLoggedIn ? '0' : '3',
                        referencia3: 'historico',
                        tipo: 'Notícias',
                        priority: '0',
                        filters: btoa(JSON.stringify([])),
                        sorters: btoa(JSON.stringify([
                            {
                                property: 'data',
                                direction: 'DESC'
                            }
                        ]))
                    }
                ]);
                st.add([
                    {
                        id: 2009,
                        clipping: 'Notícias por Tema',
                        activo: notLoggedIn ? '0' : '4',
                        referencia3: 'FilterTema',
                        tipo: 'Temas',
                        priority: '-1',
                        filters: btoa(JSON.stringify([
                            {
                                property: 'data?>=',
                                value: 'date("now", "-6 days")'
                            }
                        ])),
                        sorters: btoa(JSON.stringify([
                            {
                                property: 'data',
                                direction: 'DESC'
                            },
                            {
                                property: 'publicacao',
                                direction: 'ASC'
                            }
                        ]))
                    }
                ]);
                //console.log('notLoggedIn: '+notLoggedIn);
                //console.log(records);

                if (!notLoggedIn) {
                    var realRecords = [];
                    for (var i in records) {
                        if (records[i].data.activo == 1) {
                            realRecords.push(records[i]);
                        }
                    }
                    if (realRecords.length > 0) {
                        Manchete.app.getController('Main').loadStores(realRecords);
                    }
                    else {
                        Ext.Viewport.setMasked(false);
                    }
                }
                else {
                    Ext.Viewport.setMasked(false);
                }
            }
        }
    }
});