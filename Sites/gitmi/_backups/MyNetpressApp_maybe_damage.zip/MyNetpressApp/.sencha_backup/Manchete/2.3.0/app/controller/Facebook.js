/**
 * Created by zul on 06/11/13.
 */
Ext.define('Manchete.controller.Facebook', {
    extend: 'Ext.app.Controller',

    config: {
        refs: {

        },
        control: {

        }
    },
    init: function () {
            if (Ext.browser.is.WebView){
                var script = document.createElement("script");
                script.type = "text/javascript";
                script.src = "facebook_js_sdk.js";
                script.onload = Ext.bind(this.fbOnWebView, this);
                document.body.appendChild(script);
            }
            else{
                window.fbAsyncInit = Ext.bind(this.fbOnDesktop, this);
                (function (d) {
                    var js, id = 'facebook-jssdk';
                    if (d.getElementById(id)) {
                        return;
                    }
                    js = d.createElement('script');
                    js.id = id;
                    js.async = true;
                    js.src = "//connect.facebook.net/en_US/all.js";
                    d.getElementsByTagName('head')[0].appendChild(js);
                }(document));
            }

    },
    fbOnWebView:function(){
        //console.log('fbOnWebView');
        //FB.Event.subscribe('auth.login', Ext.bind(this.onLogin, this));
        FB.Event.subscribe('auth.logout', Ext.bind(this.onLogout, this));
        FB.init({
            appId: Manchete.app.facebookAppId,
            nativeInterface: CDV.FB,
            useCachedDialogs: false
        });

        this.getLoginFbStatus();
    },
    fbOnDesktop:function(){
        //console.log('fbOnDesktop');
        var controller = this;
        //FB.Event.subscribe('auth.login', Ext.bind(this.onLogin, this));
        FB.Event.subscribe('auth.logout', Ext.bind(this.onLogout, this));
        FB.init({
            appId: Manchete.app.facebookAppId,
            frictionlessRequests: true,
            status     : true,           // check login status
            cookie     : true,           // enable cookies to allow the server to access the session
            xfbml      : true
        });
        this.getLoginFbStatus();
    },
    getLoginFbStatus:function(connected,nonconnected){
        var controller = this;
        FB.getLoginStatus(function (resp) {

            if (resp.status == 'connected') {
                var accessToken = resp.authResponse.accessToken;
                //console.log('logged in');
                if(connected){
                    connected(controller);
                }
                FB.api('/me', function (response) {
                    /*console.log(response.id);
                    console.log(response.name);
                    console.log(response.gender);
                    console.log(response.email);
                    console.log(response.username);*/
                });
            }
            else {
                //console.log('not logged in');
                if(nonconnected){
                    nonconnected(controller);
                }
            }
        });
    },
    startLogin:function(){
        var controller = this;
        FB.login(function(response) {
            controller.onLogin(response)
        },{ scope: "publish_stream,email" });
    },
    onLogin: function(resp) {

        if (resp.status === 'connected') {
            var accessToken = resp.authResponse.accessToken;
            this.accessToken = accessToken;
            FB.api('/me', function (response) {
                //console.log(response.id);
                 //console.log(response.name);
                 //console.log(response.gender);
                 //console.log(response.email);
                 //console.log(response.username);



            });
        }
        else {
            console.log('not logged in');
        }
        //console.log('auth.login event');
    },
    onLogout: function(response) {
        //console.log(response);
        //console.log('auth.logout event');
    },
    publishToFB:function(data,onsuccess){

        var me = this;

        /*FB.api('/me/feed', 'post', {
                message: body,
                privacy: {
                    'value': 'SELF'
                }
            },
            function (response) {
                if (!response) {
                    console.log('Error occured on publish to FB');
                }
                else if(response.error){
                    if(response.error.code == 200){
                        console.log('Permission error');
                        me.startLogin();
                    }
                    else{
                        console.log('Error occured on publish to FB');
                    }
                }
                else {
                    var postID = response.id.split('_');
                    console.log('https://www.facebook.com/' + postID[0] + '/posts/' + postID[1]);
                    onsuccess();
                }
            }
        );*/

        //console.log(Ext.htmlDecode(data.titulo));

        FB.api('/me/feed', 'post', {
                privacy: {
                    'value': 'SELF'
                },
                /*privacy:{
                    'value': 'CUSTOM',
                    'allow': '10150724533865328,10151414724869799,1269766299713,444183589031005'
                },*/
                name: Ext.htmlDecode(data.titulo),
                type: 'link',
                link: Ext.htmlDecode(data.link),
                description: 'in '+ Ext.htmlEncode(data.publicacao) +', '+ data.data,
                picture: 'https://fbcdn-photos-f-a.akamaihd.net/hphotos-ak-ash3/851555_475232129262933_807163637_n.png'
            },
            function (response) {
                if (!response) {
                    console.log('Error occured on publish to FB');
                }
                else if (response.error) {
                    if (response.error.code == 200) {
                        console.log('Permission error');
                        me.startLogin();
                    }
                    else {
                        console.log('Error occured on publish to FB');
                    }
                }
                else {
                    var postID = response.id.split('_');
                    console.log('https://www.facebook.com/' + postID[0] + '/posts/' + postID[1]);
                    onsuccess();
                }
            }
        );
    }

});