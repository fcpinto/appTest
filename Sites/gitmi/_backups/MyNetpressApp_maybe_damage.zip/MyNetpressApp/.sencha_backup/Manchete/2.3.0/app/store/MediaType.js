/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 09/09/13
 * Time: 13:32
 */
Ext.define('Manchete.store.MediaType', {
    extend: 'Ext.data.Store',

    requires: [
        'Ext.data.proxy.JsonP'
    ],

    config:{
        model:'Manchete.model.MediaType',

        proxy:{
            type:"jsonp",
            url: 'https://services.manchete.pt:8002/Clientes.asmx/getNewsPress',

            pageParam:false,
            limitParam:false,
            startParam:false
        },

        listeners:{
            load:function (st, records, successful, operation) {
                //console.log('MediaType: ' + successful);
                if(successful){
                    //console.log(records);

                    Manchete.app.fireEvent('insertRecords', records, 'News');

                    localStorage['mancheteLastTime'+operation.getParams().referencia3] = Ext.Date.parse(operation.getParams().datafim, "Y-m-d H:i", true);
                }
                else{
                    //console.log('error!');

                    Ext.getStore('News').load();
                }
            }
        }
    }
});
