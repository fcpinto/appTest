/**
 * Created by zul on 16/10/13.
 */
Ext.define('Manchete.store.NewsRemover', {
    extend: 'Ext.data.Store',

    config: {
        model: 'Manchete.model.News',

        filters: [
            /*{
                property: 'ownQuery',
                value   : 'SELECT * FROM NEWS WHERE favorito=0 AND (link="" OR data <= date("now", "-30 days"))'//'SELECT * FROM NEWS WHERE data <= date("now", "-30 days")'
            }*/
            {
                property: 'favorito',
                value   : '0'
            },
            {
                property: 'data?<=',
                value: 'date("now", "-'+(!localStorage.manchetemaxhistory?30:localStorage.manchetemaxhistory)+' days")'
            }
        ],
        pageSize:false,
        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'NEWS',
            enablePagingParams:false
        },
        listeners: {
            beforeload: function (st, operation) {

            },
            load: function (st, records, successful, operation) {
                //console.log('NewsRemover: ' + successful);
                //console.log(records);
                var links = [],
                    splitter = [],
                    len = records.length;
                for(var i = 0; i < len; i++){
                    if(records[i].data.downloaded == 1){
                        splitter = records[i].data.link.split('/');
                        links.push('/'+splitter[splitter.length-1]);
                    }
                    st.remove(records[i])
                }
                if(links.length > 0){
                    Manchete.app.getController('Main').removeMultipleFiles(links);
                }
                st.sync();
            }
        }
    }
});