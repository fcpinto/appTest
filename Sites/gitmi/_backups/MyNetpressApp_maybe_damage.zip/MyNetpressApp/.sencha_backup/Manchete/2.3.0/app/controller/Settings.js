/**
 * Created by zul on 08/10/13.
 */
Ext.define('Manchete.controller.Settings', {
    extend: 'Ext.app.Controller',

    config: {
        refs: {
            settingsView:'settingsView',
            titleHistory:'settingsView #titleHistory',
            sliderHistory:'settingsView #sliderHistory'
        },
        control: {
            settingsView:{
                initialize:'setInit'
            },
            sliderHistory:{
                change:'hSliderChange'
            },
            'button[action=limpardados]': {
                tap: 'limpardados'
            },
            'togglefield[name=language]': {
                initialize:'giveTapEvent'
            }
        }
    },
    init: function () {
         this.cleanTimer = 0;
    },
    setInit:function(){
        this.getTitleHistory().setHtml('Histórico: <span class="set-blue">' + localStorage.manchetemaxhistory + 'dias</span>');
        this.getSliderHistory().setValue(localStorage.manchetemaxhistory);
    },
    limpardados: function (btn) {
        Ext.getStore('NewsRemover').load();
    },
    hSliderChange:function(cmp, sl, thumb, newValue, oldValue){
        var th = this.getTitleHistory();
        th.setHtml('Histórico: <span class="set-blue">' + newValue + 'dias</span>');
        localStorage.manchetemaxhistory = newValue;

        Ext.getStore('NewsRemover').setFilters([
            {
                property: 'favorito',
                value   : '0'
            },
            {
                property: 'data?<=',
                value: 'date("now", "-'+newValue+' days")'
            }
        ]);
        clearTimeout(this.cleanTimer);
        this.cleanTimer = setTimeout(function(){
            Ext.getStore('NewsRemover').load();
        },3000);
    },
    giveTapEvent:function(cmp){
        //isto é temporário
        cmp.element.on('tap',function(){
            Ext.Msg.alert("Language", "Ainda não está disponível!", Ext.emptyFn);
        });
    }
});