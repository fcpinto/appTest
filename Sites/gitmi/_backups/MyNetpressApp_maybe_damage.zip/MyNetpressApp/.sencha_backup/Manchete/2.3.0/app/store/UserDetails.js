/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 09/09/13
 * Time: 13:32
 */
Ext.define('Manchete.store.UserDetails', {
    extend: 'Ext.data.Store',

    config: {
        fields:['id','login','nomeacesso','mail','nomecliente','logo'],

        startTable:true,
        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'USERDETAILS',
            enablePagingParams:false
        },
        listeners: {
            beforeload: function (store, operation) {
                //console.log(store.getData().items);
            },
            load: function (st, records, successful, operation) {
                //console.log('UserDetails: '+successful);
                //console.log(records);
                if(records.length>0){
                    this.fireEvent('onupdateuserdata', records[0].data);
                }

            }
        }
    }
});