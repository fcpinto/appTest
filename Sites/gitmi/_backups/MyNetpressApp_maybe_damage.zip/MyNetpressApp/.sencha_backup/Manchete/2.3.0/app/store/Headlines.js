/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 09/09/13
 * Time: 13:32
 */
Ext.define('Manchete.store.Headlines', {
    extend: 'Ext.data.Store',

    requires: [
        'Ext.data.proxy.JsonP'
    ],

    config:{
        model:'Manchete.model.Headlines',

        autoLoad:true,

        proxy:{
            type:"jsonp",
            url:'https://services.manchete.pt:8001/Manchetes.asmx/getHeadlinesPress',

            extraParams: {
                user:'manchetemobile',
                password:'mancheteqwerty'
            },
            pageParam:false,
            limitParam:false,
            startParam:false

        },
        pageSize:100,

        listeners:{
            load:function (st, records, successful, operation) {
                //console.log('Headlines: '+successful);
                if(successful){

                    Manchete.app.fireEvent('insertRecords', records, 'HeadlinesTable');

                    /*var record;
                    var params = [];
                    var values = [];

                    var db = window.openDatabase("MancheteDB", "1.0", "Manchete Demo", 200000);

                    db.transaction(function(tx){
                        for(var i=0; i<records.length; i++){

                            record = records[i].getData();
                            //delete record.id;
                            params = [];
                            values = [];
                            for (var j in record) {
                                params.push(j);
                                values.push(Ext.htmlEncode(record[j]));
                            }
                            //console.log('INSERT OR IGNORE INTO HEADLINES ('+params.join(',')+') VALUES("'+values.join('","')+'")');

                            tx.executeSql('INSERT OR IGNORE INTO HEADLINES ('+params.join(',')+') VALUES("'+values.join('","')+'")');
                        }
                        Ext.getStore('HeadlinesTable').load();
                    }, function(){console.log(arguments)}, function(){});*/

                    //Manchete.app.fireEvent('countTotalItems', Ext.getStore('HeadlinesTable'));

                    //select * from headlines where data <= 'Mon Sep 23 2013 00:00:00 GMT+0100 (WEST)';
                    /*var db = window.openDatabase("MancheteDB", "1.0", "Manchete Demo", 200000);
                    db.transaction(function(tx){
                        tx.executeSql('delete from headlines where data <= "Mon Sep 23 2013 00:00:00 GMT+0100 (WEST)"',[],function(tx,results){
                            var len = results.rows.length;
                            for (var i=0; i<len; i++){
                                console.log(results.rows.item(i).data);
                            }
                        });
                    },function(){
                        console.log(arguments)
                    }, function(){});*/



                    /*var prx = Ext.getStore('HeadlinesTable').getProxy();
                    var db = prx.getDatabaseObject();
                    var myFilter = new Ext.util.Filter({
                        property: 'titulo',
                        value   : 'Alta Segurança'
                    });

                    db.transaction(function(tx) {
                        //console.log(tx);
                        prx.selectRecords(tx, {filters:[myFilter]}, function(resultSet) {
                            //console.log(resultSet);
                            var len = resultSet.getTotal();
                            for (var i=0; i<len; i++){
                                console.log(resultSet.getRecords()[i].data);
                            }
                        }, this);
                    });*/
                }
                else{
                    Ext.getStore('HeadlinesTable').load();
                    //console.log('error');
                }
            }
        }
    }
});

/*
$.ajax({
    type: "GET",
    url: "https://services.manchete.pt/Manchetes.asmx/getHeadlinesPress",
    dataType: "xml",
    success: function (msg){
        console.log(msg);
    },
    failure: function(){
        console.log('Failure');
    }
});


var xmlhttp=new XMLHttpRequest();
xmlhttp.onreadystatechange=function(){
    if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
        var node = xmlhttp.responseXML.querySelector('string').firstChild.textContent;
        var data = JSON.parse(node);
        console.log(data);
    }
}
xmlhttp.open("POST","https://services.manchete.pt/Manchetes.asmx/getHeadlinesPress",true);
xmlhttp.send();
//user=manchetemobile&password=mancheteqwerty
*/