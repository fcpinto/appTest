/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 17/09/13
 * Time: 00:52
 */
Ext.define('Manchete.model.News', {
    extend: 'Ext.data.Model',

    config: {
        fields: [
            'id',
            'titulo',
            'publicacao',
            'suplemento',
            'tipo',
            'tema',
            'bold',
            'link',
            'linkType',
            'data',
            'data_insercao',
            'hora_insercao',
            'jornalista',
            'paginas',
            'duracoes',
            'texto',
            {
                name:'favorito',
                type:'int',
                allowNull:false
            },
            {
                name:'downloaded',
                type:'int',
                allowNull:false
            }
        ]
    }
});