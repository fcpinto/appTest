/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 16/09/13
 * Time: 15:29
 */
Ext.define('Manchete.store.UserThemesTable', {
    extend: 'Ext.data.Store',

    config: {
        model: 'Manchete.model.UserThemesTable',

        sorters: ['tema'],

        pageSize: 100,
        startTable:true,
        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'THEMES'
        },
        listeners: {
            beforeload: function (store, operation) {
                //console.log(store.getData().items);
            },
            load: function (st, records, successful, operation) {
                //console.log('UserThemesTable: '+successful);
                //console.log(records);
            }
        }
    }
});