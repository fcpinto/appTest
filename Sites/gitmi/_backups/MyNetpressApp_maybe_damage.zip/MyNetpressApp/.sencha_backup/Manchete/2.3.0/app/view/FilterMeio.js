/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.view.FilterMeio', {
    extend: 'Ext.dataview.List',
    xtype: 'filterMeio',

    config: {
        modal: true,
        centered:true,
        hideOnMaskTap: true,
        hidden: true,
        width: !Ext.os.is.Phone? 400 : 260,
        height: !Ext.os.is.Phone? 400 : '70%',
        contentEl: 'content',
        styleHtmlContent: true,
        scrollable: true,
        store: 'FilterMeio',
        mode:'MULTI',
        callback:'',
        itemTpl:Ext.create('Ext.XTemplate',
            '<span class="title">{text}</span>'
        ),
        items:[
            {
                xtype:'titlebar',
                docked:'top',
                title: 'Filtros',
                ui:'light',
                items: [
                    {
                        iconCls: 'ss-notall',
                        align: 'left',
                        ui:'plain',
                        action:'fSelectAll',
                        itemId:'fSelectAll'
                    },
                    {
                        iconCls: 'ss-select',
                        align: 'right',
                        ui:'plain',
                        action:'fClose'
                    }
                ]
            }
        ],
        listeners:{
            initialize:function(list){
                //list.getStore().load();
            },
            itemtap:{
                fn: function (list, index, target, record, e) {

                    /*var store = Ext.getStore('FilterPublicacao'),
                        refs = [],
                        selection,len;

                    if(record.data.text == 'Todos'){
                        if(list.isSelected(record)){
                            list.selectAll();
                        }
                        else{
                            list.deselectAll();
                        }
                    }
                    else{
                        list.deselect(0);
                    }

                    selection = list.getSelection();
                    len = selection.length;

                    for (var i = 0; i < len; i++) {
                        if(selection[i].data.value != 'todos'){
                            refs.push(selection[i].data.value);
                        }
                    }
                    list.form.setValues({
                        refString:len==1?selection[0].data.text:len==0?'':'vários',
                        referencia3:len==0?'':'"'+refs.join('","')+'"'
                    });
                    store.setFilters([
                        {
                            property: 'ownQuery',
                            value: 'SELECT DISTINCT publicacao FROM NEWS WHERE tipo in ("' + refs.join('","') + '")'
                        }
                    ]);
                    store.load();*/

                },
                buffer:100
            }
        }
    }
});