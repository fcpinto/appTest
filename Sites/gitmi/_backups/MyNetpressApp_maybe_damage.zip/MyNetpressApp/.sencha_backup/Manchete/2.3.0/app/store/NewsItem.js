/**
 * Created by zul on 07/10/13.
 */
/*Ext.define('Manchete.store.NewsItem', {
    extend: 'Ext.data.Store',

    config:{
        model: 'Manchete.model.News',

        listeners: {
            load: function (st, records, successful, operation) {

                if(successful){
                    //console.log(records[0].data.texto);
                }
            }
        }

    }
});*/

Ext.define('Manchete.store.NewsItem', {
    extend: 'Ext.data.Store',

    config: {
        model: 'Manchete.model.News',
        sorters:[{property:'data',direction:'DESC'}],

        pageSize: 1,
        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'NEWS'
        },
        listeners: {
            beforeload:function(){
                /*Ext.getCmp('contentView').setMasked({
                    xtype:'container',
                    centered:true,
                    modal:true,
                    html:'<div style="text-align:center; background-color:rgba(0, 0, 0, 0.51);padding:20px;border-radius:0px; color: #ffffff; font-size: 75%;">' +
                        '<img src="resources/images/lg.png" width="58px" height="58px" >' +
                        '<br>loading...</div>'
                });*/
                Ext.getCmp('contentView').setMasked({
                    xtype: 'loadmask',
                    message: ''
                });
                /*Ext.getCmp('contentView').setMasked({
                    xtype: 'loadmask',
                    message: '<img class="rotationObj" src="resources/images/loader.png" width="32px" height="32px">',
                    indicator:false
                });*/
            },
            load: function (st, records, successful, operation) {
                //console.log('NewsItem: ' + successful);
                //console.log(st.getPageSize());
                if(successful){
                    //console.log('********************')
                    if(records.length > 0){
                        if(records[0].data.texto == ''){

                            var data = records[0].data;


                            Ext.getStore('SearchResult').load({
                                params:{
                                    user: localStorage.mancheteuser,
                                    password: localStorage.manchetepass,
                                    listIds: JSON.stringify([{
                                        "id": data.id,
                                        "tipo": data.tipo,
                                        "data": data.data
                                    }])
                                },
                                callback: function (recs, operation, success) {
                                    if(success){
                                        var result = recs[0].data;
                                        //console.log(result);

                                        Manchete.app.getController('MancheteDB').updateRowById(result,function(){
                                            Ext.getStore('NewsItem').load();
                                            Ext.getStore('News').load();
                                        });
                                        //list.getStore().sync();
                                    }
                                    else{
                                        Ext.getCmp('contentView').setMasked(false);
                                        //Ext.Msg.alert("Internet", "Não tem ligação à internet!", Ext.emptyFn);
                                    }
                                }
                            });


                            /*Ext.getStore('TextById').load({
                                params:{
                                    user: localStorage.mancheteuser,
                                    password: localStorage.manchetepass,
                                    Id: JSON.stringify({
                                        "id": data.id,
                                        "tipo": data.tipo,
                                        "data": data.data
                                    })
                                },
                                callback: function (records, operation, success) {
                                    if(success){
                                        var result = records[0].data;
                                        console.log(result);

                                        Manchete.app.getController('MancheteDB').updateRowById(result,function(){
                                            Ext.getStore('NewsItem').load();
                                        });
                                    }
                                    else{
                                        Ext.getCmp('contentView').setMasked(false);
                                        //Ext.Msg.alert("Internet", "Não tem ligação à internet!", Ext.emptyFn);
                                    }
                                }
                            });*/


                            /*Ext.data.JsonP.request({
                                url: 'https://services.manchete.pt:8002/Clientes.asmx/getTextbyId',
                                callbackKey: 'callback',
                                params: {
                                    user: localStorage.mancheteuser,
                                    password: localStorage.manchetepass,
                                    Id: JSON.stringify({
                                        "id": data.id,
                                        "tipo": data.tipo,
                                        "data": data.data
                                    })
                                },
                                success: function (result, request) {
                                    //console.log(arguments)
                                    Manchete.app.getController('MancheteDB').updateFieldById(data.id,'texto',Ext.htmlEncode(result.texto),function(){
                                        Ext.getStore('NewsItem').load();
                                    })
                                },
                                failure: function () {
                                    Ext.getCmp('contentView').setMasked(false);
                                    //Ext.Msg.alert("Internet", "Não tem ligação à internet!", Ext.emptyFn);
                                }
                            });*/
                        }
                        else{
                            Ext.getCmp('contentView').setMasked(false);
                        }
                    }
                    else{
                        Ext.getCmp('contentView').setMasked(false);
                    }
                    //console.log('********************')
                }
                else{
                    Ext.getCmp('contentView').setMasked(false);
                }
            }
        }
    }
});