/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 09/09/13
 * Time: 13:32
 */
Ext.define('Manchete.store.Login', {
    extend: 'Ext.data.Store',

    requires: [
        'Ext.data.proxy.JsonP'
    ],

    config:{
        fields: [
            {
                name:'id',
                mapping:'mail'
            },
            'login',
            'nomeacesso',
            'mail',
            'nomecliente',
            'logo'
        ],

        proxy:{
            type:"jsonp",
            url:'https://services.manchete.pt:8002/Clientes.asmx/AuthenticateLogin',

            pageParam:false,
            limitParam:false,
            startParam:false
        }
    }
});