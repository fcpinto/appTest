/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 27/08/13
 * Time: 12:13
 */
Ext.define('Manchete.view.ManchetesGrid', {
    extend: 'Ext.carousel.Carousel',
    xtype: 'manchetesGrid',

    config: {
        title: 'Manchetes',
        padding: 0,
        //cls:'manchetes-carousel',

        listeners: {
            initialize: function (cmp) {
                Manchete.app.fireEvent('getTodayCovers', function (data) {
                    var len = data.length,
                        maxItemsPerPage = !Ext.os.is.Phone?6: 4,
                        totalPages = Math.ceil(len/maxItemsPerPage),
                        itemsPerPage,
                        pages = [],
                        items = [],
                        width = !Ext.os.is.Phone?'33.3%':'50%';

                    console.log(len, maxItemsPerPage, totalPages);

                    for (var i = 0; i < totalPages; i++) {
                        console.log('----------');
                        pages.push(Ext.create('Ext.Container',{
                            style:'background-color:#EAEDF0;'
                        }));
                        itemsPerPage = (maxItemsPerPage * (i+1) < len)?maxItemsPerPage:len-(maxItemsPerPage * (i));
                        items = [];
                        for (var j = 0; j < itemsPerPage; j++) {
                            console.log('✹ ');
                            items.push({
                                xtype:'container',
                                width:width,
                                height:'50%',
                                //html: ((i * maxItemsPerPage) + (j)) + '',
                                style: 'float: left; display: inline-block!important; padding:10px;',
                                items:[
                                    {
                                        xtype:'img',
                                        width:'100%',
                                        height:'100%',
                                        ref: ((i * maxItemsPerPage) + (j)) + '',
                                        src: data[(i * maxItemsPerPage) + (j)].linkBig,
                                        style: 'float: left; display: inline-block!important; padding:10px; background-size:contain;',// -webkit-box-shadow: 0 5px 10px -6px black; background-color:#ffffff;' +
                                            //' background-image:url('+data[(i*maxItemsPerPage)+(j)].data+');'
                                        listeners: {
                                            tap: function () {
                                                Manchete.app.mancheteActiveItem = this.config.ref;
                                                this.up('manchetesGrid').fireEvent('mancheteImgtap', this);
                                            },
                                            element: 'element'
                                        }
                                    }
                                ]
                            });
                        }
                        pages[i].setItems(items);
                        console.log(pages[i]);
                    }
                    cmp.add(pages);


                    /*var items = [];
                    for (var i in data) {
                        items.push({
                            xtype:'container',
                            styleHtmlContent:true,
                            layout:'vbox',
                            style:'background-color:#ffffff;',
                            items:[
                                {
                                    xtype:'component',
                                    style:'background-color: rgba(0, 0, 0, 0.7); height: 30px; color: #ffffff; text-align: center; padding: 6px 5px 2px 5px; font-size: 80%;',
                                    html:data[i].data,
                                    docked:'top'
                                },
                                {
                                    xtype: 'img',
                                    src: data[i].linkBig,
                                    style: 'background-size:contain;',
                                    flex:1,
                                    listeners: {
                                        tap: function () {
                                            this.up('manchetesCarousel').fireEvent('mancheteImgtap', this);
                                        },
                                        element: 'element'
                                    }
                                },
                                {
                                    xtype:'component',
                                    style:'background-color: rgba(0, 0, 0, 0.7); height: 30px; color: #ffffff;',
                                    docked:'bottom'
                                }
                            ]
                        })
                    }
                    cmp.add(items);*/
                });
            }
        }
    }
});
