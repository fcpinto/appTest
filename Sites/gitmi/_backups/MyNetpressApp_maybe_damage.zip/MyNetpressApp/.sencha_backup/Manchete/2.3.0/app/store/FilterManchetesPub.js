/**
 * Created by zul on 07/10/13.
 */
Ext.define('Manchete.store.FilterManchetesPub', {
    extend: 'Ext.data.Store',

    config: {
        fields:['publicacao',
            {
                name:'text',
                convert:function(vl,rec){
                    return rec.raw.publicacao;
                }
            },
            {
                name:'value',
                convert:function(vl,rec){
                    return rec.raw.publicacao;
                }
            }
        ],
        filters:[
            {
                property: 'ownQuery',
                value: 'SELECT DISTINCT publicacao FROM HEADLINES'
            }
        ],
        pageSize:false,
        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'HEADLINES',
            tableExists:true
        },
        listeners: {
            load: function (st, records, successful, operation) {

                /*if(records.length > 0){
                    st.insert(0, [
                        {
                            publicacao:'Todos',
                            tipo:'todos'
                        }
                    ])
                }*/
            }
        }

    }
});