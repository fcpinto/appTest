/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 09/09/13
 * Time: 13:32
 */
Ext.define('Manchete.store.SearchResult', {
    extend: 'Ext.data.Store',

    requires: [
        'Ext.data.proxy.JsonP'
    ],

    config:{
        model:'Manchete.model.MediaType',

        proxy:{
            type:"jsonp",

            url:'https://services.manchete.pt:8002/Clientes.asmx/getSearchResult',

            extraParams: {
                user: localStorage.mancheteuser,
                password: localStorage.manchetepass,
                listIds:''
            },
            pageParam:false,
            limitParam:false,
            startParam:false
        }/*,
        pageSize:100,

        listeners:{
            load:function (st, records, successful, operation) {
                /*console.log('SearchResult: '+successful);
                if(successful){
                    console.log(records);
                    var len = records.length,
                        store = Ext.getStore('News'),
                        listIds = [];

                    if(len>0){
                        for(var i=0;i<len;i++){
                            listIds.push(records[i].data.id);
                        }
                        store.setFilters([
                            {
                                property:'id',
                                values:listIds
                            }
                        ]);
                    }
                    Manchete.app.fireEvent('insertRecords', records, 'News');
                    Manchete.app.getController('Main').showViews('mediaType');
                    Ext.Viewport.getMasked().setHidden(true);
                }
                else{
                    Ext.Msg.alert('Internet', 'Erro de ligação à Internet.', Ext.emptyFn);
                    Ext.Viewport.getMasked().setHidden(true);
                    //Ext.getStore('HeadlinesTable').load();
                    //console.log('error');
                }
            }
        }*/
    }
});