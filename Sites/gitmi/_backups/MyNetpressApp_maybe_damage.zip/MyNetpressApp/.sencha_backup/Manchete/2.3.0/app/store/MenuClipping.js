/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 09/09/13
 * Time: 13:32
 */
Ext.define('Manchete.store.MenuClipping', {
    extend: 'Ext.data.Store',

    requires: [
        'Ext.data.proxy.JsonP'
    ],

    config:{
        model:'Manchete.model.MenuClipping',

        autoLoad:true,

        proxy:{
            type:"jsonp",
            url:'https://services.manchete.pt:8002/Clientes.asmx/getClippingbyUser',

            extraParams: {
                user: localStorage.mancheteuser,
                password: localStorage.manchetepass
            },
            pageParam:false,
            limitParam:false,
            startParam:false

        },

        listeners:{
            load:function (st, records, successful, operation) {
                //console.log('MenuClipping: ' + successful);
                if(successful){

                    //window.myRecords = records;
                    Manchete.app.fireEvent('insertRecords', records, 'MenuClippingTable');



                    //Manchete.app.getController('Main').loadRemoteNews();
                    //TEMPORÁRIO

                    //Manchete.app.getController('Main').loadStores(records);

                    /*user:teste@manchete.pt
                    password:b9Wk9Yeq
                    datainicio:2013-10-02 00:00
                    datafim:2013-10-02 18:00
                    referencia3:

                    user:teste@manchete.pt
                    password:b9Wk9Yeq
                    datainicio:2013-10-18 17:38
                    datafim:2013-10-25 17:38
                    referencia3:*/


                    //https://services.manchete.pt:8002/Clientes.asmx/getNewsPress?callback=xpto&user=teste%40manchete.pt&password=b9Wk9Yeq&datainicio=2013-10-02+00%3A00&datafim=2013-10-02+18%3A00&referencia3=&_=1382718380152
                    //https://services.manchete.pt:8002/Clientes.asmx/getNewsPress?_dc=1382719107898&user=teste%40manchete.pt&password=b9Wk9Yeq&datainicio=2013-10-18+00%3A00&datafim=2013-10-24+18%3A00&referencia3=&callback=Ext.data.JsonP.callback4





                    /*var record;
                    var params = [];
                    var values = [];

                    var db = window.openDatabase("MancheteDB", "1.0", "Manchete Demo", 200000);

                    db.transaction(function(tx){
                        for(var i=0; i<records.length; i++){

                            record = records[i].getData();
                            //delete record.id;
                            params = [];
                            values = [];
                            for (var j in record) {
                                params.push(j);
                                values.push(Ext.htmlEncode(record[j]));
                                console.log(record[j])
                            }
                            //console.log('INSERT OR IGNORE INTO CLIPPING ('+params.join(',')+') VALUES("'+values.join('","')+'")')
                            tx.executeSql('INSERT OR IGNORE INTO CLIPPING ('+params.join(',')+') VALUES("'+values.join('","')+'")');
                        }
                        Ext.getStore('MenuClippingTable').load();
                    }, function(){console.log(arguments)}, function(){});*/
                }
                else{
                    Ext.getStore('MenuClippingTable').load();
                    //console.log('error');
                }
            }
        }
    }
});
