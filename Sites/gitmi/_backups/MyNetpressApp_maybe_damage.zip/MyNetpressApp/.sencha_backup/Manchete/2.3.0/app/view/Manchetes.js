/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 18/09/13
 * Time: 11:21
 */
Ext.define('Manchete.view.Manchetes', {
    extend: 'Ext.dataview.List',
    xtype: 'manchetes',

    config: {
        title: 'Manchetes',
        cls: 'manchetes-list',
        selectedCls: '',
        padding: 0,
        margin: 0,
        styleHtmlContent: true,
        store: 'HeadlinesTable',
        grouped: true,
        striped: true,
        scrollable:{
            direction:'vertical',
            directionLock:true
        },
        /*itemTpl: [
         '<span class="title">{titulo}</span><br>',
         '<span class="date" style="opacity: 0.7; font-size: 90%;">{data}</span>'
         ].join(''),*/
        itemTpl: Ext.os.is.Phone ? [
            '<div class="boxPhone">',
            '   <div class="title">{titulo}</div>',
            '   <div class="others">',
            '       <div class="date">{data}</div>',
            '       <div class="share iconios"></div>',
            '       <div class="open iconios"></div>',
            '   </div>',
            '</div>'
        ].join('') : [
            '<div class="box">',
            '   <div class="title">{titulo}</div>',
            '       <div class="date">{data}</div>',
            '       <div class="share iconios"></div>',
            '       <div class="open iconios"></div>',
            '</div>'
        ].join(''),
        items: [
            {
                xtype: 'container',
                style: 'text-align:center; padding:10px 0 10px 0; background-color:#ffffff; color:#0775c1; font-family: iOSss;',
                html: '6',
                itemId: 'toNext',
                scrollDock: 'bottom',
                hidden: true,
                listeners: {
                    tap: {
                        fn: function () {
                            var store = this.up('list').getStore(),
                                totalItems = store.getProxy().totalItems,
                                totalPages = Math.ceil(totalItems / store.getPageSize());

                            if (store.currentPage < totalPages) {
                                store.nextPage();
                            }
                        },
                        element: 'element'
                    }
                }
            },
            {
                xtype: 'container',
                style: 'text-align:center; padding:10px 0 10px 0; background-color:#ffffff; color:#0775c1; font-family: iOSss;',
                html: '9',
                itemId: 'toPrev',
                scrollDock: 'top',
                hidden: true,
                listeners: {
                    tap: {
                        fn: function () {
                            var store = this.up('list').getStore(),
                                currentPage = store.currentPage;
                            if (currentPage > 1) {
                                store.previousPage();
                            }
                        },
                        element: 'element'
                    }
                }
            }
        ],
        listeners: {
            refresh: function (list) {
                var store = list.getStore(),
                    totalItems = store.getProxy().totalItems,
                    totalPages = Math.ceil(totalItems / store.getPageSize()),
                    currentPage = store.currentPage,
                    toPrev = list.down('#toPrev'),
                    toNext = list.down('#toNext');

                toPrev.setHidden(currentPage <= 1);
                toNext.setHidden(store.currentPage >= totalPages);
            }
        }
    }
});
