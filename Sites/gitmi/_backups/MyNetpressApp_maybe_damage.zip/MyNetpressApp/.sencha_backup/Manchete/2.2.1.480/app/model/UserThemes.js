/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 17/09/13
 * Time: 00:52
 */
Ext.define('Manchete.model.UserThemes', {
    extend: 'Ext.data.Model',

    config: {
        fields:[
            'id',
            'tema',
            'referencia4'
        ]
    }
});