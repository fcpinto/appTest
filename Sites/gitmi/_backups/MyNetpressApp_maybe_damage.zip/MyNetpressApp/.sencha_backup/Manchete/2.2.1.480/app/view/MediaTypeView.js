/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 18/09/13
 * Time: 11:21
 */
Ext.define('Manchete.view.MediaTypeView', {
    extend: 'Ext.dataview.List',
    xtype: 'mediaType',

    config: {

        cls: 'manchetes-list',

        selectedCls: '',
        padding: 0,
        margin: 0,
        styleHtmlContent: true,
        store: 'News',
        masked:{
            xtype: 'loadmask',
            hidden:false
        },
        scrollable:{
            direction:'vertical',
            directionLock:true
        },
        scrollToTopOnRefresh:false,
        striped: true,
        //emptyText:'Não existem novas notícias...',
        itemTpl: Ext.os.is.Phone?Ext.create('Ext.XTemplate',
            '<div class="boxPhone">',
            '   <div class="title">{titulo}</div>',
            '   <div class="others">',
            '       <div class="provider">{publicacao}</div>',
            '       <div class="date">{data}</div>',
            '       <div class="favorite{[this.isFavorite(values.favorito)]}">⋆</div>',
            '       <div class="share"></div>',
            '       <div class="file">{[this.fileType(values.linkType)]}</div>',
            '   </div>',
            '</div>',
            {
                isFavorite:function(vl){
                    if(vl == 1){
                        return 'Yes';
                    }
                    return 'No';
                },
                fileType:function(vl){
                    if(vl == 'pdf'){
                        return '📄';
                    }
                    else if(vl == 'video'){
                        return '📹';
                    }
                    else if(vl == 'audio'){
                        return '🔉';
                    }
                    return '🔗';
                }
            }
        ):Ext.create('Ext.XTemplate',
            '<div class="box">',
            '   <div class="title">{titulo}</div>',
            '       <div class="provider">{publicacao}</div>',
            '       <div class="date">{data}</div>',
            '       <div class="favorite{[this.isFavorite(values.favorito)]}">⋆</div>',
            '       <div class="share"></div>',
            '       <div class="file">{[this.fileType(values.linkType)]}</div>',
            '</div>',
            {
                isFavorite:function(vl){
                    if(vl == 1){
                        return 'Yes';
                    }
                    return 'No';
                },
                fileType:function(vl){
                    if(vl == 'pdf'){
                        return '📄';
                    }
                    else if(vl == 'video'){
                        return '📹';
                    }
                    else if(vl == 'audio'){
                        return '🔉';
                    }
                    return '🔗';
                }
            }
        ),
        items:[
            {
                xtype:'container',
                style:'text-align:center; padding:10px 0 10px 0; background-color:#ffffff; color:#0775c1; font-family: SSStandard;',
                html:'',
                itemId:'toNext',
                scrollDock:'bottom',
                hidden:true,
                listeners: {
                    tap: {
                        fn: function(){
                            var store = this.up('list').getStore(),
                                totalItems = store.getProxy().totalItems,
                                totalPages = Math.ceil(totalItems/store.getPageSize());

                            if(store.currentPage < totalPages){
                                store.nextPage();
                            }
                        },
                        element: 'element'
                    }
                }
            },
            {
                xtype:'container',
                style:'text-align:center; padding:10px 0 10px 0; background-color:#ffffff; color:#0775c1; font-family: SSStandard;',
                html:'',
                itemId:'toPrev',
                scrollDock:'top',
                hidden:true,
                listeners: {
                    tap: {
                        fn: function(){
                            var store = this.up('list').getStore(),
                                currentPage = store.currentPage;
                            if(currentPage > 1){
                                store.previousPage();
                            }
                        },
                        element: 'element'
                    }
                }
            }
        ],
        listeners:{
            refresh:function(list){
                var store = list.getStore(),
                    totalItems = store.getProxy().totalItems,
                    totalPages = Math.ceil(totalItems/store.getPageSize()),
                    currentPage = store.currentPage,
                    toPrev = list.down('#toPrev'),
                    toNext = list.down('#toNext');

                toPrev.setHidden(currentPage<=1);
                toNext.setHidden(store.currentPage >= totalPages);
            }
        }
    }
});
