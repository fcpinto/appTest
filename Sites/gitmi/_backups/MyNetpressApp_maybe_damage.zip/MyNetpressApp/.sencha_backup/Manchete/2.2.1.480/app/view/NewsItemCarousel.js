/**
 * Created by zul on 01/10/13.
 */
Ext.define('Manchete.view.NewsItemCarousel', {
    extend: 'Ext.Container',
    xtype: 'newsItemCarousel',

    config: {
        styleHtmlContent: true,
        scrollable:{
            direction:'vertical',
            directionLock:true
        },
        style:'background-color:#ffffff;',
        /*hideAnimation:{
            duration: 300,
            easing: 'ease-out',
            type: 'slide',
            out: true
        },*/
        tpl: Ext.create('Ext.XTemplate',
            '<div class="topbar" style="width: 100%; background-color: #eeeeee; position: absolute; top: 0; left: 0; padding: 5px; color:#03486c; font-family: SSStandard;">',
            '   <div class="favorite" style="float: right; padding: 5px 10px;">⋆</div>',
            '   <div class="file" style="float: right; padding: 5px 10px;">{[this.fileType(values.linkType)]}</div>',
            '   <div class="trash" style="float: right; padding: 5px 10px;"></div>',
            '</div>',
            '<div class="boxPhone" style="padding-top: 40px; padding-bottom:10px; border-bottom: #CCCCCC solid 1px;">',
            '   <span class="title"><b>{titulo}</b></span><br>',
            '   <span class="texto" style="font-size: 80%; color: #666666;">{jornalista} | {publicacao}</span><br>',
            '   <span class="date" style="font-size: 80%; color: #666666;">{data}</span>',
            '</div>',
            {
                isFavorite:function(vl){
                    if(vl == 1){
                        return 'Yes';
                    }
                    return 'No';
                },
                fileType:function(vl){
                    if(vl == 'pdf'){
                        return '📄';
                    }
                    else if(vl == 'video'){
                        return '📹';
                    }
                    else if(vl == 'audio'){
                        return '🔉';
                    }
                    return '🔗';
                }
            }
        ),
        listeners:{
            initialize:function(cmp){
                console.log(cmp.getData());
                var data = cmp.getData();
                cmp.element.on('tap', function(e,target){
                    if(target.className=='favorite'){

                    }
                    if(target.className=='file'){
                        var ref = window.open(Ext.htmlDecode(data.link), '_blank', 'location=yes,EnableViewPortScale=yes');
                        ref.addEventListener('exit', function(event) {
                            Manchete.app.getController('MancheteDB').db = rootdb;
                        });
                    }
                    if(target.className=='trash'){
                        cmp.up('navigationview').pop();
                    }
                })
            },
            destroy:function(cmp){
                console.log('has been destroyed!!')
            }
        }
    }
});