/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 27/08/13
 * Time: 12:13
 */
Ext.define('Manchete.view.ManchetesCarousel', {
    extend: 'Ext.carousel.Carousel',
    xtype: 'manchetesCarousel',

    config: {
        title: 'Manchetes',
        padding: 0,

        listeners: {
            initialize: function (cmp) {
                Manchete.app.fireEvent('getTodayCovers', function (data) {
                    var items = [];
                    for (var i in data) {
                        items.push({
                            xtype: 'img',
                            src: data[i].linkBig,
                            style: 'background-size:contain;',
                            html: [
                                '<div style="background-color: rgba(0, 0, 0, 0.8); color: #ffffff; top: 0; position: absolute; width: 100%; padding: 5px 5px 8px 5px;">',
                                '<span class="date" style="opacity: 0.7; font-size: 90%;">' + data[i].data + '</span>',
                                '</div>',
                                '<div style="background-color: rgba(238, 238, 238, 0.8); bottom: 0; position: absolute; width: 100%; height: 30px;"></div>'
                            ].join(''),
                            listeners: {
                                tap: function () {

                                    var ref = window.open(this.getSrc(), '_blank', 'location=no,EnableViewPortScale=yes');
                                    ref.addEventListener('exit', function (event) {
                                        Manchete.app.getController('MancheteDB').db = rootdb;
                                    });
                                },
                                element: 'element'
                            }
                        });
                    }
                    cmp.add(items);
                });
            }
        }
    }
});
