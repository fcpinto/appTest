/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 18/09/13
 * Time: 16:56
 */
Ext.define('Manchete.controller.Manchetes', {
    extend: 'Ext.app.Controller',

    config: {
        refs: {
            manchetes:'manchetes',
            dailyNav:'dailyNav',
            manchetesCarousel:'manchetesCarousel',
            manList:'manchetes list'
        },
        control: {
            manchetes:{
                initialize:'onInit'
            },
            dailyNav:{
                initialize:'onInit'
            },
            manchetesCarousel:{
                initialize:'onInit'
            },
            manList:{
                itemtap:'onItemTap'
            },
            'button[action=typeView]':{
                tap:'onTypeView'
            }
        }
    },
    init:function(){
        this.mainController = Manchete.app.getController('Main');
    },
    onInit:function(nav){
        var flag = (nav.xtype === 'manchetes');
        nav.getNavigationBar().add({
            xtype:'button',
            iconCls:flag?'ss-target':'ss-rows',
            ui:'plain',
            text:' ',
            align:'right',
            action:'typeView',
            openView: flag?'manchetesCarousel':'manchetes',
            store:'HeadlinesTable'
        });
    },
    onItemTap:function (dv, index, target, record, e) {
        //console.log(record)
        var ref = window.open('photoHolder.html?'+record.data.linkBig, '_blank', 'location=no,toolbar=no,transitionstyle=fliphorizontal');
        ref.addEventListener('loadstart', function(event) {
            if(event.url.split('?')[1] == 'done'){
                ref.close();
            }
        });
        //Ext.Viewport.overlay.element.dom.style.backgroundImage = 'url(' + record.data.linkBig + ')';
        //Ext.Viewport.overlay.show();

    },
    onTypeView:function(btn){
        this.mainController.openView(btn);
        //btn.setIconCls((btn.getIconCls() === 'ss-target')?'ss-rows':'ss-target');
    }
});