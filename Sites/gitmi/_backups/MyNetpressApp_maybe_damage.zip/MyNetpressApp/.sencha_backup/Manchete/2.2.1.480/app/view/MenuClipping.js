/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 26/08/13
 * Time: 20:23
 */
Ext.define('Manchete.view.MenuClipping', {
    extend: 'Ext.dataview.List',
    xtype: 'menuClipping',

    config: {
        id: 'm-menu',
        style: 'background-color: #ffffff;',
        width: 240,
        layout: 'fit',
        showAnimation: {type: 'slide', direction: 'right'},
        hideAnimation: {type: 'slide', direction: 'left', out: true},
        scrollable: {
            direction: 'vertical',
            indicators: false
        },
        masked:{
            xtype: 'loadmask',
            hidden:false
        },
        cls:'menu-list',
        styleHtmlContent:true,
        store:'MenuClippingTable',
        grouped: true,
        itemTpl: [
            '<span class="title">{clipping}</span><br>'
        ].join(''),
        items: [
            {
                docked: 'bottom',
                xtype: 'toolbar',
                padding: 0,
                layout: 'hbox',
                ui: 'about-settings',
                items:[
                    {
                        xtype: 'button',
                        ui:'plain',
                        iconCls: 'ss-settings',
                        flex:1
                    },
                    {
                        xtype: 'button',
                        ui:'plain',
                        iconCls: 'ss-info',
                        flex:1
                    }
                ]
            }

        ]
    }
})