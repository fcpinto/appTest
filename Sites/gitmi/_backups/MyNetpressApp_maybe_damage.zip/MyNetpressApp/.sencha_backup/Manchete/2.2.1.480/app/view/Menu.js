/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 26/08/13
 * Time: 20:23
 */
Ext.define('Manchete.view.Menu', {
    extend: 'Ext.Container',
    xtype: 'menu',

    config: {
        id: 'm-menu',
        style: 'background-color: #333333;',
        width: 200,
        layout: 'vbox',
        showAnimation: {type: 'slide', direction: 'right'},
        hideAnimation: {type: 'slide', direction: 'left', out: true},
        scrollable: {
            direction: 'vertical',
            indicators: false
        },
        items: [
            {
                docked: 'top',
                xtype: 'toolbar',
                padding: 0,
                layout: 'fit',
                ui: 'light'
            },
            {
                xtype: 'leftbtn',
                iconCls: 'ss-calender',
                iconAlign: 'left',
                text: 'Daily',
                openView: 'manchetes'
            },
            {
                xtype: 'leftbtn',
                iconCls: 'ss-globe',
                iconAlign: 'left',
                text: 'Online'
            },
            {
                xtype: 'leftbtn',
                iconCls: 'ss-mic',
                iconAlign: 'left',
                text: 'Radio'
            },
            {
                xtype: 'leftbtn',
                iconCls: 'ss-desktop',
                iconAlign: 'left',
                text: 'TV'
            },
            {
                xtype: 'leftbtn',
                iconCls: 'ss-star',
                iconAlign: 'left',
                text: 'Favorites'
            },
            {
                xtype: 'leftbtn',
                iconCls: 'ss-settings',
                iconAlign: 'left',
                text: 'About',
                docked: 'bottom'
            },
            {
                xtype: 'leftbtn',
                iconCls: 'ss-info',
                iconAlign: 'left',
                text: 'Settings',
                docked: 'bottom'
            },
            {
                xtype: 'component',
                padding: 0,
                margin: '5 10 5 10',
                docked: 'bottom',
                style: 'border-top:#666666 solid 1px;'
            }

        ]
    }
})