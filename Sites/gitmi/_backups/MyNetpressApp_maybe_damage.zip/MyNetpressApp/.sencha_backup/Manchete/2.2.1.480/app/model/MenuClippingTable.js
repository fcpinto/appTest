/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 17/09/13
 * Time: 00:52
 */
Ext.define('Manchete.model.MenuClippingTable', {
    extend: 'Ext.data.Model',

    config: {
        fields:[
            'id',
            {
                name: 'clipping'
            },
            'activo',
            'referencia3',
            {
                name:'marcador'
            }
        ]/*,
        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'HEADLINES'
        }*/
    }
});