/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 16/09/13
 * Time: 15:29
 */
Ext.define('Manchete.store.MenuClippingTable', {
    extend: 'Ext.data.Store',

    config: {
        model:'Manchete.model.MenuClippingTable',

        sorters:['marcador', 'id'],
        grouper: {
            groupFn: function(record) {
                return record.get('marcador');
            }
        },

        pageSize:100,

        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'CLIPPING'
            //,pageParam:false
        },
        listeners:{
            beforeload:function(store, operation){
                //console.log(store.getData().items);
            },
            load:function(st, records, successful, operation){
                console.log(successful);

                st.insert(0,[
                    {
                        id: 2001,
                        clipping: '<span style="font-family: SSStandard">📅 </span>Manchetes',
                        activo: '2',
                        referencia3: 'manchetesCarousel',
                        marcador: '   Hoje'
                    },
                    {
                        id: 2002,
                        clipping: '<span style="font-family: SSStandard">⋆ </span>Favoritos',
                        activo: '0',
                        referencia3: 'favorito',
                        marcador: '   Outros'

                    },
                    {
                        id: 2003,
                        clipping: '<span style="font-family: SSStandard">⏲ </span>Histórico',
                        activo: '0',
                        referencia3: 'historico',
                        marcador: '   Outros'

                    }
                ]);
                //console.log(records);
            },
            addrecords:function(){
                console.log('')
            }
        }
    }
});