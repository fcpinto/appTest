/**
 * Created with JetBrains WebStorm.
 * User: zul
 * Date: 16/09/13
 * Time: 15:29
 */
Ext.define('Manchete.store.HeadlinesTable', {
    extend: 'Ext.data.Store',

    config: {

        model:'Manchete.model.HeadlinesTable',
        sorters:['publicacao', {property:'data',direction:'DESC'}],
        grouper: {
            groupFn: function(record) {
                return record.get('publicacao');
            }
        },
        filters: [
            {
                property: 'data?>=',
                value   : 'date("now", "-6 days")'
            }
        ],
        pageSize:50,

        proxy: {
            type: "sql",
            database: 'MancheteDB',
            table: 'HEADLINES',
            tableExists: true,
            //limitParam: 'pageSize'

            pageParam:false,
            limitParam:false,
            startParam:false
        },
        listeners:{
            beforeload:function(store, operation){
                //console.log(store.getData().items);
            },
            load:function(st, records, successful, operation){
                console.log(successful);
                //console.log(records);
            }
        }
    }
});